# Persisted Context - Observius Project

## Completed Task
User requested: "Restore the AI function but do not apply to any alerts. Instead add a button to each alert that says 'Tell me more'. When someone manually presses this button, use AI to provide the same type of info as before."

### Implementation Complete:
1. **API Endpoint:** `POST /api/alerts/:id/analyze` - Takes alert ID, returns AI-generated ~200 word analysis
   - Returns cached analysis if available in database
   - Sanitizes inputs with fallback values
   - Uses 502 status for AI service errors
   - Caches analysis in database via `storage.updateAlertAnalysis()`

2. **OpenAI Function:** `generateAlertAnalysis()` in `server/services/openai.ts`
   - Uses gpt-4.1 model
   - Generates historical background, current political landscape, and root causes
   - Max 600 tokens, JSON response format

3. **AlertCard Component:** Updated `client/src/components/alert-card.tsx`
   - "Tell me more" button with Sparkles icon
   - Loading state with spinner when fetching
   - Button disappears after analysis is loaded
   - Card auto-expands when aiAnalysis exists (default expanded if pre-loaded)
   - Proper error handling with response.ok check and toast notifications

4. **Storage:** Added `updateAlertAnalysis(id, analysis)` method to IStorage, MemStorage, and DbStorage

## Recent Changes Made This Session:
1. **AI Usage Reduced by 90%+**: Default is keyword-based analysis (no AI). AI only used if `USE_AI_ANALYSIS=true` env var set.
2. **Newsletter Enabled**: Set to run daily at 3am EST (8am UTC via cron `0 8 * * *`)
3. **Newsletter Simplified to 3 sections**: Executive Summary, Travel Advisory, Coup Watch
4. **Alert auto-pruning**: System keeps only 2000 most recent alerts
5. **"Tell me more" feature**: On-demand AI analysis with caching

## Important Technical Details:
- OpenAI integration uses Replit AI Integrations: `AI_INTEGRATIONS_OPENAI_BASE_URL` and `AI_INTEGRATIONS_OPENAI_API_KEY`
- Monitor service at `server/services/monitor.ts` - `USE_KEYWORD_ANALYZER` defaults to true
- RSS feeds have retry logic with exponential backoff
- Translation has auto-fallback for unsupported language codes

## Database State:
- Newsletter enabled in `app_settings` table
- `alerts` table has `aiAnalysis` column for caching on-demand analysis
- ~2000 alerts in database (auto-pruned)

## Environment Variables Set:
- `NEWSLETTER_CRON_SCHEDULE=0 8 * * *` (3am EST)
