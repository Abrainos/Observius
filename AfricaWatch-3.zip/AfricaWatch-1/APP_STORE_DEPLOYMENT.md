# App Store Deployment Guide

This guide walks you through everything needed to publish AfricaWatch to Google Play Store and Apple App Store.

## ✅ What's Already Done

- ✅ Native Android and iOS apps built with Capacitor v7.4.3
- ✅ Push notifications configured (foreground-only)
- ✅ PWA manifest and service worker
- ✅ App bundle ID: `com.africawatch.monitor`
- ✅ Build scripts and Capacitor configuration
- ✅ Native projects synced and ready (`/android` and `/ios`)

## 📋 Pre-Deployment Checklist

### 1. App Icons (Required for Both Stores)

**What you need:**
- 1024x1024 PNG icon (no transparency, no rounded corners)
- High-quality, professional design representing security monitoring

**Where to create:**
- Use Canva, Figma, or hire a designer on Fiverr ($10-50)
- Free tool: https://www.canva.com/create/logos/

**Design tips:**
- Africa map silhouette with shield or alert symbol
- Bold, simple design that works at small sizes
- Use app brand colors (terracotta accent from design system)

**Installation:**
```bash
# Place your 1024x1024 icon in project root
# Then generate all sizes:
npx @capacitor/assets generate --iconBackgroundColor '#your-brand-color'
```

This auto-generates all required sizes for Android and iOS.

---

### 2. Screenshots (Required for Both Stores)

**Android Requirements:**
- 2-8 screenshots
- Minimum dimension: 320px
- Maximum dimension: 3840px
- Recommended: 1080x1920 (phone), 1200x1920 (tablet)

**iOS Requirements:**
- 2-10 screenshots per device size
- iPhone 6.7" (1290x2796) - **Required**
- iPhone 6.5" (1242x2688)
- iPad Pro 12.9" (2048x2732)

**How to capture:**
1. Run app on physical device or simulator
2. Navigate to key screens:
   - Dashboard with heat map
   - Alert list with critical incidents
   - Settings page
   - Alert history
3. Use device screenshot tools
4. Edit with borders/captions (optional but recommended)

**Screenshot editing tools:**
- Figma (free, professional mockups)
- Canva (easy templates)
- App Store Screenshot Generator: https://www.appstorescreenshot.com/

---

### 3. Privacy Policy (Required for Both Stores)

**What to include:**
- What data you collect (location data, alerts, user preferences)
- How data is used (security monitoring, notifications)
- Third-party services (OpenAI for analysis, Google Translate)
- Data retention and deletion
- Contact information

**Free privacy policy generators:**
- https://www.privacypolicies.com/
- https://app-privacy-policy-generator.firebaseapp.com/

**Important notes:**
- Must be hosted on public URL (not in app)
- Must be accessible without authentication
- Hosting options: GitHub Pages, Replit public URL, Google Sites

**Example privacy policy content:**

```markdown
# Privacy Policy for AfricaWatch

**Effective Date:** [Your Date]

## Information We Collect
- Geographic data (country monitoring preferences)
- Alert notifications preferences
- No personal identifiable information (PII) collected

## How We Use Your Information
- Monitor security incidents in selected African countries
- Deliver critical alert notifications
- Analyze news content using OpenAI GPT models
- Translate multilingual content using Google Translate

## Third-Party Services
- OpenAI (content analysis)
- Google Translate (language translation)
- RSS feed providers (news sources)

## Data Retention
- Alert data stored indefinitely for historical analysis
- User preferences stored locally on device

## Contact
[Your email address]
```

---

### 4. Google Play Store Submission

**Prerequisites:**
- Google Play Developer account ($25 one-time fee)
- Privacy policy URL
- App icons and screenshots
- Signed APK or AAB (Android App Bundle)

**Steps:**

#### 4.1 Create Developer Account
1. Go to https://play.google.com/console
2. Pay $25 registration fee
3. Complete developer profile

#### 4.2 Create App Listing
1. Click "Create app"
2. Fill in basic details:
   - App name: "AfricaWatch Security Monitor"
   - Default language: English
   - App or game: App
   - Free or paid: Free

#### 4.3 Build Signed APK
```bash
# 1. Build the app
npm run build
npx cap sync

# 2. Open in Android Studio
npx cap open android

# 3. In Android Studio:
# Build > Generate Signed Bundle / APK
# Create new keystore (SAVE THIS - you'll need it for updates!)
# Generate Release APK or AAB (AAB is recommended)
```

**Important:** Save your keystore file and passwords securely. You cannot update the app without them.

#### 4.4 Upload to Play Console
1. Go to "Production" track
2. Create new release
3. Upload AAB file
4. Complete app content:
   - Privacy policy URL
   - App category: Productivity or News
   - Content rating questionnaire
   - Target audience: 18+
5. Add screenshots
6. Write app description:

```
AfricaWatch is a real-time security monitoring system that tracks armed conflicts, protests, civil unrest, and security incidents across all 54 African countries.

Features:
• Real-time monitoring of 71+ news sources in multiple languages
• Interactive Africa heat map showing incident distribution
• Critical alert notifications for immediate threats
• Automatic translation from French, Arabic, and Portuguese
• Historical alert archive with search and filters
• Customizable monitoring intervals

Stay informed about security situations across Africa with AI-powered analysis and instant notifications.
```

7. Submit for review (takes 2-7 days)

---

### 5. Apple App Store Submission

**Prerequisites:**
- Apple Developer account ($99/year)
- macOS with Xcode installed
- Privacy policy URL
- App icons and screenshots

**Steps:**

#### 5.1 Create Developer Account
1. Go to https://developer.apple.com/
2. Enroll in Apple Developer Program ($99/year)
3. Complete account setup

#### 5.2 Create App ID
1. Go to developer.apple.com/account
2. Certificates, IDs & Profiles > Identifiers
3. Create new App ID:
   - Bundle ID: `com.africawatch.monitor` (matches capacitor.config.ts)
   - Enable Push Notifications capability

#### 5.3 Build iOS App
```bash
# 1. Build the app
npm run build
npx cap sync

# 2. Open in Xcode (requires macOS)
npx cap open ios

# 3. In Xcode:
# - Select "Product > Archive"
# - Click "Distribute App"
# - Choose "App Store Connect"
# - Upload to TestFlight
```

#### 5.4 Create App Store Listing
1. Go to https://appstoreconnect.apple.com/
2. Click "My Apps" > "+" > "New App"
3. Fill in details:
   - Name: "AfricaWatch Security Monitor"
   - Bundle ID: Select `com.africawatch.monitor`
   - SKU: "africawatch-monitor-001"
   - Category: News or Productivity

#### 5.5 Complete App Information
1. Upload screenshots for all required device sizes
2. Write app description (same as Android)
3. Add keywords: africa, security, monitoring, news, alerts
4. Privacy policy URL
5. Support URL (can be your GitHub repo or website)
6. Age rating: 17+ (news/violent content)

#### 5.6 Submit for Review
1. Upload build from Xcode
2. Complete App Review Information
3. Submit (takes 1-3 days)

---

## 🔒 Security & Compliance

### App Store Permissions You'll Need to Justify

**Android (AndroidManifest.xml):**
- `INTERNET` - Fetch news and alerts
- `POST_NOTIFICATIONS` - Send security alerts
- `RECEIVE_BOOT_COMPLETED` - Restart monitoring after device reboot

**iOS (Info.plist):**
- `NSUserNotificationsUsageDescription` - Send security alerts
- `NSLocationWhenInUseUsageDescription` - (if using geolocation in future)

### Content Rating Questionnaire

**Google Play:**
- Violence: Moderate (news about armed conflicts)
- News content: Yes
- Target age: 18+

**Apple App Store:**
- Age rating: 17+
- Reason: Frequent/Intense Realistic Violence (news content)

---

## 📊 Analytics & Monitoring (Optional)

Consider adding before submission:
- Google Analytics or Mixpanel for usage tracking
- Crashlytics for crash reporting
- Performance monitoring

Install:
```bash
npm install @capacitor-community/google-analytics
```

---

## 🧪 Pre-Submission Testing

### Test on Physical Devices

**Android:**
```bash
# Build and install on connected device
npm run build
npx cap sync
npx cap run android --target=<device-id>
```

**iOS:**
```bash
# Requires macOS and connected iPhone
npm run build
npx cap sync
npx cap run ios --target=<device-id>
```

### Test Checklist
- [ ] App installs successfully
- [ ] Push notifications work when app is active
- [ ] Heat map loads and displays correctly
- [ ] Alert list shows recent incidents
- [ ] Settings toggle for notifications works
- [ ] No console errors in production build
- [ ] App doesn't crash on orientation change
- [ ] Offline mode works (PWA caching)
- [ ] All links and navigation work
- [ ] Privacy policy link opens correctly

---

## 📱 Post-Deployment

### Version Updates
When releasing updates:
1. Increment version in `package.json`
2. Update version in `capacitor.config.ts`
3. Build and sync
4. Upload new APK/AAB to Play Console
5. Upload new build to App Store Connect

### Monitoring
- Check crash reports weekly
- Monitor user reviews and respond
- Track download numbers
- Update app every 2-3 months minimum

---

## 🎯 Quick Start Checklist

**Today:**
- [ ] Create app icon (1024x1024)
- [ ] Generate screenshots from app
- [ ] Write privacy policy and host it

**This Week:**
- [ ] Register for Google Play Developer account ($25)
- [ ] Build signed Android APK/AAB
- [ ] Create Play Store listing
- [ ] Submit for Android review

**This Month (if publishing to iOS):**
- [ ] Register for Apple Developer Program ($99/year)
- [ ] Access macOS with Xcode
- [ ] Build iOS app archive
- [ ] Create App Store Connect listing
- [ ] Submit for iOS review

---

## 💰 Total Costs

**Minimum (Android only):**
- Google Play Developer: $25 one-time
- **Total: $25**

**Both Platforms:**
- Google Play: $25 one-time
- Apple Developer: $99/year
- **Total: $124 first year, $99/year after**

**Optional:**
- App icon designer: $10-50
- Privacy policy generator: Free
- Screenshot editor: Free (Canva/Figma)

---

## 🆘 Common Issues

**"Keystore file not found"**
- You need to generate a keystore in Android Studio first
- Save it securely - you'll need it for all future updates

**"Bundle ID already exists"**
- Change `appId` in `capacitor.config.ts` to something unique
- Run `npx cap sync` again

**"iOS build fails"**
- Requires macOS with Xcode
- Run `pod install` in `/ios/App` folder
- Check Apple Developer certificate is valid

**"App rejected for permissions"**
- Provide clear justification for each permission
- Update privacy policy to explain data usage

---

## 📚 Additional Resources

- [Capacitor Deployment Guide](https://capacitorjs.com/docs/deployment)
- [Google Play Console Help](https://support.google.com/googleplay/android-developer)
- [App Store Connect Help](https://developer.apple.com/help/app-store-connect/)
- [Privacy Policy Template](https://www.privacypolicies.com/)

---

**Need Help?** 
- Capacitor Discord: https://discord.gg/UPYYRhtyzp
- Stack Overflow: Tag questions with `capacitor` or `ionic-framework`
