# AfricaWatch Mobile App Deployment Guide

## Overview

AfricaWatch is now configured as a native Android and iOS application using Capacitor. The same codebase powers the web app, Android app, and iOS app.

## Prerequisites

### For Android Development
- **Android Studio** (latest version)
- **Java Development Kit (JDK)** 17 or higher
- Android SDK installed via Android Studio

### For iOS Development (macOS only)
- **Xcode** 14+ (latest version)
- **macOS** (iOS apps can only be built on Mac)
- **CocoaPods** (install via: `sudo gem install cocoapods`)
- Apple Developer Account ($99/year for App Store publishing)

## Quick Start

### 1. Build the Web App

```bash
npm run build
```

This creates the production build in `dist/public/`.

### 2. Sync to Native Platforms

```bash
npx cap sync
```

This command:
- Copies web assets to Android/iOS projects
- Updates native dependencies
- Syncs Capacitor plugins

### 3. Open in Native IDE

**For Android:**
```bash
npx cap open android
```

**For iOS:**
```bash
npx cap open ios
```

## Development Workflow

### Making Changes

1. **Edit your code** in the React app (client/src)
2. **Build the app**: `npm run build`
3. **Sync changes**: `npx cap sync`
4. **Reload in native IDE** or rebuild

### Live Reload (Optional)

For faster development, you can point Capacitor to your dev server:

1. Start the dev server: `npm run dev`
2. Note the server URL (e.g., `https://your-repl.replit.dev`)
3. Update `capacitor.config.ts`:

```typescript
server: {
  url: 'https://your-repl.replit.dev',
  cleartext: true,
}
```

4. Run `npx cap sync` and rebuild the app

**Important:** Remove the `server.url` before building for production!

## Building for Production

### Android App

1. Open Android Studio: `npx cap open android`
2. Select **Build > Generate Signed Bundle / APK**
3. Choose **Android App Bundle** (recommended) or **APK**
4. Configure signing (create keystore if first time)
5. Build release version

**Command Line Build (Advanced):**
```bash
cd android
./gradlew assembleRelease
# APK will be in: app/build/outputs/apk/release/
```

### iOS App

1. Open Xcode: `npx cap open ios`
2. Select your development team in **Signing & Capabilities**
3. Configure bundle identifier: `com.africawatch.monitor`
4. Select **Product > Archive**
5. Upload to App Store Connect

## App Configuration

### App Name & Bundle ID

Edit `capacitor.config.ts`:

```typescript
const config: CapacitorConfig = {
  appId: 'com.africawatch.monitor',  // Change for your app
  appName: 'AfricaWatch',             // Display name
  webDir: 'dist/public',
  // ... other settings
};
```

### App Icons

Current icons are in `client/public/`:
- `pwa-192x192.png` - App icon (small)
- `pwa-512x512.png` - App icon (large)

**For higher quality icons:**

1. Create 1024x1024px PNG icon
2. Use [Capacitor Assets](https://github.com/ionic-team/capacitor-assets) to generate all sizes:

```bash
npm install -g @capacitor/assets
capacitor-assets generate --iconPath path/to/icon.png
```

This generates icons for both Android and iOS platforms.

### Splash Screen

Configure in `capacitor.config.ts`:

```typescript
plugins: {
  SplashScreen: {
    launchShowDuration: 2000,
    backgroundColor: "#0f172a",  // Match your app theme
    showSpinner: false,
  },
},
```

## Publishing to App Stores

### Google Play Store

1. Create Google Play Developer account ($25 one-time fee)
2. Build signed Android App Bundle (AAB)
3. Go to [Google Play Console](https://play.google.com/console)
4. Create new app and fill in details
5. Upload AAB file
6. Complete store listing (screenshots, description)
7. Submit for review

**Requirements:**
- Privacy policy URL
- App screenshots (phone + tablet)
- Feature graphic (1024x500)
- App description and category

### Apple App Store

1. Create Apple Developer account ($99/year)
2. Go to [App Store Connect](https://appstoreconnect.apple.com/)
3. Create new app with bundle ID: `com.africawatch.monitor`
4. Archive app in Xcode
5. Upload to App Store Connect
6. Complete app information and screenshots
7. Submit for review

**Requirements:**
- Privacy policy URL
- App screenshots (multiple device sizes)
- App description, keywords, category
- TestFlight testing (recommended)

## Updating the App

When you release updates:

1. **Build web app**: `npm run build`
2. **Sync platforms**: `npx cap sync`
3. **Increment version** in native projects:
   - Android: Update `versionCode` and `versionName` in `android/app/build.gradle`
   - iOS: Update version in Xcode project settings
4. **Build and publish** new version to stores

## Native Features

### Available Plugins

AfricaWatch can use Capacitor plugins for native features:

```typescript
import { App } from '@capacitor/app';
import { Network } from '@capacitor/network';
import { PushNotifications } from '@capacitor/push-notifications';
```

**Common plugins:**
- **Push Notifications**: Real-time alert notifications
- **Geolocation**: User location for proximity alerts
- **Network**: Offline detection
- **App**: App state, deep linking

Install plugins:
```bash
npm install @capacitor/push-notifications
npx cap sync
```

## Troubleshooting

### "Web assets directory must contain index.html"
- Ensure you ran `npm run build` first
- Check `capacitor.config.ts` has correct `webDir: 'dist/public'`

### Android build fails
- Clean project: `cd android && ./gradlew clean`
- Check Java version: `java -version` (need JDK 17+)
- Update Android SDK in Android Studio

### iOS build fails
- Update CocoaPods: `cd ios/App && pod install`
- Clean build folder in Xcode: Product > Clean Build Folder
- Check Xcode version (need 14+)

### Changes not showing in app
- Rebuild web assets: `npm run build`
- Sync: `npx cap sync`
- Clean native build and rebuild

## Useful Commands

```bash
# Build everything
npm run build && npx cap sync

# Open native IDEs
npx cap open android
npx cap open ios

# Sync after code changes
npx cap sync

# Update Capacitor
npm install @capacitor/cli@latest @capacitor/core@latest
npm install @capacitor/android@latest @capacitor/ios@latest
npx cap sync

# Check Capacitor doctor
npx cap doctor
```

## Resources

- **Capacitor Docs**: https://capacitorjs.com/docs
- **Android Publishing**: https://developer.android.com/distribute
- **iOS Publishing**: https://developer.apple.com/app-store/
- **Capacitor Community**: https://ionic.io/community

## Next Steps

1. ✅ Configure app icons and splash screens
2. ✅ Test on physical devices
3. ✅ Set up push notifications (optional)
4. ✅ Create store listings and screenshots
5. ✅ Submit to Google Play and App Store

Your AfricaWatch app is now ready for mobile deployment! 🚀
