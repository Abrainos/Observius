# Push Notifications Setup Guide

## Overview

AfricaWatch supports native push notifications for security alerts on Android and iOS devices. This implementation uses **foreground local notifications** which work while the app is active.

## Current Implementation

**Status**: Foreground Notifications ✅  
**Limitation**: Requires app to be open or running in background  

### What Works

- ✅ **Foreground Notifications** - Alerts while app is active
- ✅ **Severity-based Alerts** - Critical events trigger notifications
- ✅ **Global Monitoring** - Polls for new alerts every 60 seconds
- ✅ **In-app Settings** - Enable/disable with toggle
- ✅ **Platform Detection** - Web vs mobile detection
- ✅ **Permission Management** - Seamless permission flow
- ✅ **No Duplicates** - Tracks seen alerts to avoid spam

### What Doesn't Work (Yet)

- ❌ **Background Push** - No notifications when app is completely closed
- ❌ **Remote Delivery** - No server-side push (requires Firebase/APNs)

### Future Enhancement

For true background push notifications when the app is closed, you would need:
- Firebase Cloud Messaging (FCM) for Android
- Apple Push Notification service (APNs) for iOS  
- Backend integration to send pushes from monitoring service

See "Future Enhancements" section below for implementation guide.

## How It Works

### 1. Local Notifications (Implemented)

**Current Implementation:**
- App checks for new critical alerts periodically
- When detected, shows instant notification on device
- No external push service required
- Works offline after initial sync

**User Flow:**
1. User opens Settings page
2. Toggles "Enable Push Notifications"
3. App requests notification permission
4. User grants permission
5. Critical alerts trigger instant notifications

### 2. Remote Push Notifications (Future Enhancement)

For server-side push when app is closed, you would need:
- Firebase Cloud Messaging (FCM) for Android
- Apple Push Notification service (APNs) for iOS
- Backend service to send push messages

## Setup for Development

### Android Configuration

**No additional setup required!** Local notifications work out of the box.

For remote push (optional):
1. Create Firebase project at [Firebase Console](https://console.firebase.google.com/)
2. Download `google-services.json`
3. Place in `android/app/google-services.json`
4. Update `android/app/build.gradle` with FCM dependencies

### iOS Configuration

**No additional setup required!** Local notifications work out of the box.

For remote push (optional):
1. Enable Push Notifications capability in Xcode
2. Create APNs certificate in Apple Developer portal
3. Configure in your app's capabilities

## Testing Notifications

### In the Mobile App

1. **Build and run the app:**
   ```bash
   npm run build
   npx cap sync
   npx cap open android  # or ios
   ```

2. **Enable notifications:**
   - Open the app
   - Go to Settings
   - Toggle "Enable Push Notifications"
   - Grant permission when prompted

3. **Trigger a test notification:**
   - Monitor countries with recent activity (Nigeria, South Africa, Egypt)
   - Wait for monitoring cycle to run
   - Critical alerts will trigger notifications

### Manual Test

Add this code temporarily to test notifications:

```typescript
import { notificationService } from '@/lib/notifications';

// Test notification
await notificationService.scheduleLocalNotification(
  'Test Alert',
  'Critical security incident detected in Nigeria',
  'critical'
);
```

## Permissions

### Android

Declared in `android/app/src/main/AndroidManifest.xml`:
```xml
<uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
```

### iOS

Declared in `ios/App/App/Info.plist`:
```xml
<key>NSUserNotificationsUsageDescription</key>
<string>This app needs notification access to alert you of critical security incidents</string>
```

These are added automatically by Capacitor when you sync.

## Notification Behavior

### Severity Levels

| Severity | Behavior | Sound |
|----------|----------|-------|
| **Critical** | Instant notification | Alert sound |
| **High** | Notification | Default sound |
| **Moderate** | No notification | - |
| **Info** | No notification | - |

### Notification Format

**Title**: Alert title (e.g., "Armed Conflict in Nigeria")  
**Body**: Brief description of incident  
**Action**: Tap to open app and view details

## Code Structure

### Files

- `client/src/lib/notifications.ts` - Notification service
- `client/src/pages/settings.tsx` - Notification toggle UI
- `client/src/App.tsx` - Notification initialization

### Key Functions

```typescript
// Initialize notification listeners
await notificationService.initialize();

// Request permission
const granted = await notificationService.requestPermission();

// Send local notification
await notificationService.scheduleLocalNotification(
  'Alert Title',
  'Alert description',
  'critical'
);
```

## Future Enhancements

### 1. Remote Push Notifications

**Why:** Send alerts even when app is closed  
**Requirements:** Firebase (Android) + APNs (iOS)  
**Effort:** Medium (requires backend integration)

### 2. Notification Channels (Android)

**Why:** Users can customize notification sounds/vibration  
**Implementation:** Use `LocalNotifications.createChannel()`

### 3. Rich Notifications

**Why:** Show map preview, action buttons  
**Implementation:** Add `attachments` and `actions` to notifications

### 4. Background Refresh

**Why:** Fetch new alerts in background  
**Implementation:** Use `@capacitor/background-runner`

## Troubleshooting

### Notifications not appearing

1. **Check permissions:**
   - Android: Settings > Apps > AfricaWatch > Notifications
   - iOS: Settings > AfricaWatch > Notifications

2. **Verify platform:**
   - Open browser console and check for "Not a native platform" message
   - Notifications only work in native apps, not web

3. **Check logs:**
   - Android: Use Android Studio Logcat
   - iOS: Use Xcode Console

### Permission denied

- User must grant permission in device settings
- On iOS, permission prompt only appears once
- If denied, user must enable in system settings manually

### No critical alerts

- Ensure monitoring is active (check Settings)
- Verify countries with recent incidents are selected
- Wait for next monitoring cycle (default: 30 minutes)
- Use "Trigger Now" button in Settings to force immediate check

## Resources

- **Capacitor Push Notifications**: https://capacitorjs.com/docs/apis/push-notifications
- **Local Notifications**: https://capacitorjs.com/docs/apis/local-notifications
- **Firebase Cloud Messaging**: https://firebase.google.com/docs/cloud-messaging
- **APNs Guide**: https://developer.apple.com/documentation/usernotifications

## Summary

AfricaWatch now delivers instant mobile notifications for critical security alerts. The current implementation uses local notifications which work immediately without external services. For production, consider implementing remote push notifications for alerts when the app is closed.

Your users will never miss a critical security incident! 🔔
