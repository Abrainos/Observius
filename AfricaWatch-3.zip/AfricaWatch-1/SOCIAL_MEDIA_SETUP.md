# Social Media Monitoring Setup Guide

AfricaWatch now includes **social media monitoring** to complement traditional news sources! This guide explains how to enable and configure social media integrations.

## 🌐 Available Social Media Sources

### 1. **Twitter/X API** (Recommended)
**Status:** ✅ Implemented  
**Cost:** $200/month minimum (Basic tier) or use free alternatives  
**Best for:** Real-time security updates, breaking news, trending topics

#### Setup Instructions:

1. **Get Twitter API Access:**
   - **Option A (Official):** Go to https://developer.x.com/ and apply for API access
     - Free tier: Write-only (not useful for monitoring)
     - Basic: $200/month - 10K tweets/month with read access
     - Pro: $5,000/month - 1M tweets/month

   - **Option B (Cheaper Alternative):** Use TwitterAPI.io or similar services
     - Pay-as-you-go pricing (up to 97% cheaper)
     - Visit https://twitterapi.io for details

2. **Configure AfricaWatch:**
   ```bash
   # Add your Twitter Bearer Token to environment
   TWITTER_BEARER_TOKEN=your_bearer_token_here
   ```

3. **Restart the application** - Twitter monitoring will activate automatically

---

### 2. **NewsAPI**
**Status:** ✅ Implemented  
**Cost:** FREE tier available (100 requests/day)  
**Best for:** Aggregated news from 80,000+ sources worldwide

#### Setup Instructions:

1. **Get API Key:**
   - Visit https://newsapi.org/
   - Sign up for free account
   - Get your API key from dashboard

2. **Configure AfricaWatch:**
   ```bash
   # Add NewsAPI key to environment
   NEWSAPI_KEY=your_api_key_here
   ```

3. **Restart the application** - NewsAPI will be included in monitoring cycles

---

### 3. **Reddit**
**Status:** ⚠️ Partially Implemented  
**Current Issue:** Reddit blocks automated scraping (403 errors)  
**Potential Solution:** Implement Reddit OAuth authentication (requires user setup)

#### Disable Reddit Scraping:
If Reddit continues to fail and clutter logs, disable it with:
```bash
DISABLE_REDDIT_SCRAPING=true
```

#### Current Coverage:
AfricaWatch attempts to monitor these subreddits for security keywords:
- r/Africa
- r/africanews
- r/Nigeria, r/Kenya, r/SouthAfrica
- r/Ethiopia, r/Somalia, r/Sudan, r/DRC, r/Egypt
- r/sahel (Sahel region security)
- r/geopolitics

#### How to Enable (Future):
When Reddit OAuth is implemented, users will need to:
1. Create a Reddit app at https://www.reddit.com/prefs/apps
2. Get client ID and secret
3. Configure environment variables

---

## 📊 How Social Media Monitoring Works

### Content Collection
1. **Traditional News Sites** - Scraped every monitoring cycle (30 min default)
2. **Reddit** - Filtered by security keywords (conflict, violence, protest, etc.)
3. **NewsAPI** - Search for African security news in English
4. **Twitter/X** - Real-time tweets about African security incidents

### AI Analysis
All content (news + social media) is analyzed by GPT-5 to:
- Determine relevance to African security
- Extract incident location and country
- Classify severity (Critical, High, Moderate, Info)
- Generate structured alerts

### Alert Generation
Only relevant content becomes alerts:
- **Critical:** Armed conflicts, military combat, terrorist attacks
- **High:** Protests with violence, militant activity
- **Moderate:** Political instability, military movements
- **Info:** Security advisories, general concerns

---

## 🔧 Configuration Tips

### Balancing Cost & Coverage

**Free Tier Setup:**
```bash
# NewsAPI only (100 requests/day - plenty for 30min intervals)
NEWSAPI_KEY=your_key_here
```

**Budget Setup (~$50/month):**
```bash
# NewsAPI + cheaper Twitter alternative
NEWSAPI_KEY=your_key_here
TWITTER_BEARER_TOKEN=twitterapi_io_token
```

**Premium Setup ($200+/month):**
```bash
# NewsAPI + Official Twitter Basic
NEWSAPI_KEY=your_key_here
TWITTER_BEARER_TOKEN=official_twitter_bearer
```

### Monitoring Frequency
Adjust monitoring interval to manage API costs:
```bash
# More frequent = more API calls = higher cost
MONITORING_INTERVAL_MINUTES=30  # Default
MONITORING_INTERVAL_MINUTES=60  # Hourly (saves API calls)
MONITORING_INTERVAL_MINUTES=120 # Every 2 hours (minimal usage)
```

---

## 📈 Expected Results

With social media enabled, you should see:

```
[MONITOR] Scraped 9 articles from news sites
[MONITOR] Fetched 15 posts from Reddit
[MONITOR] Fetched 12 articles from NewsAPI
[MONITOR] Fetched 18 tweets from Twitter/X
[MONITOR] Total content to analyze: 54 items
```

Alerts from social media will be tagged with their source:
- `Twitter (@username)` - From Twitter/X
- `Reddit (r/subreddit)` - From Reddit posts
- `NewsAPI source` - From NewsAPI articles

---

## 🚨 Current Limitations

1. **Reddit** - Currently blocked by anti-bot protection (returns 0 posts)
2. **Twitter** - Requires paid API access ($200/month minimum for official API)
3. **Rate Limits** - Be mindful of API quotas when setting monitoring frequency

---

## 🛠️ Troubleshooting

### No social media content?
Check logs for:
- `[NewsAPI] API key not configured` → Add NEWSAPI_KEY
- `[Twitter] Bearer token not configured` → Add TWITTER_BEARER_TOKEN
- `[Reddit] Request failed with status code 403` → Reddit blocking (known issue)

### API errors?
- `401 Unauthorized` → Check your API keys are correct
- `429 Rate limit exceeded` → Reduce monitoring frequency or upgrade API tier
- `403 Forbidden` → Service blocking requests (use different User-Agent or authentication)

---

## 🌍 Why Social Media Matters for Security Monitoring

Social media provides:
1. **Real-time updates** - News often hours/days behind social media
2. **Local perspectives** - Direct reports from affected areas
3. **Trend detection** - Identify emerging threats before media coverage
4. **Broader coverage** - Stories too small for traditional news

Combining traditional news + social media gives the most complete security picture!
