package com.africawatch.monitor;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
