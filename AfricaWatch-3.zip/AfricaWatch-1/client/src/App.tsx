import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { ThemeProvider } from "@/components/theme-provider";
import { ThemeToggle } from "@/components/theme-toggle";
import { AppSidebar } from "@/components/app-sidebar";
import { PWAInstallPrompt } from "@/components/pwa-install-prompt";
import { NotificationProvider, useNotificationSettings } from "@/contexts/notification-context";
import { RegionProvider, useRegion } from "@/contexts/region-context";
import { TranslationProvider } from "@/contexts/translation-context";
import Dashboard from "@/pages/dashboard";
import AlertHistory from "@/pages/alert-history";
import Settings from "@/pages/settings";
import AdminNewsletter from "@/pages/admin-newsletter";
import AdminLogin from "@/pages/admin-login";
import Unsubscribe from "@/pages/unsubscribe";
import NotFound from "@/pages/not-found";
import { useState, useEffect } from "react";
import { countriesByRegion, type MonitoredCountry } from "@shared/schema";
import { notificationService } from "@/lib/notifications";
import { useAlertNotifications } from "@/hooks/use-alert-notifications";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";

function MainApp() {
  const [selectedCountries, setSelectedCountries] = useState<string[]>([]);
  const { notificationsEnabled } = useNotificationSettings();
  const { selectedRegion } = useRegion();

  // Load monitored countries from database for the selected region
  const { data: monitoredCountries = [] } = useQuery<MonitoredCountry[]>({
    queryKey: ["/api/monitored-countries", selectedRegion],
    queryFn: async () => {
      const response = await fetch(`/api/monitored-countries?region=${selectedRegion}`, {
        credentials: 'include',
      });
      if (!response.ok) throw new Error('Failed to fetch monitored countries');
      return response.json();
    },
  });

  // Sync selectedCountries with monitored countries from database
  useEffect(() => {
    const enabledCountries = monitoredCountries
      .filter(mc => mc.enabled)
      .map(mc => mc.country);
    
    // Only update if different to avoid unnecessary re-renders
    if (JSON.stringify(enabledCountries.sort()) !== JSON.stringify(selectedCountries.sort())) {
      setSelectedCountries(enabledCountries);
    }
  }, [monitoredCountries]);

  // Initialize notification service on mount
  useEffect(() => {
    notificationService.initialize().catch(console.error);
  }, []);

  // Global notification monitoring (runs regardless of which page user is on)
  useAlertNotifications({
    enabled: notificationsEnabled,
    pollInterval: 60000 // Poll every minute
  });

  // Mutation for adding a country
  const addCountryMutation = useMutation({
    mutationFn: async (country: string) => {
      return await apiRequest("POST", "/api/monitored-countries", { country, region: selectedRegion, enabled: true });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/monitored-countries", selectedRegion] });
    },
  });

  // Mutation for removing a country
  const removeCountryMutation = useMutation({
    mutationFn: async (countryId: string) => {
      return await apiRequest("DELETE", `/api/monitored-countries/${countryId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/monitored-countries", selectedRegion] });
    },
  });

  const handleToggleCountry = (country: string) => {
    const isCurrentlySelected = selectedCountries.includes(country);
    
    // Optimistically update UI state only
    setSelectedCountries((prev) =>
      isCurrentlySelected
        ? prev.filter((c) => c !== country)
        : [...prev, country]
    );
    
    if (isCurrentlySelected) {
      // Find and remove from database
      const countryToDelete = monitoredCountries.find(mc => mc.country === country);
      if (countryToDelete) {
        removeCountryMutation.mutate(countryToDelete.id);
      }
    } else {
      // Add to database
      addCountryMutation.mutate(country);
    }
  };

  const handleSelectAll = () => {
    const regionCountries = countriesByRegion[selectedRegion];
    // Check if ALL region countries are selected (not just length)
    const allCurrentlySelected = regionCountries.every(country => selectedCountries.includes(country));
    const shouldSelectAll = !allCurrentlySelected;
    
    // Optimistically update UI
    setSelectedCountries(shouldSelectAll ? [...regionCountries] : []);
    
    if (shouldSelectAll) {
      // Add all countries that aren't already monitored
      const monitoredCountryNames = monitoredCountries.map(mc => mc.country);
      const countriesToAdd = regionCountries.filter(c => !monitoredCountryNames.includes(c));
      countriesToAdd.forEach(country => addCountryMutation.mutate(country));
    } else {
      // Remove all monitored countries
      monitoredCountries.forEach(mc => removeCountryMutation.mutate(mc.id));
    }
  };

  // Custom sidebar width for better country list display
  const sidebarStyle = {
    "--sidebar-width": "20rem",
    "--sidebar-width-icon": "4rem",
  } as React.CSSProperties;

  return (
    <>
      <SidebarProvider style={sidebarStyle}>
        <div className="flex h-screen w-full">
          <AppSidebar
            selectedCountries={selectedCountries}
            onToggleCountry={handleToggleCountry}
            onSelectAll={handleSelectAll}
          />
          <div className="flex flex-col flex-1 overflow-hidden">
            <header className="flex items-center justify-between p-4 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
              <div className="flex items-center gap-2">
                <SidebarTrigger data-testid="button-sidebar-toggle" />
                <div className="hidden sm:block">
                  <h1 className="text-sm font-semibold" data-testid="text-header-title">
                    Observius
                  </h1>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <ThemeToggle />
              </div>
            </header>
            <main className="flex-1 overflow-auto">
              <div className="container max-w-5xl mx-auto p-6">
                <Switch>
                  <Route path="/">
                    <Dashboard selectedCountries={selectedCountries} />
                  </Route>
                  <Route path="/history">
                    <AlertHistory selectedCountries={selectedCountries} />
                  </Route>
                  <Route path="/settings">
                    <Settings />
                  </Route>
                  <Route path="/admin/login">
                    <AdminLogin />
                  </Route>
                  <Route path="/admin/newsletter">
                    <AdminNewsletter />
                  </Route>
                  <Route path="/unsubscribe/:token">
                    <Unsubscribe />
                  </Route>
                  <Route component={NotFound} />
                </Switch>
              </div>
            </main>
          </div>
        </div>
      </SidebarProvider>
      <Toaster />
      <PWAInstallPrompt />
    </>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ThemeProvider defaultTheme="dark">
          <NotificationProvider>
            <TranslationProvider>
              <RegionProvider>
                <MainApp />
              </RegionProvider>
            </TranslationProvider>
          </NotificationProvider>
        </ThemeProvider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
