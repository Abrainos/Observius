import { useMemo } from "react";
import { ComposableMap, Geographies, Geography, Marker } from "react-simple-maps";
import { scaleLinear } from "d3-scale";
import { geoCentroid } from "d3-geo";
import { type Alert } from "@shared/schema";
import { MapPin, AlertTriangle } from "lucide-react";
import { severityWeights } from "@/lib/geo-data";

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

interface AfricaHeatMapProps {
  alerts: Alert[];
  onCountryClick?: (country: string) => void;
}

// Map country names to ISO numeric codes (used in world-atlas)
const countryNameToIsoNum: Record<string, string> = {
  "Algeria": "012", "Angola": "024", "Benin": "204", "Botswana": "072",
  "Burkina Faso": "854", "Burundi": "108", "Cabo Verde": "132", "Cameroon": "120",
  "Central African Republic": "140", "Chad": "148", "Comoros": "174", "Congo": "178",
  "Democratic Republic of Congo": "180", "Djibouti": "262", "Egypt": "818",
  "Equatorial Guinea": "226", "Eritrea": "232", "Eswatini": "748", "Ethiopia": "231",
  "Gabon": "266", "Gambia": "270", "Ghana": "288", "Guinea": "324",
  "Guinea-Bissau": "624", "Ivory Coast": "384", "Kenya": "404", "Lesotho": "426",
  "Liberia": "430", "Libya": "434", "Madagascar": "450", "Malawi": "454",
  "Mali": "466", "Mauritania": "478", "Mauritius": "480", "Morocco": "504",
  "Mozambique": "508", "Namibia": "516", "Niger": "562", "Nigeria": "566",
  "Rwanda": "646", "Sao Tome and Principe": "678", "Senegal": "686",
  "Seychelles": "690", "Sierra Leone": "694", "Somalia": "706", "South Africa": "710",
  "South Sudan": "728", "Sudan": "729", "Tanzania": "834", "Togo": "768",
  "Tunisia": "788", "Uganda": "800", "Zambia": "894", "Zimbabwe": "716",
};

// Abbreviated country names for map labels
const countryAbbreviations: Record<string, string> = {
  "Central African Republic": "CAR",
  "Democratic Republic of Congo": "DRC",
  "South Africa": "S. Africa",
  "South Sudan": "S. Sudan",
  "Burkina Faso": "B. Faso",
  "Equatorial Guinea": "Eq. Guinea",
  "Guinea-Bissau": "G-Bissau",
  "Sao Tome and Principe": "STP",
  "Sierra Leone": "S. Leone",
};

export function AfricaHeatMap({ alerts, onCountryClick }: AfricaHeatMapProps) {
  // Calculate heat intensity per country
  const countryHeatData = useMemo(() => {
    const heatMap = new Map<string, { score: number; count: number; maxSeverity: string }>();

    alerts.forEach((alert) => {
      const isoNum = countryNameToIsoNum[alert.country];
      if (!isoNum) return;

      const weight = severityWeights[alert.severity] || 1;
      const existing = heatMap.get(isoNum) || { score: 0, count: 0, maxSeverity: "info" };

      const newSeverity = severityWeights[alert.severity] > severityWeights[existing.maxSeverity]
        ? alert.severity
        : existing.maxSeverity;

      heatMap.set(isoNum, {
        score: existing.score + weight,
        count: existing.count + 1,
        maxSeverity: newSeverity,
      });
    });

    return heatMap;
  }, [alerts]);

  // Calculate max score for color scaling
  const maxScore = useMemo(() => {
    let max = 0;
    countryHeatData.forEach((data) => {
      if (data.score > max) max = data.score;
    });
    return max || 1;
  }, [countryHeatData]);

  // Color scale from light to dark based on intensity
  const colorScale = scaleLinear<string>()
    .domain([0, maxScore / 2, maxScore])
    .range(["hsl(var(--muted))", "hsl(25 95% 53%)", "hsl(0 84% 60%)"])
    .clamp(true);

  const getCountryColor = (id: string): string => {
    const data = countryHeatData.get(id);
    if (!data) return "hsl(var(--muted))";
    return colorScale(data.score);
  };

  const getCountryInfo = (id: string) => {
    return countryHeatData.get(id);
  };

  // African country ISO numeric codes for filtering
  const africanCountries = new Set(Object.values(countryNameToIsoNum));

  return (
    <div className="w-full" data-testid="heat-map-container">
      <div className="bg-card rounded-lg border shadow-sm">
        <div className="p-4 border-b">
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            <h3 className="font-semibold">Africa Instability Heat Map</h3>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Geographic distribution of protests, instability, and security incidents
          </p>
        </div>
        <div className="relative bg-muted/30 !h-[500px] md:!h-[700px] lg:!h-[800px] w-full overflow-hidden" data-testid="map-canvas">
          <ComposableMap
            projection="geoMercator"
            projectionConfig={{
              scale: 713,
              center: [20, 5],
            }}
            width={1200}
            height={800}
            style={{ width: '100%', height: '100%' }}
          >
            <Geographies geography={geoUrl}>
              {({ geographies }) => {
                const filteredGeographies = geographies.filter((geo) => africanCountries.has(geo.id));
                
                return (
                  <>
                    {filteredGeographies.map((geo) => {
                      const countryInfo = getCountryInfo(geo.id);
                      const countryName = Object.keys(countryNameToIsoNum).find(
                        (key) => countryNameToIsoNum[key] === geo.id
                      );

                      return (
                        <Geography
                          key={geo.rsmKey}
                          geography={geo}
                          fill={getCountryColor(geo.id)}
                          stroke="hsl(var(--foreground) / 0.7)"
                          strokeWidth={2.0}
                          style={{
                            default: { 
                              outline: "none",
                              strokeWidth: 2.0,
                            },
                            hover: {
                              fill: "hsl(var(--primary))",
                              outline: "none",
                              cursor: "pointer",
                              strokeWidth: 2.5,
                              stroke: "hsl(var(--foreground) / 0.9)",
                            },
                            pressed: { 
                              outline: "none",
                              strokeWidth: 2.0,
                            },
                          }}
                          onClick={() => countryName && onCountryClick?.(countryName)}
                          data-testid={`map-country-${geo.id}`}
                        >
                          <title>
                            {countryName || "Unknown"}
                            {countryInfo
                              ? `\n${countryInfo.count} alert${countryInfo.count > 1 ? 's' : ''}\nMax Severity: ${countryInfo.maxSeverity}`
                              : '\nNo alerts'}
                          </title>
                        </Geography>
                      );
                    })}
                  </>
                );
              }}
            </Geographies>
            {/* Country Name Labels */}
            <Geographies geography={geoUrl}>
              {({ geographies }) =>
                geographies
                  .filter((geo) => africanCountries.has(geo.id))
                  .map((geo) => {
                    const centroid = geoCentroid(geo);
                    const countryName = Object.keys(countryNameToIsoNum).find(
                      (key) => countryNameToIsoNum[key] === geo.id
                    );
                    const displayName = countryName ? (countryAbbreviations[countryName] || countryName) : "";

                    return (
                      <Marker key={`${geo.rsmKey}-label`} coordinates={centroid}>
                        <text
                          textAnchor="middle"
                          style={{
                            fontSize: "11px",
                            fontWeight: 600,
                            fill: "hsl(var(--foreground))",
                            stroke: "hsl(var(--background))",
                            strokeWidth: "3px",
                            paintOrder: "stroke",
                            pointerEvents: "none",
                            userSelect: "none",
                          }}
                        >
                          {displayName}
                        </text>
                      </Marker>
                    );
                  })
              }
            </Geographies>
          </ComposableMap>

          {/* Legend */}
          <div className="absolute bottom-4 right-4 bg-background/95 backdrop-blur border rounded-lg p-3 space-y-2">
            <div className="text-xs font-semibold flex items-center gap-1">
              <AlertTriangle className="h-3 w-3" />
              Intensity
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs">
                <div className="w-4 h-4 rounded-sm" style={{ backgroundColor: "hsl(0 84% 60%)" }} />
                <span>High</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <div className="w-4 h-4 rounded-sm" style={{ backgroundColor: "hsl(25 95% 53%)" }} />
                <span>Medium</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <div className="w-4 h-4 rounded-sm bg-muted" />
                <span>Low/None</span>
              </div>
            </div>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-4 p-4 border-t bg-muted/20">
          <div className="text-center">
            <p className="text-2xl font-bold" data-testid="stat-countries-affected">
              {countryHeatData.size}
            </p>
            <p className="text-xs text-muted-foreground">Countries Affected</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold" data-testid="stat-total-alerts">
              {alerts.length}
            </p>
            <p className="text-xs text-muted-foreground">Total Alerts</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold" data-testid="stat-critical-alerts">
              {alerts.filter((a) => a.severity === "critical").length}
            </p>
            <p className="text-xs text-muted-foreground">Critical Incidents</p>
          </div>
        </div>
      </div>
    </div>
  );
}
