import { type Alert } from "@shared/schema";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, ExternalLink, ChevronDown, ChevronUp, Globe2, Map, Languages, Sparkles, Loader2 } from "lucide-react";
import { getSeverityConfig, formatTimestamp, cn } from "@/lib/utils";
import { useState } from "react";
import { LocationMapDialog } from "./location-map-dialog";
import { useTranslationSettings } from "@/contexts/translation-context";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AlertCardProps {
  alert: Alert;
  onViewDetails?: (alert: Alert) => void;
}

export function AlertCard({ alert, onViewDetails }: AlertCardProps) {
  const [expanded, setExpanded] = useState(!!alert.aiAnalysis);
  const [showLocationMap, setShowLocationMap] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState<string | null>(alert.aiAnalysis || null);
  const [isLoadingAnalysis, setIsLoadingAnalysis] = useState(false);
  const { showOriginalLanguage } = useTranslationSettings();
  const { toast } = useToast();
  const severityConfig = getSeverityConfig(alert.severity);

  const handleTellMeMore = async () => {
    if (aiAnalysis || isLoadingAnalysis) return;
    
    setIsLoadingAnalysis(true);
    try {
      const response = await apiRequest("POST", `/api/alerts/${alert.id}/analyze`);
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || "Service unavailable");
      }
      const data = await response.json();
      if (data.analysis) {
        setAiAnalysis(data.analysis);
        setExpanded(true);
      } else {
        toast({
          title: "Analysis unavailable",
          description: "Could not generate analysis for this alert.",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error("Failed to fetch analysis:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to load analysis. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoadingAnalysis(false);
    }
  };
  
  // Check if location coordinates are available
  const hasLocationData = alert.latitude && alert.longitude;

  // Determine which text to display based on user preference and availability
  const displayTitle = (showOriginalLanguage && alert.wasTranslated && alert.originalTitle) 
    ? alert.originalTitle 
    : alert.title;
  
  const displayDescription = (showOriginalLanguage && alert.wasTranslated && alert.originalDescription)
    ? alert.originalDescription
    : alert.description;
  
  // Show language badge if displaying original language
  const showLanguageBadge = showOriginalLanguage && alert.wasTranslated && alert.detectedLanguage;

  return (
    <Card 
      className={cn(
        "hover-elevate transition-all duration-200",
        severityConfig.bgClass
      )}
      data-testid={`card-alert-${alert.id}`}
    >
      <CardHeader className="pb-3 space-y-2">
        <div className="flex items-start justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge 
              variant="outline" 
              className={cn("font-mono text-xs", severityConfig.badgeClass)}
              data-testid={`badge-severity-${alert.id}`}
            >
              {severityConfig.label}
            </Badge>
            {showLanguageBadge && (
              <Badge 
                variant="outline" 
                className="text-xs gap-1"
                data-testid={`badge-language-${alert.id}`}
              >
                <Languages className="h-3 w-3" />
                {alert.detectedLanguage?.toUpperCase()}
              </Badge>
            )}
            <div className="flex items-center gap-1.5 text-sm">
              <Globe2 className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="font-medium" data-testid={`text-country-${alert.id}`}>
                {alert.country}
              </span>
            </div>
          </div>
          <time 
            className="text-xs text-muted-foreground font-mono"
            dateTime={new Date(alert.timestamp).toISOString()}
            data-testid={`text-timestamp-${alert.id}`}
          >
            {formatTimestamp(alert.timestamp)}
          </time>
        </div>

        <h3 className="text-base font-semibold leading-tight" data-testid={`text-title-${alert.id}`}>
          {displayTitle}
        </h3>
      </CardHeader>

      <CardContent className="space-y-3">
        <div className="flex items-start gap-2">
          <MapPin className="h-4 w-4 mt-0.5 text-muted-foreground flex-shrink-0" />
          <p className="text-sm font-medium" data-testid={`text-location-${alert.id}`}>
            {alert.location}
          </p>
        </div>

        <p className="text-sm text-muted-foreground leading-relaxed" data-testid={`text-description-${alert.id}`}>
          {displayDescription}
        </p>

        {expanded && (
          <div className="space-y-3 pt-2 border-t">
            {alert.violenceDetails && (
              <div className="space-y-1">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Violence Details
                </p>
                <p className="text-sm" data-testid={`text-violence-${alert.id}`}>
                  {alert.violenceDetails}
                </p>
              </div>
            )}

            {alert.policeIntervention && (
              <div className="space-y-1">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Police Intervention
                </p>
                <p className="text-sm" data-testid={`text-police-${alert.id}`}>
                  {alert.policeIntervention}
                </p>
              </div>
            )}

            {aiAnalysis && (
              <div className="space-y-1">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Historical Context
                </p>
                <p className="text-sm text-muted-foreground" data-testid={`text-analysis-${alert.id}`}>
                  {aiAnalysis}
                </p>
              </div>
            )}
          </div>
        )}

        <div className="flex items-center justify-between gap-2 pt-2 flex-wrap">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="secondary" className="text-xs font-normal" data-testid={`badge-source-${alert.id}`}>
              {alert.source}
            </Badge>
            {alert.sourceUrl && (
              <Button
                variant="ghost"
                size="sm"
                asChild
                className="h-7 gap-1 text-xs"
                data-testid={`link-source-${alert.id}`}
              >
                <a href={alert.sourceUrl} target="_blank" rel="noopener noreferrer">
                  <ExternalLink className="h-3 w-3" />
                  View Source
                </a>
              </Button>
            )}
            {hasLocationData && (
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setShowLocationMap(true)}
                className="h-7 gap-1 text-xs"
                data-testid={`button-view-location-${alert.id}`}
              >
                <Map className="h-3 w-3" />
                View Location
              </Button>
            )}
            {!aiAnalysis && (
              <Button
                variant="ghost"
                size="sm"
                onClick={handleTellMeMore}
                disabled={isLoadingAnalysis}
                className="h-7 gap-1 text-xs"
                data-testid={`button-tell-me-more-${alert.id}`}
              >
                {isLoadingAnalysis ? (
                  <>
                    <Loader2 className="h-3 w-3 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Sparkles className="h-3 w-3" />
                    Tell me more
                  </>
                )}
              </Button>
            )}
          </div>

          <Button
            variant="ghost"
            size="sm"
            onClick={() => setExpanded(!expanded)}
            className="h-7 gap-1 text-xs"
            data-testid={`button-expand-${alert.id}`}
          >
            {expanded ? (
              <>
                <ChevronUp className="h-3 w-3" />
                Show Less
              </>
            ) : (
              <>
                <ChevronDown className="h-3 w-3" />
                Show More
              </>
            )}
          </Button>
        </div>
      </CardContent>

      <LocationMapDialog
        open={showLocationMap}
        onOpenChange={setShowLocationMap}
        location={alert.location}
        country={alert.country}
        latitude={alert.latitude}
        longitude={alert.longitude}
        title={alert.title}
      />
    </Card>
  );
}
