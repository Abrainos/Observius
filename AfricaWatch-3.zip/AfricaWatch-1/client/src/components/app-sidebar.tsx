import { Home, History, Settings, Bell, Globe } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
} from "@/components/ui/sidebar";
import { CountrySelector } from "@/components/country-selector";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useRegion } from "@/contexts/region-context";

interface AppSidebarProps {
  selectedCountries: string[];
  onToggleCountry: (country: string) => void;
  onSelectAll: () => void;
  alertCount?: number;
}

export function AppSidebar({
  selectedCountries,
  onToggleCountry,
  onSelectAll,
  alertCount = 0,
}: AppSidebarProps) {
  const [location, setLocation] = useLocation();
  const { selectedRegion, setSelectedRegion } = useRegion();
  
  const { data: settings } = useQuery<{ intervalMinutes: number }>({
    queryKey: ["/api/settings/monitoring"],
  });

  // Handler for region selection - sets region and navigates to Dashboard
  const handleRegionSelect = (region: typeof selectedRegion) => {
    setSelectedRegion(region);
    setLocation("/"); // Navigate to Dashboard
  };

  const navItems = [
    {
      title: "Dashboard",
      url: "/",
      icon: Home,
      badge: alertCount > 0 ? alertCount : undefined,
    },
    {
      title: "Alert History",
      url: "/history",
      icon: History,
    },
    {
      title: "Settings",
      url: "/settings",
      icon: Settings,
    },
  ];

  return (
    <Sidebar>
      <SidebarHeader className="border-b px-4 py-4">
        <div className="flex items-center gap-2 mb-3">
          <div className="h-8 w-8 rounded-md bg-primary flex items-center justify-center">
            <Bell className="h-5 w-5 text-primary-foreground" />
          </div>
          <div>
            <h2 className="text-sm font-bold" data-testid="text-app-title">
              Observius
            </h2>
            <p className="text-xs text-muted-foreground">Global Event Monitor</p>
          </div>
        </div>
        
        {/* Region Selector */}
        <div className="grid grid-cols-2 gap-1">
          <Button
            variant={selectedRegion === "africa" ? "default" : "outline"}
            size="sm"
            className="text-xs h-8"
            onClick={() => handleRegionSelect("africa")}
            data-testid="button-region-africa"
          >
            <Globe className="h-3 w-3 mr-1" />
            Africa
          </Button>
          <Button
            variant={selectedRegion === "asia" ? "default" : "outline"}
            size="sm"
            className="text-xs h-8"
            onClick={() => handleRegionSelect("asia")}
            data-testid="button-region-asia"
          >
            <Globe className="h-3 w-3 mr-1" />
            Asia
          </Button>
          <Button
            variant={selectedRegion === "europe" ? "default" : "outline"}
            size="sm"
            className="text-xs h-8"
            onClick={() => handleRegionSelect("europe")}
            data-testid="button-region-europe"
          >
            <Globe className="h-3 w-3 mr-1" />
            Europe
          </Button>
          <Button
            variant={selectedRegion === "middleeast" ? "default" : "outline"}
            size="sm"
            className="text-xs h-8"
            onClick={() => handleRegionSelect("middleeast")}
            data-testid="button-region-middleeast"
          >
            <Globe className="h-3 w-3 mr-1" />
            M.East
          </Button>
          <Button
            variant={selectedRegion === "southamerica" ? "default" : "outline"}
            size="sm"
            className="text-xs h-8"
            onClick={() => handleRegionSelect("southamerica")}
            data-testid="button-region-southamerica"
          >
            <Globe className="h-3 w-3 mr-1" />
            S.America
          </Button>
          <Button
            variant={selectedRegion === "northamerica" ? "default" : "outline"}
            size="sm"
            className="text-xs h-8"
            onClick={() => handleRegionSelect("northamerica")}
            data-testid="button-region-northamerica"
          >
            <Globe className="h-3 w-3 mr-1" />
            N.America
          </Button>
          <Button
            variant={selectedRegion === "centralsouthasia" ? "default" : "outline"}
            size="sm"
            className="text-xs h-8 col-span-2"
            onClick={() => handleRegionSelect("centralsouthasia")}
            data-testid="button-region-centralsouthasia"
          >
            <Globe className="h-3 w-3 mr-1" />
            Central/South Asia
          </Button>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupLabel>Navigation</SidebarGroupLabel>
          <SidebarGroupContent>
            <SidebarMenu>
              {navItems.map((item) => {
                const isActive = location === item.url;
                return (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton asChild isActive={isActive}>
                      <Link href={item.url} data-testid={`link-${item.title.toLowerCase().replace(/\s+/g, '-')}`}>
                        <item.icon className="h-4 w-4" />
                        <span>{item.title}</span>
                        {item.badge !== undefined && (
                          <Badge 
                            variant="destructive" 
                            className="ml-auto h-5 px-1.5 text-xs"
                            data-testid="badge-alert-count"
                          >
                            {item.badge}
                          </Badge>
                        )}
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                );
              })}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>

        <SidebarGroup className="flex-1">
          <SidebarGroupContent className="px-2">
            <CountrySelector
              selectedCountries={selectedCountries}
              onToggleCountry={onToggleCountry}
              onSelectAll={onSelectAll}
            />
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t p-4">
        <p className="text-xs text-muted-foreground text-center" data-testid="text-monitoring-interval">
          {settings?.intervalMinutes 
            ? `Monitoring every ${settings.intervalMinutes} minutes`
            : "Loading..."
          }
        </p>
      </SidebarFooter>
    </Sidebar>
  );
}
