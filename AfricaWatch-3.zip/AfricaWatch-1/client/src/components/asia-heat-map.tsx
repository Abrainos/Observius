import { useMemo } from "react";
import { ComposableMap, Geographies, Geography, Marker } from "react-simple-maps";
import { scaleLinear } from "d3-scale";
import { geoCentroid } from "d3-geo";
import { type Alert } from "@shared/schema";
import { MapPin, AlertTriangle } from "lucide-react";
import { severityWeights } from "@/lib/geo-data";

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

interface AsiaHeatMapProps {
  alerts: Alert[];
  onCountryClick?: (country: string) => void;
}

// Map country names to ISO numeric codes (used in world-atlas)
const countryNameToIsoNum: Record<string, string> = {
  "Afghanistan": "004", "Armenia": "051", "Azerbaijan": "031", "Bahrain": "048",
  "Bangladesh": "050", "Bhutan": "064", "Brunei": "096", "Cambodia": "116",
  "China": "156", "Cyprus": "196", "Georgia": "268", "India": "356",
  "Indonesia": "360", "Iran": "364", "Iraq": "368", "Israel": "376",
  "Japan": "392", "Jordan": "400", "Kazakhstan": "398", "Kuwait": "414",
  "Kyrgyzstan": "417", "Laos": "418", "Lebanon": "422", "Malaysia": "458",
  "Maldives": "462", "Mongolia": "496", "Myanmar": "104", "Nepal": "524",
  "North Korea": "408", "Oman": "512", "Pakistan": "586", "Palestine": "275",
  "Philippines": "608", "Qatar": "634", "Russia": "643", "Saudi Arabia": "682",
  "Singapore": "702", "South Korea": "410", "Sri Lanka": "144", "Syria": "760",
  "Taiwan": "158", "Tajikistan": "762", "Thailand": "764", "Timor-Leste": "626",
  "Turkey": "792", "Turkmenistan": "795", "United Arab Emirates": "784",
  "Uzbekistan": "860", "Vietnam": "704", "Yemen": "887"
};

// Abbreviated country names for map labels
const countryAbbreviations: Record<string, string> = {
  "United Arab Emirates": "UAE",
  "Saudi Arabia": "Saudi",
  "North Korea": "N. Korea",
  "South Korea": "S. Korea",
  "Sri Lanka": "Sri Lanka",
  "Timor-Leste": "T-Leste",
};

export function AsiaHeatMap({ alerts, onCountryClick }: AsiaHeatMapProps) {
  // Calculate heat intensity per country
  const countryHeatData = useMemo(() => {
    const heatMap = new Map<string, { score: number; count: number; maxSeverity: string }>();

    alerts.forEach((alert) => {
      const isoNum = countryNameToIsoNum[alert.country];
      if (!isoNum) return;

      const weight = severityWeights[alert.severity] || 1;
      const existing = heatMap.get(isoNum) || { score: 0, count: 0, maxSeverity: "info" };

      const newSeverity = severityWeights[alert.severity] > severityWeights[existing.maxSeverity]
        ? alert.severity
        : existing.maxSeverity;

      heatMap.set(isoNum, {
        score: existing.score + weight,
        count: existing.count + 1,
        maxSeverity: newSeverity,
      });
    });

    return heatMap;
  }, [alerts]);

  // Calculate max score for color scaling
  const maxScore = useMemo(() => {
    let max = 0;
    countryHeatData.forEach((data) => {
      if (data.score > max) max = data.score;
    });
    return max || 1;
  }, [countryHeatData]);

  // Color scale from light to dark based on intensity
  const colorScale = scaleLinear<string>()
    .domain([0, maxScore / 2, maxScore])
    .range(["hsl(var(--muted))", "hsl(25 95% 53%)", "hsl(0 84% 60%)"])
    .clamp(true);

  const getCountryColor = (id: string): string => {
    const data = countryHeatData.get(id);
    if (!data) return "hsl(var(--muted))";
    return colorScale(data.score);
  };

  const getCountryInfo = (id: string) => {
    return countryHeatData.get(id);
  };

  // Asian country ISO numeric codes for filtering
  const asianCountries = new Set(Object.values(countryNameToIsoNum));

  return (
    <div className="w-full" data-testid="heat-map-container">
      <div className="bg-card rounded-lg border shadow-sm">
        <div className="p-4 border-b">
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            <h3 className="font-semibold">Asia Instability Heat Map</h3>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Geographic distribution of protests, instability, and security incidents
          </p>
        </div>
        <div className="relative bg-muted/30 !h-[500px] md:!h-[700px] lg:!h-[800px] w-full overflow-hidden" data-testid="map-canvas">
          <ComposableMap
            projection="geoMercator"
            projectionConfig={{
              scale: 600,
              center: [90, 30],
            }}
            width={1200}
            height={800}
            style={{ width: '100%', height: '100%' }}
          >
            <Geographies geography={geoUrl}>
              {({ geographies }) => {
                const filteredGeographies = geographies.filter((geo) => asianCountries.has(geo.id));
                
                return (
                  <>
                    {filteredGeographies.map((geo) => {
                      const countryInfo = getCountryInfo(geo.id);
                      const countryName = Object.keys(countryNameToIsoNum).find(
                        (key) => countryNameToIsoNum[key] === geo.id
                      );

                      return (
                        <Geography
                          key={geo.rsmKey}
                          geography={geo}
                          fill={getCountryColor(geo.id)}
                          stroke="hsl(var(--foreground) / 0.7)"
                          strokeWidth={2.0}
                          style={{
                            default: { 
                              outline: "none",
                              strokeWidth: 2.0,
                            },
                            hover: {
                              fill: "hsl(var(--primary))",
                              outline: "none",
                              cursor: "pointer",
                              strokeWidth: 2.5,
                              stroke: "hsl(var(--foreground) / 0.9)",
                            },
                            pressed: { 
                              outline: "none",
                              strokeWidth: 2.0,
                            },
                          }}
                          onClick={() => countryName && onCountryClick?.(countryName)}
                          data-testid={`map-country-${geo.id}`}
                        >
                          <title>
                            {countryName || "Unknown"}
                            {countryInfo
                              ? `\n${countryInfo.count} alert${countryInfo.count > 1 ? 's' : ''}\nMax Severity: ${countryInfo.maxSeverity}`
                              : '\nNo alerts'}
                          </title>
                        </Geography>
                      );
                    })}
                  </>
                );
              }}
            </Geographies>
            {/* Country Name Labels */}
            <Geographies geography={geoUrl}>
              {({ geographies }) =>
                geographies
                  .filter((geo) => asianCountries.has(geo.id))
                  .map((geo) => {
                    const centroid = geoCentroid(geo);
                    const countryName = Object.keys(countryNameToIsoNum).find(
                      (key) => countryNameToIsoNum[key] === geo.id
                    );
                    const displayName = countryName ? (countryAbbreviations[countryName] || countryName) : "";

                    return (
                      <Marker key={`${geo.rsmKey}-label`} coordinates={centroid}>
                        <text
                          textAnchor="middle"
                          style={{
                            fontSize: "11px",
                            fontWeight: 600,
                            fill: "hsl(var(--foreground))",
                            stroke: "hsl(var(--background))",
                            strokeWidth: "3px",
                            paintOrder: "stroke",
                            pointerEvents: "none",
                            userSelect: "none",
                          }}
                        >
                          {displayName}
                        </text>
                      </Marker>
                    );
                  })
              }
            </Geographies>
          </ComposableMap>

          {/* Legend */}
          <div className="absolute bottom-4 right-4 bg-background/95 backdrop-blur border rounded-lg p-3 space-y-2">
            <div className="text-xs font-semibold flex items-center gap-1">
              <AlertTriangle className="h-3 w-3" />
              Intensity
            </div>
            <div className="space-y-1">
              <div className="flex items-center gap-2 text-xs">
                <div className="w-4 h-4 rounded-sm" style={{ backgroundColor: "hsl(0 84% 60%)" }} />
                <span>High</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <div className="w-4 h-4 rounded-sm" style={{ backgroundColor: "hsl(25 95% 53%)" }} />
                <span>Medium</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <div className="w-4 h-4 rounded-sm bg-muted" />
                <span>Low/None</span>
              </div>
            </div>
          </div>
        </div>

        {/* Summary Stats */}
        <div className="grid grid-cols-3 gap-4 p-4 border-t bg-muted/20">
          <div className="text-center">
            <p className="text-2xl font-bold" data-testid="stat-countries-affected">
              {countryHeatData.size}
            </p>
            <p className="text-xs text-muted-foreground">Countries Affected</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold" data-testid="stat-total-alerts">
              {alerts.length}
            </p>
            <p className="text-xs text-muted-foreground">Total Alerts</p>
          </div>
          <div className="text-center">
            <p className="text-2xl font-bold" data-testid="stat-critical-alerts">
              {alerts.filter((a) => a.severity === "critical").length}
            </p>
            <p className="text-xs text-muted-foreground">Critical Incidents</p>
          </div>
        </div>
      </div>
    </div>
  );
}
