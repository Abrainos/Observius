import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { AlertCard } from "@/components/alert-card";
import { ScrollArea } from "@/components/ui/scroll-area";
import { type Alert } from "@shared/schema";
import { Badge } from "@/components/ui/badge";
import { MapPin } from "lucide-react";

interface CountryAlertsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  country: string | null;
  alerts: Alert[];
}

export function CountryAlertsDialog({
  open,
  onOpenChange,
  country,
  alerts,
}: CountryAlertsDialogProps) {
  if (!country) return null;

  const countryAlerts = alerts
    .filter((alert) => alert.country === country)
    .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

  const criticalCount = countryAlerts.filter((a) => a.severity === "critical").length;
  const highCount = countryAlerts.filter((a) => a.severity === "high").length;
  const moderateCount = countryAlerts.filter((a) => a.severity === "moderate").length;
  const infoCount = countryAlerts.filter((a) => a.severity === "info").length;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl h-[90vh] flex flex-col gap-0 p-0" data-testid="dialog-country-alerts">
        <div className="px-6 pt-6 pb-4 border-b">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              {country} - Events
            </DialogTitle>
            <DialogDescription>
              Showing {countryAlerts.length} event{countryAlerts.length !== 1 ? 's' : ''} in {country}
            </DialogDescription>
          </DialogHeader>

          {/* Summary Stats */}
          {countryAlerts.length > 0 && (
            <div className="grid grid-cols-4 gap-2 mt-4">
              {criticalCount > 0 && (
                <div className="text-center">
                  <Badge variant="destructive" className="mb-1">Critical</Badge>
                  <p className="text-sm font-medium">{criticalCount}</p>
                </div>
              )}
              {highCount > 0 && (
                <div className="text-center">
                  <Badge variant="destructive" className="mb-1 bg-orange-600 hover:bg-orange-700">High</Badge>
                  <p className="text-sm font-medium">{highCount}</p>
                </div>
              )}
              {moderateCount > 0 && (
                <div className="text-center">
                  <Badge variant="secondary" className="mb-1 bg-yellow-600 hover:bg-yellow-700">Moderate</Badge>
                  <p className="text-sm font-medium">{moderateCount}</p>
                </div>
              )}
              {infoCount > 0 && (
                <div className="text-center">
                  <Badge variant="outline" className="mb-1">Info</Badge>
                  <p className="text-sm font-medium">{infoCount}</p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Scrollable Alerts List */}
        <div className="flex-1 overflow-hidden">
          <ScrollArea className="h-full px-6 py-4">
            {countryAlerts.length === 0 ? (
              <div className="text-center py-12 text-muted-foreground">
                <MapPin className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No events found for {country}</p>
              </div>
            ) : (
              <div className="space-y-4 pb-4" data-testid="country-alerts-list">
                {countryAlerts.map((alert) => (
                  <AlertCard key={alert.id} alert={alert} />
                ))}
              </div>
            )}
          </ScrollArea>
        </div>
      </DialogContent>
    </Dialog>
  );
}
