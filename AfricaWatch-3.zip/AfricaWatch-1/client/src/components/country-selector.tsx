import { countriesByRegion } from "@shared/schema";
import { cn } from "@/lib/utils";
import { Check, Globe2, CheckSquare, Square } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useRegion } from "@/contexts/region-context";

interface CountrySelectorProps {
  selectedCountries: string[];
  onToggleCountry: (country: string) => void;
  onSelectAll: () => void;
}

export function CountrySelector({
  selectedCountries,
  onToggleCountry,
  onSelectAll,
}: CountrySelectorProps) {
  const { selectedRegion } = useRegion();
  const regionCountries = countriesByRegion[selectedRegion];
  
  // Check if ALL region countries are in selectedCountries (not just length match)
  const allSelected = regionCountries.every(country => selectedCountries.includes(country));
  
  return (
    <div className="space-y-3">
      <div className="px-2 space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold uppercase tracking-wide">
            Monitored Countries
          </h3>
          <span className="text-xs text-muted-foreground font-mono" data-testid="text-selected-count">
            {selectedCountries.length} selected
          </span>
        </div>
        
        <Button
          variant="outline"
          size="sm"
          className="w-full justify-start gap-2"
          onClick={onSelectAll}
          data-testid="button-select-all-countries"
        >
          {allSelected ? (
            <CheckSquare className="h-4 w-4" />
          ) : (
            <Square className="h-4 w-4" />
          )}
          <span>{allSelected ? "Deselect All" : "Select All"}</span>
        </Button>
      </div>

      <div className="space-y-1 max-h-[calc(100vh-280px)] overflow-y-auto pr-1">
        {regionCountries.map((country) => {
          const isSelected = selectedCountries.includes(country);
          
          return (
            <Button
              key={country}
              variant={isSelected ? "secondary" : "ghost"}
              size="sm"
              className={cn(
                "w-full justify-start gap-2 font-normal",
                isSelected && "bg-sidebar-accent"
              )}
              onClick={() => onToggleCountry(country)}
              data-testid={`button-country-${country.toLowerCase().replace(/\s+/g, '-')}`}
            >
              <Globe2 className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />
              <span className="flex-1 text-left truncate">{country}</span>
              {isSelected && (
                <Check className="h-4 w-4 text-primary flex-shrink-0" />
              )}
            </Button>
          );
        })}
      </div>
    </div>
  );
}
