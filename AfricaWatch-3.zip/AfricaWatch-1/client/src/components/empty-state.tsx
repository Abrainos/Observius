import { Globe, MapPin, Shield, CheckCircle } from "lucide-react";
import { cn } from "@/lib/utils";

interface EmptyStateProps {
  type: "no-countries" | "no-alerts" | "no-results";
  className?: string;
}

export function EmptyState({ type, className }: EmptyStateProps) {
  const config = {
    "no-countries": {
      icon: Globe,
      title: "Select Countries to Monitor",
      description: "Choose African countries from the sidebar to start monitoring for protests and instability.",
      iconClass: "text-primary",
    },
    "no-alerts": {
      icon: CheckCircle,
      title: "All Quiet",
      description: "No protests or instability detected in your monitored regions. We'll alert you immediately if anything changes.",
      iconClass: "text-severity-safe",
    },
    "no-results": {
      icon: MapPin,
      title: "No Matching Alerts",
      description: "Try adjusting your filters to see more results.",
      iconClass: "text-muted-foreground",
    },
  }[type];

  const Icon = config.icon;

  return (
    <div className={cn("flex flex-col items-center justify-center p-12 text-center", className)} data-testid={`empty-state-${type}`}>
      <div className={cn("mb-4 rounded-full bg-muted p-6", config.iconClass)}>
        <Icon className="h-12 w-12" strokeWidth={1.5} />
      </div>
      <h3 className="text-xl font-semibold mb-2" data-testid="text-empty-title">
        {config.title}
      </h3>
      <p className="text-sm text-muted-foreground max-w-md" data-testid="text-empty-description">
        {config.description}
      </p>
    </div>
  );
}
