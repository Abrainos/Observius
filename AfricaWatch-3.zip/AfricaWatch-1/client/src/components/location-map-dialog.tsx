import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { ComposableMap, Geographies, Geography, Marker } from "react-simple-maps";
import { MapPin } from "lucide-react";

interface LocationMapDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  location: string;
  country: string;
  latitude?: string | null;
  longitude?: string | null;
  title: string;
}

const AFRICA_TOPO_URL = "https://unpkg.com/world-atlas@2.0.2/countries-50m.json";

export function LocationMapDialog({
  open,
  onOpenChange,
  location,
  country,
  latitude,
  longitude,
  title,
}: LocationMapDialogProps) {
  // Parse coordinates
  const lat = latitude ? parseFloat(latitude) : null;
  const lon = longitude ? parseFloat(longitude) : null;

  // Check if we have valid coordinates
  const hasCoordinates = lat !== null && lon !== null && !isNaN(lat) && !isNaN(lon);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh]" data-testid="dialog-location-map">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <MapPin className="h-5 w-5 text-primary" />
            Event Location
          </DialogTitle>
          <DialogDescription>
            {location}, {country}
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {hasCoordinates ? (
            <>
              <div className="text-sm text-muted-foreground">
                <p className="font-medium">{title}</p>
                <p className="mt-1">
                  Coordinates: {lat?.toFixed(4)}°, {lon?.toFixed(4)}°
                </p>
              </div>

              <div className="border-2 rounded-lg overflow-hidden bg-muted/30">
                <style>{`
                  @keyframes pulse-heat {
                    0%, 100% {
                      transform: scale(0.3);
                      opacity: 0.3;
                    }
                    50% {
                      transform: scale(1);
                      opacity: 1;
                    }
                  }
                  .heat-ring-pulse {
                    animation: pulse-heat 1s ease-in-out infinite;
                    transform-origin: center;
                  }
                `}</style>
                <ComposableMap
                  projection="geoMercator"
                  projectionConfig={{
                    center: [lon, lat],
                    scale: 2000, // Zoom in significantly for city-level view
                  }}
                  width={800}
                  height={500}
                  style={{
                    width: "100%",
                    height: "auto",
                  }}
                >
                  <Geographies geography={AFRICA_TOPO_URL}>
                    {({ geographies }) =>
                      geographies.map((geo) => (
                        <Geography
                          key={geo.rsmKey}
                          geography={geo}
                          fill="hsl(var(--muted))"
                          stroke="hsl(var(--foreground))"
                          strokeWidth={2}
                          style={{
                            default: { outline: "none", opacity: 0.6 },
                            hover: { outline: "none", opacity: 0.8 },
                            pressed: { outline: "none", opacity: 0.8 },
                          }}
                        />
                      ))
                    }
                  </Geographies>

                  {/* Heat map visualization - separate markers for each ring */}
                  {/* Outermost ring - lowest intensity */}
                  <Marker coordinates={[lon, lat]}>
                    <circle
                      r={35}
                      fill="hsl(var(--destructive))"
                      fillOpacity={0.08}
                      stroke="hsl(var(--destructive))"
                      strokeWidth={1}
                      strokeOpacity={0.3}
                      data-heatmap-ring="4"
                      className="heat-ring-pulse"
                      style={{ animationDelay: '0s' }}
                    />
                  </Marker>
                  
                  {/* Third ring */}
                  <Marker coordinates={[lon, lat]}>
                    <circle
                      r={25}
                      fill="hsl(var(--destructive))"
                      fillOpacity={0.18}
                      stroke="hsl(var(--destructive))"
                      strokeWidth={1.5}
                      strokeOpacity={0.4}
                      data-heatmap-ring="3"
                      className="heat-ring-pulse"
                      style={{ animationDelay: '0.1s' }}
                    />
                  </Marker>
                  
                  {/* Second ring */}
                  <Marker coordinates={[lon, lat]}>
                    <circle
                      r={18}
                      fill="hsl(var(--destructive))"
                      fillOpacity={0.28}
                      stroke="hsl(var(--destructive))"
                      strokeWidth={2}
                      strokeOpacity={0.5}
                      data-heatmap-ring="2"
                      className="heat-ring-pulse"
                      style={{ animationDelay: '0.2s' }}
                    />
                  </Marker>
                  
                  {/* First ring - highest intensity */}
                  <Marker coordinates={[lon, lat]}>
                    <circle
                      r={12}
                      fill="hsl(var(--destructive))"
                      fillOpacity={0.45}
                      stroke="hsl(var(--destructive))"
                      strokeWidth={2}
                      strokeOpacity={0.7}
                      data-heatmap-ring="1"
                      className="heat-ring-pulse"
                      style={{ animationDelay: '0.3s' }}
                    />
                  </Marker>
                  
                  {/* Center marker for exact location */}
                  <Marker coordinates={[lon, lat]}>
                    <circle
                      r={6}
                      fill="hsl(var(--destructive))"
                      stroke="hsl(var(--background))"
                      strokeWidth={3}
                      data-heatmap-ring="center-outer"
                      className="heat-ring-pulse"
                      style={{ animationDelay: '0.4s' }}
                    />
                  </Marker>
                  
                  <Marker coordinates={[lon, lat]}>
                    <circle
                      r={3}
                      fill="hsl(var(--destructive-foreground))"
                      data-heatmap-ring="center-inner"
                    />
                  </Marker>
                </ComposableMap>
              </div>

              <div className="text-xs text-muted-foreground">
                <p>
                  This map shows the approximate location of the security incident based on the
                  reported location data. The exact location may vary.
                </p>
              </div>
            </>
          ) : (
            <div className="py-12 text-center">
              <MapPin className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
              <p className="text-muted-foreground">
                Location coordinates not available for this alert.
              </p>
              <p className="text-sm text-muted-foreground mt-2">
                Reported location: {location}, {country}
              </p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}
