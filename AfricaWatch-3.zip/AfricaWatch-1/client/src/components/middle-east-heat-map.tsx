import { useMemo } from "react";
import { ComposableMap, Geographies, Geography, Marker } from "react-simple-maps";
import { scaleLinear } from "d3-scale";
import { geoCentroid } from "d3-geo";
import { type Alert } from "@shared/schema";
import { MapPin } from "lucide-react";
import { severityWeights } from "@/lib/geo-data";

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

interface MiddleEastHeatMapProps {
  alerts: Alert[];
  onCountryClick?: (country: string) => void;
}

// Map country names to ISO numeric codes (used in world-atlas)
const countryNameToIsoNum: Record<string, string> = {
  "Afghanistan": "004", "Bahrain": "048", "Cyprus": "196", "Egypt": "818",
  "Iran": "364", "Iraq": "368", "Israel": "376", "Jordan": "400",
  "Kuwait": "414", "Lebanon": "422", "Oman": "512", "Palestine": "275",
  "Qatar": "634", "Saudi Arabia": "682", "Syria": "760", "Turkey": "792",
  "United Arab Emirates": "784", "Yemen": "887"
};

// Reverse mapping: ISO code to country name
const isoNumToCountryName: Record<string, string> = Object.entries(countryNameToIsoNum).reduce(
  (acc, [name, code]) => ({ ...acc, [code]: name }),
  {}
);

const countryAbbreviations: Record<string, string> = {
  "United Arab Emirates": "UAE",
  "Saudi Arabia": "Saudi",
};

export function MiddleEastHeatMap({ alerts, onCountryClick }: MiddleEastHeatMapProps) {
  // Calculate heat intensity per country
  const countryHeatData = useMemo(() => {
    const heatMap = new Map<string, { score: number; count: number; maxSeverity: string }>();

    alerts.forEach((alert) => {
      const isoNum = countryNameToIsoNum[alert.country];
      if (!isoNum) return;

      const weight = severityWeights[alert.severity] || 1;
      const existing = heatMap.get(isoNum) || { score: 0, count: 0, maxSeverity: "info" };

      const newSeverity = severityWeights[alert.severity] > severityWeights[existing.maxSeverity]
        ? alert.severity
        : existing.maxSeverity;

      heatMap.set(isoNum, {
        score: existing.score + weight,
        count: existing.count + 1,
        maxSeverity: newSeverity,
      });
    });

    return heatMap;
  }, [alerts]);

  // Calculate max score for color scaling
  const maxScore = useMemo(() => {
    let max = 0;
    countryHeatData.forEach((data) => {
      if (data.score > max) max = data.score;
    });
    return max || 1;
  }, [countryHeatData]);

  // Color scale from light to dark based on intensity with better contrast
  const colorScale = scaleLinear<string>()
    .domain([0, maxScore / 2, maxScore])
    .range(["hsl(var(--muted))", "hsl(25 90% 50%)", "hsl(0 80% 55%)"])
    .clamp(true);

  const getCountryColor = (id: string): string => {
    const data = countryHeatData.get(id);
    if (!data) return "hsl(var(--muted))";
    return colorScale(data.score);
  };

  const getCountryInfo = (id: string) => {
    return countryHeatData.get(id);
  };

  // Middle Eastern country ISO numeric codes for filtering
  const middleEastCountries = new Set(Object.values(countryNameToIsoNum));

  return (
    <div className="w-full">
      <div className="bg-card rounded-lg border shadow-sm">
        <div className="p-4 border-b">
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            <h3 className="font-semibold">Middle East Instability Heat Map</h3>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Geographic distribution of protests, instability, and security incidents
          </p>
        </div>
        <div className="relative bg-muted/30 !h-[500px] md:!h-[700px] lg:!h-[800px] w-full overflow-hidden" data-testid="map-canvas">
          <ComposableMap
            projection="geoAzimuthalEqualArea"
            projectionConfig={{
              rotate: [-50.0, -30.0, 0],
              scale: 1500,
            }}
            width={1200}
            height={800}
            style={{ width: '100%', height: '100%' }}
          >
        
          <Geographies geography={geoUrl}>
            {({ geographies }) => {
              const filteredGeographies = geographies.filter((geo) => middleEastCountries.has(geo.id));
              
              return (
                <>
                  {filteredGeographies.map((geo) => {
                    const info = getCountryInfo(geo.id);
                    const countryName = isoNumToCountryName[geo.id] || "Unknown";
                    
                    return (
                      <Geography
                        key={geo.rsmKey}
                        geography={geo}
                        fill={getCountryColor(geo.id)}
                        stroke="hsl(var(--foreground) / 0.7)"
                        strokeWidth={2.0}
                        style={{
                          default: { 
                            outline: "none",
                            strokeWidth: 2.0,
                          },
                          hover: {
                            fill: "hsl(var(--primary))",
                            outline: "none",
                            cursor: "pointer",
                            strokeWidth: 2.5,
                            stroke: "hsl(var(--foreground) / 0.9)",
                          },
                          pressed: { 
                            outline: "none",
                            strokeWidth: 2.0,
                          },
                        }}
                        onClick={() => countryName && onCountryClick?.(countryName)}
                        data-testid={`map-country-${countryName.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        <title>
                          {countryName}
                          {info
                            ? `\n${info.count} alert${info.count > 1 ? 's' : ''}\nMax Severity: ${info.maxSeverity}`
                            : '\nNo alerts'}
                        </title>
                      </Geography>
                    );
                  })}
                </>
              );
            }}
          </Geographies>
          {/* Country Name Labels */}
          <Geographies geography={geoUrl}>
            {({ geographies }) =>
              geographies
                .filter((geo) => middleEastCountries.has(geo.id))
                .map((geo) => {
                  const centroid = geoCentroid(geo);
                  const countryName = isoNumToCountryName[geo.id] || "Unknown";
                  const displayName = countryAbbreviations[countryName] || countryName;

                  return (
                    <Marker key={`${geo.rsmKey}-label`} coordinates={centroid}>
                      <text
                        textAnchor="middle"
                        style={{
                          fontSize: "11px",
                          fontWeight: 600,
                          fill: "hsl(var(--foreground))",
                          stroke: "hsl(var(--background))",
                          strokeWidth: "3px",
                          paintOrder: "stroke",
                          pointerEvents: "none",
                          userSelect: "none",
                        }}
                      >
                        {displayName}
                      </text>
                    </Marker>
                  );
                })
            }
          </Geographies>
        </ComposableMap>
        </div>

        {/* Legend */}
        <div className="px-6 pb-6 pt-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Low Activity</span>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded" style={{ backgroundColor: "hsl(var(--muted))" }} />
                <span>None</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded" style={{ backgroundColor: "hsl(25 90% 50%)" }} />
                <span>Moderate</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded" style={{ backgroundColor: "hsl(0 80% 55%)" }} />
                <span>Critical</span>
              </div>
            </div>
            <span>High Activity</span>
          </div>
          <p className="text-xs text-muted-foreground mt-2 text-center">
            Monitoring {alerts.length} active {alerts.length === 1 ? 'incident' : 'incidents'} across the Middle East
          </p>
        </div>
      </div>
    </div>
  );
}
