import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { Mail, Loader2 } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export function NewsletterSignup() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email || !email.includes("@")) {
      toast({
        title: "Invalid Email",
        description: "Please enter a valid email address",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);

    try {
      await apiRequest("POST", "/api/newsletter/subscribe", { email });
      toast({
        title: "Subscribed Successfully!",
        description: "You'll receive daily security briefings at " + email,
      });
      setEmail("");
    } catch (error: any) {
      toast({
        title: "Subscription Failed",
        description: error?.message || "Unable to subscribe. Please try again later.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="bg-gradient-to-br from-primary/5 via-primary/10 to-primary/5 border-primary/20">
      <CardHeader className="text-center pb-4">
        <div className="flex items-center justify-center gap-2 mb-2">
          <Mail className="h-6 w-6 text-primary" />
          <CardTitle className="text-2xl">Daily Security Briefing</CardTitle>
        </div>
        <CardDescription className="text-base">
          Get comprehensive 2,000-word analysis of global security threats delivered to your inbox every morning. Includes forward-looking predictions, travel hot spots to avoid, and expert insights across all 7 regions.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3">
          <Input
            type="email"
            placeholder="Enter your email address"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            disabled={isLoading}
            className="flex-1"
            data-testid="input-newsletter-email"
          />
          <Button 
            type="submit" 
            disabled={isLoading}
            className="sm:w-auto"
            data-testid="button-newsletter-subscribe"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Subscribing...
              </>
            ) : (
              "Subscribe Free"
            )}
          </Button>
        </form>
        <p className="text-xs text-muted-foreground text-center mt-3">
          No spam. Unsubscribe anytime with one click.
        </p>
      </CardContent>
    </Card>
  );
}
