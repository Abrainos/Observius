import { useMemo } from "react";
import { ComposableMap, Geographies, Geography, Marker } from "react-simple-maps";
import { scaleLinear } from "d3-scale";
import { geoCentroid } from "d3-geo";
import { type Alert } from "@shared/schema";
import { MapPin, AlertTriangle } from "lucide-react";
import { severityWeights } from "@/lib/geo-data";

const geoUrl = "https://cdn.jsdelivr.net/npm/world-atlas@2/countries-110m.json";

interface NorthAmericaHeatMapProps {
  alerts: Alert[];
  onCountryClick?: (country: string) => void;
}

// Map country names to ISO numeric codes (used in world-atlas)
const countryNameToIsoNum: Record<string, string> = {
  "United States": "840",
  "Canada": "124",
  "Mexico": "484",
  "Belize": "084",
  "Costa Rica": "188",
  "El Salvador": "222",
  "Guatemala": "320",
  "Honduras": "340",
  "Nicaragua": "558",
  "Panama": "591",
  "Antigua and Barbuda": "028",
  "Bahamas": "044",
  "Barbados": "052",
  "Cuba": "192",
  "Dominica": "212",
  "Dominican Republic": "214",
  "Grenada": "308",
  "Haiti": "332",
  "Jamaica": "388",
  "Saint Kitts and Nevis": "659",
  "Saint Lucia": "662",
  "Saint Vincent and the Grenadines": "670",
  "Trinidad and Tobago": "780",
};

const countryAbbreviations: Record<string, string> = {
  "United States": "USA",
  "Dominican Republic": "Dom. Rep.",
  "Saint Kitts and Nevis": "St. Kitts",
  "Saint Lucia": "St. Lucia",
  "Saint Vincent and the Grenadines": "St. Vincent",
  "Trinidad and Tobago": "Trinidad",
};

export function NorthAmericaHeatMap({ alerts, onCountryClick }: NorthAmericaHeatMapProps) {
  // Calculate heat intensity per country
  const countryHeatData = useMemo(() => {
    const heatMap = new Map<string, { score: number; count: number; maxSeverity: string }>();

    alerts.forEach((alert) => {
      const isoNum = countryNameToIsoNum[alert.country];
      if (!isoNum) return;

      const weight = severityWeights[alert.severity] || 1;
      const existing = heatMap.get(isoNum) || { score: 0, count: 0, maxSeverity: "info" };

      const newSeverity = severityWeights[alert.severity] > severityWeights[existing.maxSeverity]
        ? alert.severity
        : existing.maxSeverity;

      heatMap.set(isoNum, {
        score: existing.score + weight,
        count: existing.count + 1,
        maxSeverity: newSeverity,
      });
    });

    return heatMap;
  }, [alerts]);

  // Calculate max score for color scaling
  const maxScore = useMemo(() => {
    let max = 0;
    countryHeatData.forEach((data) => {
      if (data.score > max) max = data.score;
    });
    return max || 1;
  }, [countryHeatData]);

  // Color scale from light to dark based on intensity
  const colorScale = scaleLinear<string>()
    .domain([0, maxScore / 2, maxScore])
    .range(["hsl(var(--muted))", "hsl(25 95% 53%)", "hsl(0 84% 60%)"])
    .clamp(true);

  const getCountryColor = (id: string): string => {
    const data = countryHeatData.get(id);
    if (!data) return "hsl(var(--muted))";
    return colorScale(data.score);
  };

  const getCountryInfo = (id: string) => {
    return countryHeatData.get(id);
  };

  // North American country ISO numeric codes for filtering
  const northAmericanCountries = new Set(Object.values(countryNameToIsoNum));

  return (
    <div className="w-full" data-testid="heat-map-container">
      <div className="bg-card rounded-lg border shadow-sm">
        <div className="p-4 border-b">
          <div className="flex items-center gap-2">
            <MapPin className="h-5 w-5" />
            <h3 className="font-semibold">North America Instability Heat Map</h3>
          </div>
          <p className="text-sm text-muted-foreground mt-1">
            Geographic distribution of protests, instability, and security incidents
          </p>
        </div>
        <div className="relative bg-muted/30 !h-[500px] md:!h-[700px] lg:!h-[800px] w-full overflow-hidden" data-testid="map-canvas">
          <ComposableMap
            projection="geoMercator"
            projectionConfig={{
              scale: 780,
              center: [-95, 25],
            }}
            width={1200}
            height={900}
            style={{ width: '100%', height: '100%' }}
          >
            <Geographies geography={geoUrl}>
              {({ geographies }) =>
                geographies
                  .filter((geo) => northAmericanCountries.has(geo.id))
                  .map((geo) => {
                    const countryInfo = getCountryInfo(geo.id);
                    const countryName = Object.keys(countryNameToIsoNum).find(
                      (name) => countryNameToIsoNum[name] === geo.id
                    ) || geo.properties.name;

                    return (
                      <Geography
                        key={geo.rsmKey}
                        geography={geo}
                        fill={getCountryColor(geo.id)}
                        stroke="hsl(var(--foreground) / 0.7)"
                        strokeWidth={2.0}
                        style={{
                          default: { 
                            outline: "none",
                            strokeWidth: 2.0,
                          },
                          hover: {
                            fill: countryInfo 
                              ? "hsl(0 84% 50%)" 
                              : "hsl(var(--accent))",
                            outline: "none",
                            strokeWidth: 2.5,
                            stroke: "hsl(var(--foreground) / 0.9)",
                            cursor: "pointer",
                          },
                          pressed: { 
                            outline: "none",
                            strokeWidth: 2.0,
                          },
                        }}
                        onClick={() => countryName && onCountryClick?.(countryName)}
                        data-testid={`country-${countryName.toLowerCase().replace(/\s+/g, '-')}`}
                      >
                        <title>
                          {countryName}
                          {countryInfo && ` - ${countryInfo.count} alert${countryInfo.count > 1 ? 's' : ''} (${countryInfo.maxSeverity})`}
                        </title>
                      </Geography>
                    );
                  })
              }
            </Geographies>
            
            {/* Country Labels */}
            <Geographies geography={geoUrl}>
              {({ geographies }) =>
                geographies
                  .filter((geo) => northAmericanCountries.has(geo.id))
                  .map((geo) => {
                    const centroid = geoCentroid(geo);
                    const countryName = Object.keys(countryNameToIsoNum).find(
                      (name) => countryNameToIsoNum[name] === geo.id
                    ) || geo.properties.name;
                    const displayName = countryAbbreviations[countryName] || countryName;

                    return (
                      <Marker key={geo.rsmKey + "-label"} coordinates={centroid}>
                        <text
                          textAnchor="middle"
                          y={0}
                          style={{
                            fontFamily: "system-ui",
                            fontSize: "11px",
                            fontWeight: "600",
                            fill: "hsl(var(--foreground))",
                            stroke: "hsl(var(--background))",
                            strokeWidth: "3px",
                            paintOrder: "stroke",
                            pointerEvents: "none",
                            userSelect: "none",
                          }}
                        >
                          {displayName}
                        </text>
                      </Marker>
                    );
                  })
              }
            </Geographies>
          </ComposableMap>

          {/* Legend */}
          <div className="absolute bottom-4 right-4 bg-background/90 backdrop-blur-sm rounded-lg p-3 border shadow-lg">
            <div className="space-y-1.5">
              <div className="flex items-center gap-2 text-xs">
                <div className="w-4 h-4 rounded" style={{ backgroundColor: "hsl(0 84% 60%)" }}></div>
                <span className="font-medium">High Activity</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <div className="w-4 h-4 rounded" style={{ backgroundColor: "hsl(25 95% 53%)" }}></div>
                <span className="font-medium">Moderate Activity</span>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <div className="w-4 h-4 rounded bg-muted"></div>
                <span className="font-medium">Low/No Activity</span>
              </div>
            </div>
          </div>

          {/* Alert Summary */}
          {alerts.length > 0 && (
            <div className="absolute top-4 left-4 bg-destructive/90 backdrop-blur-sm rounded-lg p-3 border border-destructive shadow-lg">
              <div className="flex items-center gap-2 text-destructive-foreground">
                <AlertTriangle className="h-4 w-4" />
                <div>
                  <p className="text-sm font-bold">{alerts.length} Active Alerts</p>
                  <p className="text-xs opacity-90">
                    {countryHeatData.size} {countryHeatData.size === 1 ? 'country' : 'countries'} affected
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
