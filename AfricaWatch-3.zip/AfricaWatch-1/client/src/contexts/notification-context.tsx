import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface NotificationContextType {
  notificationsEnabled: boolean;
  setNotificationsEnabled: (enabled: boolean) => void;
}

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [notificationsEnabled, setNotificationsEnabledState] = useState(() => {
    return localStorage.getItem('notifications_enabled') === 'true';
  });

  const setNotificationsEnabled = (enabled: boolean) => {
    setNotificationsEnabledState(enabled);
    localStorage.setItem('notifications_enabled', enabled.toString());
  };

  return (
    <NotificationContext.Provider value={{ notificationsEnabled, setNotificationsEnabled }}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotificationSettings() {
  const context = useContext(NotificationContext);
  if (context === undefined) {
    throw new Error('useNotificationSettings must be used within NotificationProvider');
  }
  return context;
}
