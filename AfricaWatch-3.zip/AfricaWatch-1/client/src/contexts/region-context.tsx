import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { type Region } from "@shared/schema";

interface RegionContextType {
  selectedRegion: Region;
  setSelectedRegion: (region: Region) => void;
}

const RegionContext = createContext<RegionContextType | undefined>(undefined);

const STORAGE_KEY = "earthenwatch_selected_region";

export function RegionProvider({ children }: { children: ReactNode }) {
  // Load region from localStorage or default to africa
  const [selectedRegion, setSelectedRegionState] = useState<Region>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return (saved as Region) || "africa";
  });

  // Save region preference to localStorage
  const setSelectedRegion = (region: Region) => {
    setSelectedRegionState(region);
    localStorage.setItem(STORAGE_KEY, region);
  };

  return (
    <RegionContext.Provider value={{ selectedRegion, setSelectedRegion }}>
      {children}
    </RegionContext.Provider>
  );
}

export function useRegion() {
  const context = useContext(RegionContext);
  if (context === undefined) {
    throw new Error("useRegion must be used within a RegionProvider");
  }
  return context;
}
