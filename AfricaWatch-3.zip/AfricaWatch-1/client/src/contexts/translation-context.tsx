import { createContext, useContext, useState, ReactNode } from 'react';

interface TranslationContextType {
  showOriginalLanguage: boolean;
  setShowOriginalLanguage: (enabled: boolean) => void;
}

const TranslationContext = createContext<TranslationContextType | undefined>(undefined);

export function TranslationProvider({ children }: { children: ReactNode }) {
  const [showOriginalLanguage, setShowOriginalLanguageState] = useState(() => {
    return localStorage.getItem('show_original_language') === 'true';
  });

  const setShowOriginalLanguage = (enabled: boolean) => {
    setShowOriginalLanguageState(enabled);
    localStorage.setItem('show_original_language', enabled.toString());
  };

  return (
    <TranslationContext.Provider value={{ showOriginalLanguage, setShowOriginalLanguage }}>
      {children}
    </TranslationContext.Provider>
  );
}

export function useTranslationSettings() {
  const context = useContext(TranslationContext);
  if (!context) {
    throw new Error('useTranslationSettings must be used within TranslationProvider');
  }
  return context;
}
