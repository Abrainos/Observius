import { useEffect, useRef } from 'react';
import { Capacitor } from '@capacitor/core';
import { notificationService } from '@/lib/notifications';
import { type Alert } from '@shared/schema';
import { useLocalAlerts } from './use-local-alerts';

interface UseAlertNotificationsOptions {
  enabled: boolean;
  pollInterval?: number;
}

export function useAlertNotifications({ enabled, pollInterval = 60000 }: UseAlertNotificationsOptions) {
  const seenAlertIds = useRef<Set<string>>(new Set());
  const isNativePlatform = Capacitor.isNativePlatform();
  const shouldMonitor = enabled && isNativePlatform;

  // Use local alerts instead of querying the server
  const { data: alerts } = useLocalAlerts({
    autoSync: shouldMonitor, // Only sync if we're actually monitoring
  });

  useEffect(() => {
    if (!enabled || !isNativePlatform || !alerts) {
      return;
    }

    // Check for new critical alerts
    const criticalAlerts = alerts.filter(alert => alert.severity === 'critical');
    
    for (const alert of criticalAlerts) {
      // Only notify for alerts we haven't seen before
      if (!seenAlertIds.current.has(alert.id)) {
        seenAlertIds.current.add(alert.id);
        
        // Schedule notification for new critical alert
        notificationService.scheduleLocalNotification(
          `CRITICAL ALERT: ${alert.country}`,
          alert.title,
          'critical'
        ).catch(error => {
          console.error('Failed to schedule notification:', error);
        });
      }
    }

    // Clean up old seen IDs to prevent memory leak (keep last 1000)
    if (seenAlertIds.current.size > 1000) {
      const idsArray = Array.from(seenAlertIds.current);
      seenAlertIds.current = new Set(idsArray.slice(-1000));
    }
  }, [alerts, enabled, isNativePlatform]);

  return {
    isMonitoring: enabled && isNativePlatform,
  };
}
