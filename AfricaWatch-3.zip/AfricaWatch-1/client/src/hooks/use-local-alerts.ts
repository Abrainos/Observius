import { useState, useEffect, useCallback } from "react";
import type { Alert } from "@shared/schema";
import { localAlertStorage } from "@/lib/local-storage";
import { alertSyncService } from "@/lib/alert-sync";

interface UseLocalAlertsOptions {
  region?: string;
  autoSync?: boolean;
}

/**
 * Hook to fetch alerts from local IndexedDB storage
 * Automatically syncs with server in the background
 */
export function useLocalAlerts(options: UseLocalAlertsOptions = {}) {
  const { region, autoSync = true } = options;
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  const loadAlerts = useCallback(async () => {
    try {
      setIsLoading(true);
      const localAlerts = await localAlertStorage.getAllAlerts(region);
      setAlerts(localAlerts);
      setError(null);
    } catch (err) {
      console.error("[useLocalAlerts] Error loading alerts:", err);
      setError(err as Error);
    } finally {
      setIsLoading(false);
    }
  }, [region]);

  // Load alerts on mount and when region changes
  useEffect(() => {
    loadAlerts();
  }, [loadAlerts]);

  // Start sync service and listen for updates
  useEffect(() => {
    if (!autoSync) return;

    // Start sync service
    alertSyncService.start();

    // Reload alerts when sync completes
    const handleSyncComplete = () => {
      loadAlerts();
    };

    alertSyncService.addListener(handleSyncComplete);

    return () => {
      alertSyncService.removeListener(handleSyncComplete);
    };
  }, [autoSync, loadAlerts]);

  return {
    data: alerts,
    isLoading,
    error,
    refetch: loadAlerts,
  };
}

/**
 * Hook to get a single alert by ID from local storage
 */
export function useLocalAlert(id: string | undefined) {
  const [alert, setAlert] = useState<Alert | undefined>();
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    if (!id) {
      setAlert(undefined);
      setIsLoading(false);
      return;
    }

    const loadAlert = async () => {
      try {
        setIsLoading(true);
        const localAlert = await localAlertStorage.getAlertById(id);
        setAlert(localAlert);
      } catch (err) {
        console.error("[useLocalAlert] Error loading alert:", err);
      } finally {
        setIsLoading(false);
      }
    };

    loadAlert();
  }, [id]);

  return {
    data: alert,
    isLoading,
  };
}
