import type { Alert } from "@shared/schema";
import { localAlertStorage } from "./local-storage";

const SYNC_INTERVAL = 5 * 60 * 1000; // Sync every 5 minutes
const FULL_SYNC_INTERVAL = 24 * 60 * 60 * 1000; // Full sync every 24 hours
const API_BASE = "/api";

/**
 * Alert synchronization service
 * Periodically fetches new alerts from server and stores them locally
 */
class AlertSyncService {
  private syncInterval: NodeJS.Timeout | null = null;
  private fullSyncInterval: NodeJS.Timeout | null = null;
  private isSyncing = false;
  private listeners: Set<() => void> = new Set();

  /**
   * Start automatic synchronization
   */
  start(): void {
    if (this.syncInterval) {
      console.log("[Sync] Already running");
      return;
    }

    console.log("[Sync] Starting automatic sync service");
    
    // Initial sync
    this.syncAlerts();

    // Set up periodic incremental sync
    this.syncInterval = setInterval(() => {
      this.syncAlerts();
    }, SYNC_INTERVAL);

    // Set up periodic full sync (every 24 hours) to clean up deleted alerts
    this.fullSyncInterval = setInterval(() => {
      console.log("[Sync] Running periodic full sync to clean up deleted alerts");
      this.syncAlerts(true); // Force full sync
    }, FULL_SYNC_INTERVAL);
  }

  /**
   * Stop automatic synchronization
   */
  stop(): void {
    if (this.syncInterval) {
      clearInterval(this.syncInterval);
      this.syncInterval = null;
    }
    if (this.fullSyncInterval) {
      clearInterval(this.fullSyncInterval);
      this.fullSyncInterval = null;
    }
    console.log("[Sync] Stopped automatic sync service");
  }

  /**
   * Manually trigger a sync
   * @param forceFullSync - If true, fetches ALL alerts and removes local-only alerts
   */
  async syncAlerts(forceFullSync: boolean = false): Promise<void> {
    if (this.isSyncing) {
      console.log("[Sync] Sync already in progress");
      return;
    }

    this.isSyncing = true;

    try {
      // Get last sync time for incremental fetching
      const lastSyncTime = await localAlertStorage.getLastSyncTime();
      const isInitialSync = !lastSyncTime;
      
      let url = `${API_BASE}/alerts`;
      let shouldCleanupDeleted = false;
      
      if (forceFullSync || isInitialSync) {
        // Full sync - fetch ALL alerts and clean up deleted ones
        console.log(`[Sync] Fetching all alerts (${forceFullSync ? 'periodic full sync' : 'initial sync'})...`);
        shouldCleanupDeleted = true;
      } else {
        // PERFORMANCE OPTIMIZATION: Incremental sync - only fetch new/updated alerts
        const sinceTime = new Date(lastSyncTime.getTime() - 60000);
        url += `?since=${sinceTime.toISOString()}`;
        console.log(`[Sync] Fetching incremental alerts since ${sinceTime.toISOString()}...`);
      }
      
      const response = await fetch(url);
      if (!response.ok) {
        throw new Error(`Failed to fetch alerts: ${response.statusText}`);
      }

      const serverAlerts: Alert[] = await response.json();
      console.log(`[Sync] Received ${serverAlerts.length} ${isInitialSync ? 'total' : (forceFullSync ? 'total' : 'new/updated')} alerts from server`);

      // Save new/updated alerts
      if (serverAlerts.length > 0) {
        console.log(`[Sync] Syncing ${serverAlerts.length} alerts to local storage`);
        await localAlertStorage.saveAlerts(serverAlerts);
      } else {
        console.log("[Sync] No new alerts to sync");
      }

      // Clean up deleted alerts during full sync
      if (shouldCleanupDeleted) {
        const localAlerts = await localAlertStorage.getAllAlerts();
        const serverAlertIds = new Set(serverAlerts.map(a => a.id));
        const alertsToDelete = localAlerts.filter(alert => !serverAlertIds.has(alert.id));
        
        if (alertsToDelete.length > 0) {
          console.log(`[Sync] Removing ${alertsToDelete.length} deleted alerts from local storage`);
          for (const alert of alertsToDelete) {
            await localAlertStorage.deleteAlert(alert.id);
          }
        }
      }

      // Update last sync time
      await localAlertStorage.updateLastSyncTime(new Date());

      // Notify listeners
      this.notifyListeners();
    } catch (error) {
      console.error("[Sync] Error syncing alerts:", error);
    } finally {
      this.isSyncing = false;
    }
  }

  /**
   * Add listener for sync completion
   */
  addListener(callback: () => void): void {
    this.listeners.add(callback);
  }

  /**
   * Remove listener
   */
  removeListener(callback: () => void): void {
    this.listeners.delete(callback);
  }

  /**
   * Notify all listeners
   */
  private notifyListeners(): void {
    this.listeners.forEach(callback => callback());
  }

  /**
   * Get sync status
   */
  getSyncStatus(): { isSyncing: boolean; isRunning: boolean } {
    return {
      isSyncing: this.isSyncing,
      isRunning: this.syncInterval !== null,
    };
  }
}

// Export singleton instance
export const alertSyncService = new AlertSyncService();
