// Centralized geographic data for all heat map components
// This file consolidates country ISO codes, abbreviations, and severity weights

// Severity weights for heat calculation (used by all regions)
export const severityWeights: Record<string, number> = {
  critical: 10,
  high: 6,
  moderate: 3,
  info: 1,
};

// All country name to ISO numeric code mappings
export const countryNameToIsoNum: Record<string, string> = {
  // Africa
  "Algeria": "012", "Angola": "024", "Benin": "204", "Botswana": "072",
  "Burkina Faso": "854", "Burundi": "108", "Cabo Verde": "132", "Cameroon": "120",
  "Central African Republic": "140", "Chad": "148", "Comoros": "174", "Congo": "178",
  "Democratic Republic of Congo": "180", "Djibouti": "262", "Egypt": "818",
  "Equatorial Guinea": "226", "Eritrea": "232", "Eswatini": "748", "Ethiopia": "231",
  "Gabon": "266", "Gambia": "270", "Ghana": "288", "Guinea": "324",
  "Guinea-Bissau": "624", "Ivory Coast": "384", "Kenya": "404", "Lesotho": "426",
  "Liberia": "430", "Libya": "434", "Madagascar": "450", "Malawi": "454",
  "Mali": "466", "Mauritania": "478", "Mauritius": "480", "Morocco": "504",
  "Mozambique": "508", "Namibia": "516", "Niger": "562", "Nigeria": "566",
  "Rwanda": "646", "Sao Tome and Principe": "678", "Senegal": "686",
  "Seychelles": "690", "Sierra Leone": "694", "Somalia": "706", "South Africa": "710",
  "South Sudan": "728", "Sudan": "729", "Tanzania": "834", "Togo": "768",
  "Tunisia": "788", "Uganda": "800", "Zambia": "894", "Zimbabwe": "716",
  
  // Asia & Middle East
  "Afghanistan": "004", "Armenia": "051", "Azerbaijan": "031", "Bahrain": "048",
  "Bangladesh": "050", "Bhutan": "064", "Brunei": "096", "Cambodia": "116",
  "China": "156", "Cyprus": "196", "Georgia": "268", "India": "356",
  "Indonesia": "360", "Iran": "364", "Iraq": "368", "Israel": "376",
  "Japan": "392", "Jordan": "400", "Kazakhstan": "398", "Kuwait": "414",
  "Kyrgyzstan": "417", "Laos": "418", "Lebanon": "422", "Malaysia": "458",
  "Maldives": "462", "Mongolia": "496", "Myanmar": "104", "Nepal": "524",
  "North Korea": "408", "Oman": "512", "Pakistan": "586", "Palestine": "275",
  "Philippines": "608", "Qatar": "634", "Russia": "643", "Saudi Arabia": "682",
  "Singapore": "702", "South Korea": "410", "Sri Lanka": "144", "Syria": "760",
  "Taiwan": "158", "Tajikistan": "762", "Thailand": "764", "Timor-Leste": "626",
  "Turkey": "792", "Turkmenistan": "795", "United Arab Emirates": "784",
  "Uzbekistan": "860", "Vietnam": "704", "Yemen": "887",
  
  // Europe
  "Albania": "008", "Andorra": "020", "Austria": "040", "Belarus": "112",
  "Belgium": "056", "Bosnia and Herzegovina": "070", "Bulgaria": "100", "Croatia": "191",
  "Czech Republic": "203", "Denmark": "208", "Estonia": "233", "Finland": "246",
  "France": "250", "Germany": "276", "Greece": "300", "Hungary": "348",
  "Iceland": "352", "Ireland": "372", "Italy": "380", "Kosovo": "383",
  "Latvia": "428", "Liechtenstein": "438", "Lithuania": "440", "Luxembourg": "442",
  "Malta": "470", "Moldova": "498", "Monaco": "492", "Montenegro": "499",
  "Netherlands": "528", "North Macedonia": "807", "Norway": "578", "Poland": "616",
  "Portugal": "620", "Romania": "642", "San Marino": "674", "Serbia": "688",
  "Slovakia": "703", "Slovenia": "705", "Spain": "724", "Sweden": "752",
  "Switzerland": "756", "Ukraine": "804", "United Kingdom": "826", "Vatican City": "336",
  
  // North America & Caribbean
  "United States": "840", "Canada": "124", "Mexico": "484",
  "Belize": "084", "Costa Rica": "188", "El Salvador": "222",
  "Guatemala": "320", "Honduras": "340", "Nicaragua": "558", "Panama": "591",
  "Antigua and Barbuda": "028", "Bahamas": "044", "Barbados": "052",
  "Cuba": "192", "Dominica": "212", "Dominican Republic": "214",
  "Grenada": "308", "Haiti": "332", "Jamaica": "388",
  "Saint Kitts and Nevis": "659", "Saint Lucia": "662",
  "Saint Vincent and the Grenadines": "670", "Trinidad and Tobago": "780",
  
  // South America
  "Argentina": "032", "Bolivia": "068", "Brazil": "076", "Chile": "152",
  "Colombia": "170", "Ecuador": "218", "Guyana": "328", "Paraguay": "600",
  "Peru": "604", "Suriname": "740", "Uruguay": "858", "Venezuela": "862",
  "French Guiana": "254",
};

// Abbreviated country names for map labels
export const countryAbbreviations: Record<string, string> = {
  // Africa
  "Central African Republic": "CAR",
  "Democratic Republic of Congo": "DRC",
  "South Africa": "S. Africa",
  "South Sudan": "S. Sudan",
  "Burkina Faso": "B. Faso",
  "Equatorial Guinea": "Eq. Guinea",
  "Guinea-Bissau": "G-Bissau",
  "Sao Tome and Principe": "STP",
  "Sierra Leone": "S. Leone",
  
  // Asia & Middle East
  "United Arab Emirates": "UAE",
  "Saudi Arabia": "Saudi",
  "North Korea": "N. Korea",
  "South Korea": "S. Korea",
  "Timor-Leste": "T-Leste",
  
  // Europe
  "Bosnia and Herzegovina": "BiH",
  "North Macedonia": "N. Macedonia",
  "United Kingdom": "UK",
  "Czech Republic": "Czechia",
  "Netherlands": "NL",
  "Switzerland": "CH",
  "Vatican City": "Vatican",
  
  // North America
  "United States": "USA",
  "Dominican Republic": "Dom. Rep.",
  "Saint Kitts and Nevis": "St. Kitts",
  "Saint Lucia": "St. Lucia",
  "Saint Vincent and the Grenadines": "St. Vincent",
  "Trinidad and Tobago": "Trinidad",
  
  // South America
  "French Guiana": "Fr. Guiana",
  
  // Central/South Asia
  "Afghanistan": "Afgh.",
  "Bangladesh": "Bang.",
  "Kazakhstan": "Kaz.",
  "Kyrgyzstan": "Kyr.",
  "Tajikistan": "Taj.",
  "Turkmenistan": "Turkm.",
  "Uzbekistan": "Uzb.",
};

// Manual coordinate overrides for countries where centroid is incorrect
export const manualCoordinates: Record<string, [number, number]> = {
  "France": [2.5, 47.0],
};

// Helper function to get country abbreviation (returns original if no abbreviation exists)
export function getCountryAbbreviation(countryName: string): string {
  return countryAbbreviations[countryName] || countryName;
}

// Helper function to get ISO code for a country
export function getCountryIsoCode(countryName: string): string | undefined {
  return countryNameToIsoNum[countryName];
}

// Generate reverse mapping: ISO code to country name
export const isoNumToCountryName: Record<string, string> = Object.entries(countryNameToIsoNum).reduce(
  (acc, [name, code]) => ({ ...acc, [code]: name }),
  {}
);
