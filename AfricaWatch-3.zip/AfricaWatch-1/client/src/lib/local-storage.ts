import type { Alert } from "@shared/schema";

const DB_NAME = "observius-alerts";
const DB_VERSION = 1;
const ALERTS_STORE = "alerts";
const LAST_SYNC_STORE = "metadata";

/**
 * IndexedDB wrapper for client-side alert storage
 * Each user maintains their own local copy of alerts
 */
class LocalAlertStorage {
  private db: IDBDatabase | null = null;

  /**
   * Initialize IndexedDB database
   */
  async init(): Promise<void> {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);

      request.onerror = () => reject(request.error);
      request.onsuccess = () => {
        this.db = request.result;
        resolve();
      };

      request.onupgradeneeded = (event) => {
        const db = (event.target as IDBOpenDBRequest).result;

        // Create alerts object store if it doesn't exist
        if (!db.objectStoreNames.contains(ALERTS_STORE)) {
          const alertsStore = db.createObjectStore(ALERTS_STORE, { keyPath: "id" });
          // Create indexes for efficient queries
          alertsStore.createIndex("region", "region", { unique: false });
          alertsStore.createIndex("country", "country", { unique: false });
          alertsStore.createIndex("timestamp", "timestamp", { unique: false });
          alertsStore.createIndex("severity", "severity", { unique: false });
        }

        // Create metadata store for sync tracking
        if (!db.objectStoreNames.contains(LAST_SYNC_STORE)) {
          db.createObjectStore(LAST_SYNC_STORE, { keyPath: "key" });
        }
      };
    });
  }

  /**
   * Get all alerts from local storage
   */
  async getAllAlerts(region?: string): Promise<Alert[]> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([ALERTS_STORE], "readonly");
      const store = transaction.objectStore(ALERTS_STORE);

      let request: IDBRequest;

      if (region) {
        // Use region index for filtered query
        const index = store.index("region");
        request = index.getAll(region);
      } else {
        request = store.getAll();
      }

      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Get alert by ID
   */
  async getAlertById(id: string): Promise<Alert | undefined> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([ALERTS_STORE], "readonly");
      const store = transaction.objectStore(ALERTS_STORE);
      const request = store.get(id);

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Add or update alerts in bulk
   */
  async saveAlerts(alerts: Alert[]): Promise<void> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([ALERTS_STORE], "readwrite");
      const store = transaction.objectStore(ALERTS_STORE);

      transaction.oncomplete = () => resolve();
      transaction.onerror = () => reject(transaction.error);

      for (const alert of alerts) {
        store.put(alert); // Put will add or update
      }
    });
  }

  /**
   * Delete alert by ID
   */
  async deleteAlert(id: string): Promise<void> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([ALERTS_STORE], "readwrite");
      const store = transaction.objectStore(ALERTS_STORE);
      const request = store.delete(id);

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Clear all local alerts
   */
  async clearAllAlerts(): Promise<void> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([ALERTS_STORE], "readwrite");
      const store = transaction.objectStore(ALERTS_STORE);
      const request = store.clear();

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Get count of alerts
   */
  async getAlertCount(region?: string): Promise<number> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([ALERTS_STORE], "readonly");
      const store = transaction.objectStore(ALERTS_STORE);

      let request: IDBRequest;

      if (region) {
        const index = store.index("region");
        request = index.count(region);
      } else {
        request = store.count();
      }

      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Get last sync timestamp
   */
  async getLastSyncTime(): Promise<Date | null> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([LAST_SYNC_STORE], "readonly");
      const store = transaction.objectStore(LAST_SYNC_STORE);
      const request = store.get("lastSync");

      request.onsuccess = () => {
        const result = request.result;
        resolve(result ? new Date(result.value) : null);
      };
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Update last sync timestamp
   */
  async updateLastSyncTime(timestamp: Date): Promise<void> {
    if (!this.db) await this.init();

    return new Promise((resolve, reject) => {
      const transaction = this.db!.transaction([LAST_SYNC_STORE], "readwrite");
      const store = transaction.objectStore(LAST_SYNC_STORE);
      const request = store.put({ key: "lastSync", value: timestamp.toISOString() });

      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  }

  /**
   * Export alerts to CSV
   */
  async exportToCSV(): Promise<string> {
    const alerts = await this.getAllAlerts();

    const headers = ["Timestamp", "Region", "Country", "Severity", "Title", "Description", "Location", "Source", "URL"];
    const csvRows = [headers.join(",")];

    for (const alert of alerts) {
      const row = [
        new Date(alert.timestamp).toISOString(),
        `"${alert.region}"`,
        `"${alert.country}"`,
        alert.severity,
        `"${(alert.title || '').replace(/"/g, '""')}"`,
        `"${(alert.description || '').replace(/"/g, '""')}"`,
        `"${(alert.location || '').replace(/"/g, '""')}"`,
        `"${(alert.source || '').replace(/"/g, '""')}"`,
        `"${(alert.sourceUrl || '').replace(/"/g, '""')}"`
      ];
      csvRows.push(row.join(","));
    }

    return csvRows.join("\n");
  }
}

// Export singleton instance
export const localAlertStorage = new LocalAlertStorage();
