import { PushNotifications, Token, PushNotificationSchema } from '@capacitor/push-notifications';
import { LocalNotifications } from '@capacitor/local-notifications';
import { Capacitor } from '@capacitor/core';

export interface NotificationService {
  initialize(): Promise<void>;
  requestPermission(): Promise<boolean>;
  scheduleLocalNotification(title: string, body: string, severity: 'critical' | 'high' | 'moderate' | 'info'): Promise<void>;
}

class CapacitorNotificationService implements NotificationService {
  private isNativePlatform: boolean;

  constructor() {
    this.isNativePlatform = Capacitor.isNativePlatform();
  }

  async initialize(): Promise<void> {
    if (!this.isNativePlatform) {
      console.log('Not a native platform, skipping push notification initialization');
      return;
    }

    // Register for push notifications
    await PushNotifications.addListener('registration', (token: Token) => {
      console.log('Push registration success, token: ' + token.value);
      // TODO: Send token to backend for storing user device tokens
    });

    await PushNotifications.addListener('registrationError', (error: any) => {
      console.error('Error on registration: ' + JSON.stringify(error));
    });

    await PushNotifications.addListener(
      'pushNotificationReceived',
      (notification: PushNotificationSchema) => {
        console.log('Push received: ' + JSON.stringify(notification));
      }
    );

    await PushNotifications.addListener(
      'pushNotificationActionPerformed',
      (notification: any) => {
        console.log('Push action performed: ' + JSON.stringify(notification));
        // Navigate to alert details when notification is tapped
      }
    );
  }

  async requestPermission(): Promise<boolean> {
    if (!this.isNativePlatform) {
      return false;
    }

    try {
      const permStatus = await PushNotifications.checkPermissions();

      if (permStatus.receive === 'prompt') {
        const result = await PushNotifications.requestPermissions();
        if (result.receive === 'granted') {
          await PushNotifications.register();
          return true;
        }
        return false;
      }

      if (permStatus.receive !== 'granted') {
        return false;
      }

      // Permission already granted, ensure registration
      await PushNotifications.register();
      return true;
    } catch (error) {
      console.error('Error requesting push notification permission:', error);
      return false;
    }
  }

  async scheduleLocalNotification(
    title: string,
    body: string,
    severity: 'critical' | 'high' | 'moderate' | 'info'
  ): Promise<void> {
    if (!this.isNativePlatform) {
      // Fall back to browser notifications on web
      if ('Notification' in window && Notification.permission === 'granted') {
        new Notification(title, { body });
      }
      return;
    }

    try {
      // Request permission for local notifications
      const permResult = await LocalNotifications.checkPermissions();
      if (permResult.display === 'prompt') {
        await LocalNotifications.requestPermissions();
      }

      // Schedule local notification
      await LocalNotifications.schedule({
        notifications: [
          {
            title,
            body,
            id: Math.floor(Math.random() * 1000000),
            schedule: { at: new Date(Date.now() + 1000) }, // 1 second from now
            sound: severity === 'critical' ? 'beep.wav' : undefined,
            actionTypeId: '',
            extra: { severity },
          },
        ],
      });
    } catch (error) {
      console.error('Error scheduling local notification:', error);
    }
  }
}

// Export singleton instance
export const notificationService = new CapacitorNotificationService();
