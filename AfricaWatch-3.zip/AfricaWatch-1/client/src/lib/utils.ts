import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { type SeverityLevel, type AfricanCountry } from "@shared/schema";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

// Severity configuration matching design guidelines
export const severityConfig = {
  critical: {
    label: "Critical Violence",
    color: "severity-critical",
    bgClass: "bg-severity-critical/10 dark:bg-severity-critical/20",
    textClass: "text-severity-critical",
    badgeClass: "bg-severity-critical/15 text-severity-critical border-severity-critical/30",
  },
  high: {
    label: "High Alert - Protest",
    color: "severity-high",
    bgClass: "bg-severity-high/10 dark:bg-severity-high/20",
    textClass: "text-severity-high",
    badgeClass: "bg-severity-high/15 text-severity-high border-severity-high/30",
  },
  moderate: {
    label: "Moderate Instability",
    color: "severity-moderate",
    bgClass: "bg-severity-moderate/10 dark:bg-severity-moderate/20",
    textClass: "text-severity-moderate",
    badgeClass: "bg-severity-moderate/15 text-severity-moderate border-severity-moderate/30",
  },
  info: {
    label: "Information",
    color: "severity-info",
    bgClass: "bg-severity-info/10 dark:bg-severity-info/20",
    textClass: "text-severity-info",
    badgeClass: "bg-severity-info/15 text-severity-info border-severity-info/30",
  },
} as const;

export function getSeverityConfig(severity: string) {
  return severityConfig[severity as SeverityLevel] || severityConfig.info;
}

export function formatTimestamp(timestamp: string | Date) {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);
  const diffHours = Math.floor(diffMs / 3600000);
  const diffDays = Math.floor(diffMs / 86400000);

  if (diffMins < 1) return "Just now";
  if (diffMins < 60) return `${diffMins}m ago`;
  if (diffHours < 24) return `${diffHours}h ago`;
  if (diffDays < 7) return `${diffDays}d ago`;
  
  return date.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric',
    year: date.getFullYear() !== now.getFullYear() ? 'numeric' : undefined 
  });
}
