import { createRoot } from "react-dom/client";
import App from "./App";
import "./index.css";

createRoot(document.getElementById("root")!).render(<App />);

// Register service worker for PWA functionality
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker
      .register('/sw.js')
      .then((registration) => {
        console.log('[PWA] Service Worker registered:', registration.scope);
        
        // PERFORMANCE OPTIMIZATION: Check for updates every 30 minutes instead of every minute
        setInterval(() => {
          // Only check if document is visible to reduce unnecessary checks
          if (!document.hidden) {
            registration.update();
          }
        }, 30 * 60 * 1000); // Check every 30 minutes
      })
      .catch((error) => {
        console.error('[PWA] Service Worker registration failed:', error);
      });
  });
}
