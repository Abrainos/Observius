import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Mail, Users, CheckCircle, XCircle, LogOut, Trash2, Send, Power } from "lucide-react";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { NewsletterSubscriber } from "@shared/schema";
import { useState } from "react";

export default function AdminNewsletter() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [subscriberToDelete, setSubscriberToDelete] = useState<NewsletterSubscriber | null>(null);

  const { data: authStatus } = useQuery<{ isAuthenticated: boolean }>({
    queryKey: ["/api/admin/status"],
  });

  const { data: subscribers = [], isLoading } = useQuery<NewsletterSubscriber[]>({
    queryKey: ["/api/newsletter/subscribers"],
    enabled: authStatus?.isAuthenticated === true,
  });

  const { data: newsletterStatus } = useQuery<{ enabled: boolean }>({
    queryKey: ["/api/admin/newsletter/status"],
    enabled: authStatus?.isAuthenticated === true,
  });

  const logoutMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/admin/logout", {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/status"] });
      setLocation("/admin/login");
      toast({
        title: "Logged Out",
        description: "You have been successfully logged out",
      });
    },
  });

  const deleteSubscriberMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/newsletter/subscribers/${id}`, {});
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/newsletter/subscribers"] });
      toast({
        title: "Subscriber Deleted",
        description: "The subscriber has been permanently removed",
      });
      setSubscriberToDelete(null);
    },
    onError: () => {
      toast({
        title: "Delete Failed",
        description: "Failed to delete subscriber",
        variant: "destructive",
      });
    },
  });

  const sendTestNewsletterMutation = useMutation({
    mutationFn: async () => {
      console.log("Sending test newsletter request...");
      const res = await apiRequest("POST", "/api/admin/newsletter/send-test", {});
      const data = await res.json();
      console.log("Newsletter response:", data);
      return data;
    },
    onSuccess: (data: { sent: number; failed: number }) => {
      console.log("Newsletter sent successfully:", data);
      toast({
        title: "Newsletter Sent!",
        description: `Successfully sent to ${data.sent} subscriber(s). ${data.failed > 0 ? `Failed: ${data.failed}` : ''}`,
      });
    },
    onError: (error: any) => {
      console.error("Newsletter send error:", error);
      toast({
        title: "Send Failed",
        description: error.message || "Failed to send newsletter",
        variant: "destructive",
      });
    },
  });

  const toggleNewsletterMutation = useMutation({
    mutationFn: async (enabled: boolean) => {
      const res = await apiRequest("POST", "/api/admin/newsletter/toggle", { enabled });
      return await res.json();
    },
    onSuccess: (data: { enabled: boolean; message: string }) => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/newsletter/status"] });
      toast({
        title: data.enabled ? "Newsletter Enabled" : "Newsletter Disabled",
        description: data.message,
      });
    },
    onError: () => {
      toast({
        title: "Toggle Failed",
        description: "Failed to toggle newsletter feature",
        variant: "destructive",
      });
    },
  });

  if (!authStatus) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <Skeleton className="h-8 w-48" />
      </div>
    );
  }

  if (!authStatus.isAuthenticated) {
    setLocation("/admin/login");
    return null;
  }

  const activeCount = subscribers.filter(sub => sub.isActive).length;
  const inactiveCount = subscribers.filter(sub => !sub.isActive).length;

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div className="space-y-2">
          <h1 className="text-3xl font-bold tracking-tight" data-testid="text-admin-title">
            Newsletter Subscribers
          </h1>
          <p className="text-muted-foreground">
            Manage and view all newsletter subscribers
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            variant="default"
            onClick={() => sendTestNewsletterMutation.mutate()}
            disabled={sendTestNewsletterMutation.isPending || activeCount === 0}
            data-testid="button-send-test"
          >
            <Send className="h-4 w-4 mr-2" />
            {sendTestNewsletterMutation.isPending ? "Sending..." : "Send Test Newsletter"}
          </Button>
          <Button
            variant="outline"
            onClick={() => logoutMutation.mutate()}
            disabled={logoutMutation.isPending}
            data-testid="button-logout"
          >
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Subscribers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold" data-testid="text-total-subscribers">
              {isLoading ? <Skeleton className="h-8 w-16" /> : subscribers.length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600" data-testid="text-active-subscribers">
              {isLoading ? <Skeleton className="h-8 w-16" /> : activeCount}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Unsubscribed</CardTitle>
            <XCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-muted-foreground" data-testid="text-inactive-subscribers">
              {isLoading ? <Skeleton className="h-8 w-16" /> : inactiveCount}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Newsletter Feature</CardTitle>
            <Power className={`h-4 w-4 ${newsletterStatus?.enabled ? 'text-green-600' : 'text-muted-foreground'}`} />
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Switch
                id="newsletter-toggle"
                checked={newsletterStatus?.enabled ?? false}
                onCheckedChange={(checked) => toggleNewsletterMutation.mutate(checked)}
                disabled={toggleNewsletterMutation.isPending}
                data-testid="switch-newsletter-toggle"
              />
              <Label htmlFor="newsletter-toggle" className="text-sm font-medium cursor-pointer">
                {newsletterStatus?.enabled ? 'Enabled' : 'Disabled'}
              </Label>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Subscribers Table */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            All Subscribers
          </CardTitle>
          <CardDescription>
            View all newsletter subscribers and their subscription status
          </CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
              <Skeleton className="h-10 w-full" />
            </div>
          ) : subscribers.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No subscribers yet
            </div>
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Email</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Subscribed Date</TableHead>
                    <TableHead className="hidden md:table-cell">Unsubscribe Token</TableHead>
                    <TableHead className="text-right">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {subscribers.map((subscriber) => (
                    <TableRow key={subscriber.id} data-testid={`row-subscriber-${subscriber.id}`}>
                      <TableCell className="font-medium" data-testid={`text-email-${subscriber.id}`}>
                        {subscriber.email}
                      </TableCell>
                      <TableCell>
                        <Badge 
                          variant={subscriber.isActive ? "default" : "secondary"}
                          data-testid={`badge-status-${subscriber.id}`}
                        >
                          {subscriber.isActive ? "Active" : "Unsubscribed"}
                        </Badge>
                      </TableCell>
                      <TableCell data-testid={`text-date-${subscriber.id}`}>
                        {format(new Date(subscriber.subscribedAt), "PPP")}
                      </TableCell>
                      <TableCell className="hidden md:table-cell font-mono text-xs text-muted-foreground">
                        {subscriber.unsubscribeToken}
                      </TableCell>
                      <TableCell className="text-right">
                        <Button
                          variant="ghost"
                          size="icon"
                          onClick={() => setSubscriberToDelete(subscriber)}
                          data-testid={`button-delete-${subscriber.id}`}
                        >
                          <Trash2 className="h-4 w-4 text-destructive" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={!!subscriberToDelete} onOpenChange={(open) => !open && setSubscriberToDelete(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Subscriber</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to permanently delete <strong>{subscriberToDelete?.email}</strong>?
              This action cannot be undone and will remove all subscriber data.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => subscriberToDelete && deleteSubscriberMutation.mutate(subscriberToDelete.id)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              {deleteSubscriberMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
