import { useState, useMemo, useEffect } from "react";
import { type Alert, type AlertFilter } from "@shared/schema";
import { AlertCard } from "@/components/alert-card";
import { EmptyState } from "@/components/empty-state";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Filter, X, Search, Download, Trash2 } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { getSeverityConfig } from "@/lib/utils";
import { useToast } from "@/hooks/use-toast";
import { useRegion } from "@/contexts/region-context";
import { useLocalAlerts } from "@/hooks/use-local-alerts";
import { localAlertStorage } from "@/lib/local-storage";

interface AlertHistoryProps {
  selectedCountries: string[];
}

export default function AlertHistory({ selectedCountries }: AlertHistoryProps) {
  const [severityFilter, setSeverityFilter] = useState<string>("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [isClearing, setIsClearing] = useState(false);
  const { toast } = useToast();
  const { selectedRegion } = useRegion();

  const { data: alerts = [], isLoading, refetch } = useLocalAlerts({
    region: selectedRegion,
    autoSync: true,
  });

  const handleClearAll = async () => {
    setIsClearing(true);
    try {
      await localAlertStorage.clearAllAlerts();
      await refetch();
      toast({
        title: "History cleared",
        description: "All local alerts have been deleted successfully",
      });
      setShowClearDialog(false);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to clear alert history",
        variant: "destructive",
      });
    } finally {
      setIsClearing(false);
    }
  };

  const handleExportCSV = async () => {
    try {
      const csvContent = await localAlertStorage.exportToCSV();
      const blob = new Blob([csvContent], { type: "text/csv" });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = `observius-alerts-${new Date().toISOString().split('T')[0]}.csv`;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
      
      toast({
        title: "Export complete",
        description: "Your CSV file has been downloaded",
      });
    } catch (error) {
      toast({
        title: "Export failed",
        description: "Could not export alerts to CSV",
        variant: "destructive",
      });
    }
  };

  // Apply filters
  const filteredAlerts = alerts.filter((alert) => {
    // Filter by selected countries
    if (selectedCountries.length > 0 && !selectedCountries.includes(alert.country)) {
      return false;
    }

    // Filter by severity
    if (severityFilter !== "all" && alert.severity !== severityFilter) {
      return false;
    }

    // Filter by search query (searches across all text fields)
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        alert.title.toLowerCase().includes(query) ||
        alert.description.toLowerCase().includes(query) ||
        alert.location.toLowerCase().includes(query) ||
        alert.country.toLowerCase().includes(query) ||
        alert.source.toLowerCase().includes(query) ||
        (alert.sourceUrl?.toLowerCase() || "").includes(query) ||
        (alert.violenceDetails?.toLowerCase() || "").includes(query) ||
        (alert.policeIntervention?.toLowerCase() || "").includes(query) ||
        (alert.aiAnalysis?.toLowerCase() || "").includes(query)
      );
    }

    return true;
  });

  // Sort by timestamp (newest first)
  const sortedAlerts = [...filteredAlerts].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  const hasActiveFilters = severityFilter !== "all" || searchQuery !== "";

  if (isLoading) {
    return (
      <div className="space-y-6">
        <Skeleton className="h-10 w-64" />
        <div className="flex gap-3">
          <Skeleton className="h-10 flex-1" />
          <Skeleton className="h-10 w-40" />
        </div>
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6 space-y-4">
                <Skeleton className="h-5 w-32" />
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-full" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6" data-testid="alert-history">
      <div>
        <h2 className="text-2xl font-bold mb-1" data-testid="text-history-title">
          Alert History
        </h2>
        <p className="text-sm text-muted-foreground">
          Browse and filter all detected incidents
        </p>
      </div>

      <div className="flex gap-3 flex-wrap">
        <div className="relative flex-1 min-w-[250px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search by keyword (title, location, source, details...)"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
            data-testid="input-search"
          />
        </div>

        <Select value={severityFilter} onValueChange={setSeverityFilter}>
          <SelectTrigger className="w-[180px]" data-testid="select-severity">
            <Filter className="h-4 w-4 mr-2" />
            <SelectValue placeholder="Severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Severities</SelectItem>
            <SelectItem value="critical">Critical Violence</SelectItem>
            <SelectItem value="high">High Alert</SelectItem>
            <SelectItem value="moderate">Moderate</SelectItem>
            <SelectItem value="info">Information</SelectItem>
          </SelectContent>
        </Select>

        {hasActiveFilters && (
          <Button
            variant="ghost"
            onClick={() => {
              setSeverityFilter("all");
              setSearchQuery("");
            }}
            className="gap-2"
            data-testid="button-clear-filters"
          >
            <X className="h-4 w-4" />
            Clear Filters
          </Button>
        )}
      </div>

      {hasActiveFilters && (
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-sm text-muted-foreground">Active filters:</span>
          {severityFilter !== "all" && (
            <Badge variant="secondary" className="gap-1">
              {getSeverityConfig(severityFilter).label}
              <button
                onClick={() => setSeverityFilter("all")}
                className="ml-1 hover:bg-background/20 rounded-sm"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
          {searchQuery && (
            <Badge variant="secondary" className="gap-1">
              Search: "{searchQuery}"
              <button
                onClick={() => setSearchQuery("")}
                className="ml-1 hover:bg-background/20 rounded-sm"
              >
                <X className="h-3 w-3" />
              </button>
            </Badge>
          )}
        </div>
      )}

      <div className="flex items-center justify-between gap-3 flex-wrap">
        <p className="text-sm text-muted-foreground" data-testid="text-results-count">
          {sortedAlerts.length} {sortedAlerts.length === 1 ? 'result' : 'results'}
        </p>
        
        <div className="flex gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={handleExportCSV}
            disabled={alerts.length === 0}
            className="gap-2"
            data-testid="button-export-csv"
          >
            <Download className="h-4 w-4" />
            Export CSV
          </Button>
          
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowClearDialog(true)}
            disabled={alerts.length === 0}
            className="gap-2"
            data-testid="button-clear-history"
          >
            <Trash2 className="h-4 w-4" />
            Clear All
          </Button>
        </div>
      </div>

      <AlertDialog open={showClearDialog} onOpenChange={setShowClearDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Clear All Local Alert History?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete all {alerts.length} alerts from your local storage. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-clear">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleClearAll}
              disabled={isClearing}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-clear"
            >
              {isClearing ? "Clearing..." : "Clear All Alerts"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {sortedAlerts.length === 0 ? (
        <EmptyState 
          type={hasActiveFilters ? "no-results" : selectedCountries.length === 0 ? "no-countries" : "no-alerts"} 
          className="min-h-[40vh]" 
        />
      ) : (
        <div className="space-y-4" data-testid="alert-history-feed">
          {sortedAlerts.map((alert) => (
            <AlertCard key={alert.id} alert={alert} />
          ))}
        </div>
      )}
    </div>
  );
}
