import { type Alert } from "@shared/schema";
import { AlertCard } from "@/components/alert-card";
import { EmptyState } from "@/components/empty-state";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { AfricaHeatMap } from "@/components/africa-heat-map";
import { AsiaHeatMap } from "@/components/asia-heat-map";
import { EuropeHeatMap } from "@/components/europe-heat-map";
import { MiddleEastHeatMap } from "@/components/middle-east-heat-map";
import { SouthAmericaHeatMap } from "@/components/south-america-heat-map";
import { NorthAmericaHeatMap } from "@/components/north-america-heat-map";
import { CentralSouthAsiaHeatMap } from "@/components/central-south-asia-heat-map";
import { CountryAlertsDialog } from "@/components/country-alerts-dialog";
import { NewsletterSignup } from "@/components/newsletter-signup";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight, Languages } from "lucide-react";
import { useState, useEffect } from "react";
import { useRegion } from "@/contexts/region-context";
import { useLocalAlerts } from "@/hooks/use-local-alerts";
import { useTranslationSettings } from "@/contexts/translation-context";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";

interface DashboardProps {
  selectedCountries: string[];
}

export default function Dashboard({ selectedCountries }: DashboardProps) {
  const [displayLimit, setDisplayLimit] = useState<string>("all");
  const [currentPage, setCurrentPage] = useState<number>(1);
  const [selectedCountry, setSelectedCountry] = useState<string | null>(null);
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const { selectedRegion } = useRegion();
  const { showOriginalLanguage, setShowOriginalLanguage } = useTranslationSettings();

  const handleCountryClick = (country: string) => {
    setSelectedCountry(country);
    setIsDialogOpen(true);
  };

  // Fetch ALL alerts from local storage (filtered by region)
  const { data: allAlerts = [], isLoading: allAlertsLoading } = useLocalAlerts({
    region: selectedRegion,
    autoSync: true,
  });

  // Filter alerts by selected countries for the feed
  const filteredAlerts = selectedCountries.length > 0
    ? allAlerts.filter((alert) => selectedCountries.includes(alert.country))
    : [];

  // Sort by timestamp (newest first)
  const sortedAlerts = [...filteredAlerts].sort(
    (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
  );

  // Calculate pagination
  const itemsPerPage = displayLimit === "all" ? sortedAlerts.length : parseInt(displayLimit);
  const totalPages = displayLimit === "all" ? 1 : Math.ceil(sortedAlerts.length / itemsPerPage);
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = startIndex + itemsPerPage;

  // Apply pagination
  const displayedAlerts = displayLimit === "all" 
    ? sortedAlerts 
    : sortedAlerts.slice(startIndex, endIndex);

  // Reset to page 1 when display limit changes
  useEffect(() => {
    setCurrentPage(1);
  }, [displayLimit]);

  // Reset to page 1 when filtered alerts change
  useEffect(() => {
    if (currentPage > totalPages && totalPages > 0) {
      setCurrentPage(1);
    }
  }, [sortedAlerts.length, currentPage, totalPages]);

  return (
    <div className="space-y-6">
      {/* Hero Section */}
      <div className="text-center space-y-4 py-8">
        <h1 className="text-4xl sm:text-5xl md:text-6xl font-bold tracking-tight" data-testid="text-hero-title">
          Observius
        </h1>
        <p className="text-xl sm:text-2xl font-semibold text-primary" data-testid="text-hero-motto">
          Know Before It's News. Act Before The Crisis.
        </p>
        <p className="text-base sm:text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed" data-testid="text-hero-description">
          Real-time global stability monitoring across 185 countries. Track armed conflicts, civil unrest, protests, drug trafficking, and geopolitical threats. Monitor Africa, Asia, Europe, Middle East, South America, North America, and Central/South Asia for instant crisis alerts, security incidents, and breaking conflicts. Your comprehensive international stability detection and safety platform.
        </p>
      </div>

      {/* Newsletter Signup */}
      <div className="max-w-3xl mx-auto">
        <NewsletterSignup />
      </div>

      {/* Heat Map - Always visible */}
      {allAlertsLoading ? (
        <Card>
          <CardContent className="p-6">
            <Skeleton className="h-[400px] w-full" />
          </CardContent>
        </Card>
      ) : selectedRegion === "africa" ? (
        <AfricaHeatMap alerts={allAlerts} onCountryClick={handleCountryClick} />
      ) : selectedRegion === "asia" ? (
        <AsiaHeatMap alerts={allAlerts} onCountryClick={handleCountryClick} />
      ) : selectedRegion === "europe" ? (
        <EuropeHeatMap alerts={allAlerts} onCountryClick={handleCountryClick} />
      ) : selectedRegion === "middleeast" ? (
        <MiddleEastHeatMap alerts={allAlerts} onCountryClick={handleCountryClick} />
      ) : selectedRegion === "southamerica" ? (
        <SouthAmericaHeatMap alerts={allAlerts} onCountryClick={handleCountryClick} />
      ) : selectedRegion === "northamerica" ? (
        <NorthAmericaHeatMap alerts={allAlerts} onCountryClick={handleCountryClick} />
      ) : (
        <CentralSouthAsiaHeatMap alerts={allAlerts} onCountryClick={handleCountryClick} />
      )}

      {/* Country Alerts Dialog */}
      <CountryAlertsDialog
        open={isDialogOpen}
        onOpenChange={setIsDialogOpen}
        country={selectedCountry}
        alerts={allAlerts}
      />

      {/* Alert Feed Section */}
      <div className="space-y-4" data-testid="dashboard-alerts">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold" data-testid="text-dashboard-title">
              Live Alert Feed
            </h2>
            <p className="text-sm text-muted-foreground">
              {selectedCountries.length === 0 
                ? "No countries selected" 
                : `Monitoring ${selectedCountries.length} ${selectedCountries.length === 1 ? 'country' : 'countries'}`}
            </p>
          </div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3">
            <div className="text-left sm:text-right">
              <p className="text-sm font-medium" data-testid="text-alert-count">
                {sortedAlerts.length} {sortedAlerts.length === 1 ? 'Alert' : 'Alerts'}
              </p>
              <p className="text-xs text-muted-foreground">
                {displayLimit === "all" 
                  ? "Showing all alerts" 
                  : sortedAlerts.length === 0 
                    ? "Showing 0 of 0"
                    : `Showing ${startIndex + 1}-${Math.min(endIndex, sortedAlerts.length)} of ${sortedAlerts.length}`}
              </p>
            </div>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button
                  variant={showOriginalLanguage ? "default" : "outline"}
                  size="icon"
                  onClick={() => setShowOriginalLanguage(!showOriginalLanguage)}
                  data-testid="button-toggle-language"
                >
                  <Languages className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent>
                <p>{showOriginalLanguage ? "Show English" : "Show Original Language"}</p>
              </TooltipContent>
            </Tooltip>
            <Select value={displayLimit} onValueChange={setDisplayLimit}>
              <SelectTrigger className="w-[130px]" data-testid="select-display-limit">
                <SelectValue placeholder="Display limit" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="20" data-testid="option-limit-20">Show 20</SelectItem>
                <SelectItem value="50" data-testid="option-limit-50">Show 50</SelectItem>
                <SelectItem value="100" data-testid="option-limit-100">Show 100</SelectItem>
                <SelectItem value="all" data-testid="option-limit-all">Show All</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {selectedCountries.length === 0 ? (
          <EmptyState type="no-countries" className="min-h-[40vh]" />
        ) : sortedAlerts.length === 0 ? (
          <EmptyState type="no-alerts" className="min-h-[40vh]" />
        ) : (
          <>
            <div className="space-y-4" data-testid="alert-feed">
              {displayedAlerts.map((alert) => (
                <AlertCard key={alert.id} alert={alert} />
              ))}
            </div>

            {/* Pagination Controls - Only show when not "all" and more than 1 page */}
            {displayLimit !== "all" && totalPages > 1 && (
              <div className="flex items-center justify-center gap-2 pt-6" data-testid="pagination-controls">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                  disabled={currentPage === 1}
                  data-testid="button-prev-page"
                >
                  <ChevronLeft className="h-4 w-4" />
                  Previous
                </Button>

                <div className="flex items-center gap-1">
                  {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
                    let pageNumber: number;
                    
                    if (totalPages <= 7) {
                      pageNumber = i + 1;
                    } else if (currentPage <= 4) {
                      pageNumber = i + 1;
                    } else if (currentPage >= totalPages - 3) {
                      pageNumber = totalPages - 6 + i;
                    } else {
                      pageNumber = currentPage - 3 + i;
                    }

                    const isCurrentPage = pageNumber === currentPage;

                    return (
                      <Button
                        key={pageNumber}
                        variant={isCurrentPage ? "default" : "outline"}
                        size="sm"
                        onClick={() => setCurrentPage(pageNumber)}
                        className="min-w-[40px]"
                        data-testid={`button-page-${pageNumber}`}
                      >
                        {pageNumber}
                      </Button>
                    );
                  })}
                </div>

                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                  disabled={currentPage === totalPages}
                  data-testid="button-next-page"
                >
                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
