import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Shield, Globe, Bell, Map, Lock, Eye } from "lucide-react";

export default function Landing() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="border-b">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <div className="flex items-center gap-2">
            <Shield className="h-6 w-6 text-primary" />
            <h1 className="text-xl font-bold">Observius - Global Event Monitor</h1>
          </div>
          <Button 
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-login"
          >
            Sign In
          </Button>
        </div>
      </header>

      <main className="flex-1 container mx-auto px-4 py-16 max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">
            Monitor Global Security in Real-Time
          </h2>
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            Track armed conflicts, protests, and security incidents across 165 countries in Africa, Asia, Europe, and the Middle East with AI-powered analysis and instant notifications.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-get-started"
          >
            Get Started
          </Button>
        </div>

        <div className="grid md:grid-cols-3 gap-6 mb-16">
          <Card>
            <CardContent className="pt-6">
              <Globe className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-lg font-semibold mb-2">Comprehensive Coverage</h3>
              <p className="text-sm text-muted-foreground">
                Monitor 165 countries across Africa, Asia, Europe, and the Middle East with multilingual news sources in 14+ languages.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <Map className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-lg font-semibold mb-2">Interactive Heat Maps</h3>
              <p className="text-sm text-muted-foreground">
                Visualize incidents on interactive regional maps with precise location tracking and severity indicators across all four regions.
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="pt-6">
              <Bell className="h-12 w-12 text-primary mb-4" />
              <h3 className="text-lg font-semibold mb-2">Instant Alerts</h3>
              <p className="text-sm text-muted-foreground">
                Receive immediate notifications for critical security events with historical context and AI analysis.
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="bg-card border rounded-lg p-8 mb-16">
          <h3 className="text-2xl font-bold mb-6 text-center">Key Features</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="flex gap-4">
              <Eye className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold mb-1">AI-Powered Analysis</h4>
                <p className="text-sm text-muted-foreground">
                  Advanced AI categorizes incidents by severity and provides detailed historical context for every event.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <Lock className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold mb-1">Personal Dashboard</h4>
                <p className="text-sm text-muted-foreground">
                  Your own private monitoring space - customize countries, manage alerts, and export data.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <Globe className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold mb-1">Multilingual Support</h4>
                <p className="text-sm text-muted-foreground">
                  Automatic translation from 14+ languages including French, Arabic, German, Spanish, Chinese, Japanese, and more.
                </p>
              </div>
            </div>
            <div className="flex gap-4">
              <Map className="h-6 w-6 text-primary flex-shrink-0 mt-1" />
              <div>
                <h4 className="font-semibold mb-1">Location Mapping</h4>
                <p className="text-sm text-muted-foreground">
                  Precise geocoding shows exact event locations with interactive heat maps and city-level detail.
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="text-center">
          <h3 className="text-2xl font-bold mb-4">Ready to start monitoring?</h3>
          <p className="text-muted-foreground mb-6">
            Sign in to create your personal global security monitoring dashboard.
          </p>
          <Button 
            size="lg"
            onClick={() => window.location.href = '/api/login'}
            data-testid="button-signin"
          >
            Sign In Now
          </Button>
        </div>
      </main>

      <footer className="border-t py-8">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>Observius - Global Event Monitor</p>
        </div>
      </footer>
    </div>
  );
}
