import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Settings2, RefreshCw, Save, Bell, BellRing, Languages } from "lucide-react";
import { notificationService } from "@/lib/notifications";
import { useNotificationSettings } from "@/contexts/notification-context";
import { useTranslationSettings } from "@/contexts/translation-context";
import { Capacitor } from '@capacitor/core';

interface MonitoringSettings {
  intervalMinutes: number;
  message: string;
}

export default function Settings() {
  const { toast } = useToast();
  const [intervalValue, setIntervalValue] = useState("");
  const { notificationsEnabled, setNotificationsEnabled } = useNotificationSettings();
  const { showOriginalLanguage, setShowOriginalLanguage } = useTranslationSettings();
  const isNativePlatform = Capacitor.isNativePlatform();

  // Just read monitoring status (actual polling happens in App.tsx)
  const isMonitoring = notificationsEnabled && isNativePlatform;

  const { data: settings, isLoading } = useQuery<MonitoringSettings>({
    queryKey: ["/api/settings/monitoring"],
  });

  const updateSettingsMutation = useMutation({
    mutationFn: async (intervalMinutes: number) => {
      const res = await apiRequest("POST", "/api/settings/monitoring", { intervalMinutes });
      return res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings/monitoring"] });
      toast({
        title: "Settings Updated",
        description: data.message || "Monitoring interval updated successfully",
      });
      setIntervalValue("");
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update settings",
        variant: "destructive",
      });
    },
  });

  const handleSave = () => {
    const interval = parseInt(intervalValue, 10);
    if (isNaN(interval) || interval < 1) {
      toast({
        title: "Invalid Input",
        description: "Please enter a valid number greater than 0",
        variant: "destructive",
      });
      return;
    }
    updateSettingsMutation.mutate(interval);
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="mb-6">
        <h1 className="text-3xl font-bold flex items-center gap-2" data-testid="text-settings-title">
          <Settings2 className="h-8 w-8" />
          Settings
        </h1>
        <p className="text-muted-foreground mt-1">
          Configure monitoring and notification preferences
        </p>
      </div>

      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <RefreshCw className="h-5 w-5" />
              Monitoring Interval
            </CardTitle>
            <CardDescription>
              Set how frequently the system checks for new protests and instability events
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {isLoading ? (
              <div className="text-sm text-muted-foreground">Loading settings...</div>
            ) : (
              <>
                <div className="bg-muted/50 p-4 rounded-lg">
                  <p className="text-sm font-medium">Current Setting</p>
                  <p className="text-2xl font-bold mt-1" data-testid="text-current-interval">
                    {settings?.intervalMinutes} minutes
                  </p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {settings?.message}
                  </p>
                </div>

                <div className="space-y-3">
                  <Label htmlFor="interval">New Monitoring Interval (minutes)</Label>
                  <div className="flex gap-2">
                    <Input
                      id="interval"
                      type="number"
                      min="1"
                      placeholder="Enter interval in minutes"
                      value={intervalValue}
                      onChange={(e) => setIntervalValue(e.target.value)}
                      data-testid="input-monitoring-interval"
                    />
                    <Button 
                      onClick={handleSave} 
                      disabled={updateSettingsMutation.isPending || !intervalValue}
                      data-testid="button-save-interval"
                    >
                      {updateSettingsMutation.isPending ? (
                        <>
                          <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                          Saving...
                        </>
                      ) : (
                        <>
                          <Save className="h-4 w-4 mr-2" />
                          Save
                        </>
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Common values: 5 (5 min), 15 (15 min), 30 (30 min), 60 (1 hour), 180 (3 hours)
                  </p>
                </div>

                <div className="bg-amber-500/10 border border-amber-500/30 p-3 rounded-lg">
                  <p className="text-sm text-amber-900 dark:text-amber-200">
                    <strong>Note:</strong> Shorter intervals provide faster updates but may increase API usage and costs. 
                    Recommended minimum: 5 minutes.
                  </p>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Bell className="h-5 w-5" />
              Push Notifications
            </CardTitle>
            <CardDescription>
              Receive instant alerts for critical security incidents on your device
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {!isNativePlatform ? (
              <div className="bg-muted/50 p-4 rounded-lg">
                <p className="text-sm text-muted-foreground">
                  Push notifications are only available in the native mobile app.
                  Install the Observius mobile app from the App Store or Google Play.
                </p>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between space-x-2">
                  <div className="space-y-1 flex-1">
                    <div className="flex items-center gap-2">
                      <Label htmlFor="notifications" className="text-sm font-medium">
                        Enable Push Notifications
                      </Label>
                      {isMonitoring && (
                        <span className="flex items-center gap-1 text-xs text-green-600 dark:text-green-400">
                          <BellRing className="h-3 w-3" />
                          Monitoring
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      Get notified immediately when critical alerts are detected
                    </p>
                  </div>
                  <Switch
                    id="notifications"
                    checked={notificationsEnabled}
                    onCheckedChange={async (checked) => {
                      if (checked) {
                        const granted = await notificationService.requestPermission();
                        if (granted) {
                          setNotificationsEnabled(true);
                          toast({
                            title: "Notifications Enabled",
                            description: "Monitoring for critical security incidents",
                          });
                        } else {
                          toast({
                            title: "Permission Denied",
                            description: "Please enable notifications in your device settings",
                            variant: "destructive",
                          });
                        }
                      } else {
                        setNotificationsEnabled(false);
                        toast({
                          title: "Notifications Disabled",
                          description: "You won't receive push notifications",
                        });
                      }
                    }}
                    data-testid="switch-notifications"
                  />
                </div>

                <div className="bg-blue-500/10 border border-blue-500/30 p-3 rounded-lg">
                  <p className="text-sm text-blue-900 dark:text-blue-200">
                    <strong>Note:</strong> You can test notifications by monitoring countries with recent activity.
                    Critical alerts will trigger instant push notifications to your device.
                  </p>
                </div>
              </>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Languages className="h-5 w-5" />
              Language & Translation
            </CardTitle>
            <CardDescription>
              Choose whether to view alerts in English or their original language
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between space-x-2">
              <div className="space-y-1 flex-1">
                <Label htmlFor="show-original" className="text-sm font-medium">
                  Show Original Language
                </Label>
                <p className="text-xs text-muted-foreground">
                  Display alerts in their original language (French, Arabic, Portuguese, etc.) instead of translated English
                </p>
              </div>
              <Switch
                id="show-original"
                checked={showOriginalLanguage}
                onCheckedChange={(checked) => {
                  setShowOriginalLanguage(checked);
                  toast({
                    title: checked ? "Original Language Enabled" : "Translation Enabled",
                    description: checked 
                      ? "Alerts will be shown in their original language when available"
                      : "All alerts will be translated to English",
                  });
                }}
                data-testid="switch-show-original-language"
              />
            </div>

            <div className="bg-blue-500/10 border border-blue-500/30 p-3 rounded-lg">
              <p className="text-sm text-blue-900 dark:text-blue-200">
                <strong>Note:</strong> When enabled, alerts from non-English sources will display in their original language. 
                English alerts remain unchanged. This helps users who speak multiple languages access news in its original form.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
