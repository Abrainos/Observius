import { useState, useEffect } from "react";
import { useRoute } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { CheckCircle, XCircle, Loader2, Mail } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function Unsubscribe() {
  const [, params] = useRoute("/unsubscribe/:token");
  const token = params?.token;
  
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [message, setMessage] = useState("");

  useEffect(() => {
    if (!token) {
      setStatus("error");
      setMessage("Invalid unsubscribe link. The link appears to be malformed.");
    }
  }, [token]);

  const handleUnsubscribe = async () => {
    if (!token) return;

    setStatus("loading");

    try {
      await apiRequest("POST", `/api/newsletter/unsubscribe/${token}`, {});
      setStatus("success");
      setMessage("You have been successfully unsubscribed from the Observius Daily Security Briefing.");
    } catch (error: any) {
      setStatus("error");
      setMessage(error?.message || "Failed to unsubscribe. The link may have expired or is invalid.");
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-6 bg-background">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="flex justify-center mb-4">
            <Mail className="h-12 w-12 text-muted-foreground" />
          </div>
          <CardTitle className="text-2xl">Newsletter Unsubscribe</CardTitle>
          <CardDescription>
            Manage your Observius Daily Security Briefing subscription
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {status === "idle" && token && (
            <>
              <p className="text-center text-muted-foreground">
                Click the button below to unsubscribe from the daily security briefing newsletter.
              </p>
              <Button 
                onClick={handleUnsubscribe}
                className="w-full"
                variant="destructive"
                data-testid="button-confirm-unsubscribe"
              >
                Confirm Unsubscribe
              </Button>
            </>
          )}

          {status === "loading" && (
            <div className="flex flex-col items-center justify-center space-y-4 py-8">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-muted-foreground">Processing your request...</p>
            </div>
          )}

          {status === "success" && (
            <Alert className="border-green-500/50 bg-green-500/10">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertDescription className="text-green-900 dark:text-green-100">
                {message}
              </AlertDescription>
            </Alert>
          )}

          {status === "error" && (
            <Alert variant="destructive">
              <XCircle className="h-4 w-4" />
              <AlertDescription>
                {message}
              </AlertDescription>
            </Alert>
          )}

          {(status === "success" || status === "error") && (
            <div className="text-center pt-4">
              <Button
                onClick={() => window.location.href = "/"}
                variant="outline"
                data-testid="button-return-home"
              >
                Return to Observius
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
