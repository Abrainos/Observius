# Design Guidelines: African Instability Monitoring System

## Design Approach: Security & Monitoring Platform
**Selected Approach**: Dashboard-focused system inspired by security monitoring platforms (Datadog, PagerDuty) with African cultural visual identity.

**Core Principles**:
- Clarity over decoration in alert presentation
- Immediate visual hierarchy for threat levels
- Professional, trustworthy aesthetic for sensitive content
- Efficient information scanning and decision-making

---

## Color Palette

**Primary Colors** (Dark Mode):
- Background: 220 15% 8% (deep slate)
- Surface: 220 15% 12% (elevated slate)
- Border: 220 12% 20% (subtle borders)

**Alert Severity System**:
- Critical/Violence: 0 70% 50% (urgent red)
- High/Protests: 25 85% 55% (warning amber)
- Moderate/Instability: 45 75% 60% (caution gold)
- Info/Monitoring: 200 65% 50% (calm blue)

**African Identity Accents**:
- Primary brand: 35 85% 45% (warm terracotta - African earth tones)
- Success/Safe: 145 65% 45% (muted green)

**Light Mode** (accessible alternative):
- Background: 220 15% 98%
- Surface: 0 0% 100%
- Text: 220 20% 15%

---

## Typography

**Font Families**:
- Primary: 'Inter' (Google Fonts) - clean, highly legible for data
- Monospace: 'JetBrains Mono' - for timestamps, coordinates, data values

**Hierarchy**:
- Alert Headlines: 600 weight, 1.25rem (clear, scannable)
- Body/Details: 400 weight, 0.875rem (efficient information density)
- Data Labels: 500 weight, 0.75rem uppercase tracking-wide (structured data)
- Timestamps: Monospace 400, 0.75rem (precision)

---

## Layout System

**Spacing Primitives**: Tailwind units of **2, 4, 6, 8, 12** (p-4, gap-6, mb-8, etc.)

**Grid Structure**:
- Dashboard: Sidebar (280px fixed) + Main content (fluid)
- Alert Cards: max-w-4xl centered with comfortable reading width
- Country Selector: Grid cols-2 md:cols-3 lg:cols-4 for efficient scanning
- Map View: Full-width with overlay panel system

**Responsive Breakpoints**:
- Mobile: Single column, collapsible sidebar
- Tablet: 2-column alert grid
- Desktop: 3-column where appropriate, persistent sidebar

---

## Component Library

**Navigation & Structure**:
- **Sidebar**: Fixed left, dark surface, country selector + quick filters
- **Top Bar**: Alert count badges, user profile, notification bell with red dot indicator
- **Breadcrumbs**: Location context (Country > Region > City)

**Data Display**:
- **Alert Cards**: Elevated surface, severity color accent (left border 4px), location pin icon, timestamp, expandable details
- **Country Chips**: Flag emoji + name, toggle selection, active state with terracotta accent
- **Timeline View**: Vertical line with nodes for chronological incidents
- **Map Markers**: Color-coded pins matching severity system

**Interactive Elements**:
- **Severity Badges**: Pill-shaped, matching alert colors, subtle glow on dark mode
- **Filter Dropdown**: Multi-select with checkboxes (Country, Severity, Date range)
- **Alert Details Modal**: Full incident report with location map, source links, AI analysis summary

**Notification System**:
- **In-App Toast**: Slide from top-right, auto-dismiss in 8s, severity color accent
- **Notification Panel**: Slide-out drawer, grouped by date, unread indicator dots

---

## Images

**Map Integration**:
- Interactive African continent map (use Mapbox/Leaflet with custom dark styling)
- Location: Dashboard center panel, 60% viewport height
- Markers cluster on zoom out, expand to show individual incidents on zoom in

**Country Flags**:
- Small emoji flags in country selector chips and alert cards for quick visual identification

**No Hero Image**: This is a utility dashboard, not a marketing page. Launch directly into functional interface.

---

## Key UX Patterns

**Dashboard Layout**:
1. Left Sidebar: Country multi-selector (sticky checkboxes), active count badge
2. Center: Live alert feed (reverse chronological) OR map view (toggle)
3. Right: Quick stats panel (24hr activity, countries with alerts)

**Alert Card Structure**:
- Header: Severity badge + Country flag + Timestamp
- Body: Incident summary (2-3 lines), AI-extracted location (bold)
- Footer: Source badges (BBC, AllAfrica, etc.) + "View Details" link
- Expansion: Full analysis, map preview, police intervention details, safety recommendations

**Empty States**:
- No countries selected: Illustration of African continent with "Select countries to monitor"
- No alerts: Green checkmark + "All quiet in monitored regions"

**Accessibility**:
- ARIA labels for severity levels and interactive map
- Keyboard navigation for country selection
- High contrast mode support
- Screen reader announcements for new critical alerts

---

**Visual Tone**: Professional security monitoring with African cultural warmth through terracotta accents and earth-tone highlights. Interface prioritizes rapid information comprehension over aesthetic flourish.