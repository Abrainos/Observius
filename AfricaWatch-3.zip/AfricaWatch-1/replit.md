# Observius - Decentralized Global Security Monitoring

## Overview
Observius is a decentralized, multi-region monitoring system tracking armed conflicts, protests, civil unrest, drug trafficking, and security incidents across 185 countries in Africa, Asia, Europe, the Middle East, South America, North America, and Central/South Asia. It uses AI-powered analysis to scrape news, categorize events by severity (including drug-related violence), and deliver alerts via in-app and local notifications. Designed as a security monitoring dashboard, it provides clarity, immediate threat assessment, and historical context for rapid decision-making. The application requires no authentication; user data is stored locally and synced with the server.

## User Preferences
Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend
The frontend uses React 18, TypeScript, Vite, Tailwind CSS with a custom design system, and Shadcn/ui for consistent components. Wouter handles client-side routing. It functions as a PWA with offline support and can be deployed as native Android/iOS apps via Capacitor. Key features include an interactive Dashboard with heat maps, an Alert History page, and Settings. State management utilizes client-side IndexedDB for alerts, with automatic background synchronization every 5 minutes. The UI features dark mode, severity-based color coding, and terracotta accents.

### Backend
The backend is built with Express.js and TypeScript, using PostgreSQL and Drizzle ORM. It provides RESTful API endpoints for alerts and monitored countries without authentication. Security middleware includes rate limiting, bot/scraper detection, CORS restrictions, origin validation, and security headers. A `node-cron` scheduled monitoring service aggregates content, processes it via a pipeline (Scrape → Analyze → Alert → Notify) using Cheerio for HTML parsing, and validates data with Zod schemas.

### Data Storage & Synchronization
The system employs a decentralized architecture:
- **Server-Side:** PostgreSQL stores the authoritative global alerts and monitored countries.
- **Client-Side:** Each user's browser maintains an independent copy of alerts in IndexedDB for instant access and offline support.
- **Synchronization:** A service syncs local data with the server every 5 minutes, fetching new alerts, updating existing ones, and deleting stale entries. This design enables open access, local data persistence, and offline functionality without authentication. UUIDs are used for entity identification.

### UI/UX
The UI prioritizes clear security monitoring with a dark theme, color-coded alerts (Critical, High, Moderate, Info), and warm terracotta accents. Typography uses Inter and JetBrains Mono. The Dashboard features a prominent "Observius" title, motto, and SEO-optimized description. A sidebar allows region selection (Africa, Asia, Europe, Middle East, South America, North America, Central/South Asia) with interactive heat maps visualizing incident intensity and country-level details using TopoJSON data. Location heat map popups visualize city-level events with pulsating animations.

### Key Features
- **Multi-Region Monitoring:** Seamless switching between seven major regions (Africa: 54 countries, Asia: 17, Europe: 50, Middle East: 15, South America: 13, North America: 23, Central/South Asia: 13), with persisted preferences and region-filtered alerts/heat maps. Heat maps use responsive heights: 500px on mobile, 700px on tablet, 800px on desktop for optimal viewing across all devices.
- **Alert Management:** Export alerts to CSV, clear history, and advanced keyword search.
- **Historical Context:** Alerts include up to 200 words of historical background and root causes. Users can click "Tell me more" on any alert to get on-demand AI-generated analysis including historical background, current political landscape, and root causes. Analysis is cached in the database to avoid duplicate AI calls.
- **Push Notifications:** Foreground local notifications for critical alerts with user-configurable settings.
- **Location Heat Map:** Geocoding via Nominatim API for interactive, concentric heat maps at city levels, supporting 185 countries.
- **Drug Trafficking Monitoring:** Comprehensive keyword tracking for drug-related incidents across all severity levels, including cartel activity, specific drug seizures, and narco-terrorism.
- **AI Safety Filter:** Region-aware, keyword-based filtering to prevent cross-region contamination of alerts.
- **Multilingual Monitoring:** Automatic translation from numerous languages to English using Google Translate API, with language detection.
- **Translation Preference:** Users can toggle between original and translated English versions of alerts, with the preference stored locally.
- **Open Access:** No authentication required; local IndexedDB storage syncs automatically with the server.
- **Daily Newsletter System:** Users can subscribe to receive comprehensive 2,000-word daily security briefings via email. Each briefing includes an Executive Summary, TRAVEL HOT SPOTS section (specific locations to avoid), Regional Analysis with forward-looking predictions for every incident, and Global Outlook. New subscribers receive a welcome email with the latest briefing and information about the daily delivery schedule (6 AM daily). One-click unsubscribe available. Admin panel at `/admin/newsletter` shows subscriber statistics.

## External Dependencies

### AI & Analysis
- **OpenAI API (via Replit AI Integrations):** AI-powered news content analysis, threat assessment, categorization, and newsletter generation (GPT-4o).
- **Nominatim API (OpenStreetMap):** Geocoding alert locations.
- **`franc` library:** Language detection.

### Content Sources
- **GDELT (Global Database of Events, Language, and Tone):** Real-time global event monitoring for conflict events, integrated via Python `gdelt` library, updated every 30 minutes.
- **RSS Feed System:** 230+ configured RSS feeds across all seven regions, covering diverse languages and pan-regional sources. Features intelligent retry logic with exponential backoff, per-host concurrency limiting (max 2 per hostname), error classification (rate_limit/not_found/forbidden/timeout/connection/server_error), and structured logging. Production performance: ~89/219 feeds successful, ~443 articles per cycle, ~8.4 minutes per cycle.
- **Google Translate API:** Automatic translation of news articles to English with critical auto-fallback retry mechanism. When Google Translate rejects unsupported language codes (e.g., 'sco'), the system automatically retries with `{from: 'auto'}` to ensure translation success. Features HTML normalization (15+ entity types), layered language detection (feed-provided → character-set heuristics for Arabic/Cyrillic/Chinese → Franc detection → fallback), and structured error logging.
- **Social Media Platforms (Optional):** Twitter/X API, NewsAPI, Reddit (requires API keys).

### Email Notifications & Newsletter
- **Nodemailer:** Email delivery with configurable SMTP settings for daily newsletter distribution.
- **node-cron:** Automated daily newsletter scheduling (default: 6 AM daily, configurable via `NEWSLETTER_CRON_SCHEDULE`).
- **Newsletter Generation:** AI-powered 2,000-word briefings using GPT-4o, including welcome emails for new subscribers with the latest briefing and delivery schedule information.

### UI Component Libraries
- **Radix UI:** Accessible UI primitives.
- **Lucide React:** Iconography.
- **`class-variance-authority`:** Component variant management.
- **React Hook Form with Zod resolvers:** Form validation.

### Development Tools
- **`tsx`:** TypeScript execution in development.
- **`esbuild`:** Production server bundling.
- **Drizzle Kit:** Database migrations.
- **Capacitor CLI:** Native app development and deployment.