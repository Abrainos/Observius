import { db } from "../server/db.js";
import { type Alert, alerts } from "../shared/schema.js";
import { desc, gte, sql as drizzleSql } from "drizzle-orm";
import OpenAI from "openai";

// This is using Replit's AI Integrations service
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

async function generateNewsletterExample() {
  try {
    console.log("Fetching recent alerts from the last 24 hours...\n");

    // Get alerts from last 24 hours
    const twentyFourHoursAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const recentAlerts = await db
      .select()
      .from(alerts)
      .where(gte(alerts.timestamp, twentyFourHoursAgo))
      .orderBy(desc(alerts.timestamp))
      .limit(100);

    console.log(`Found ${recentAlerts.length} alerts from the last 24 hours.\n`);

    // Group alerts by region
    const alertsByRegion = recentAlerts.reduce((acc, alert) => {
      if (!acc[alert.region]) {
        acc[alert.region] = [];
      }
      acc[alert.region].push(alert);
      return acc;
    }, {} as Record<string, Alert[]>);

    // Create summary data for the AI
    const summaryData = Object.entries(alertsByRegion).map(([region, regionAlerts]) => {
      const criticalCount = regionAlerts.filter(a => a.severity === 'critical').length;
      const highCount = regionAlerts.filter(a => a.severity === 'high').length;
      const moderateCount = regionAlerts.filter(a => a.severity === 'moderate').length;
      
      return {
        region: region.toUpperCase(),
        totalAlerts: regionAlerts.length,
        critical: criticalCount,
        high: highCount,
        moderate: moderateCount,
        topIncidents: regionAlerts.slice(0, 10).map(a => ({
          country: a.country,
          title: a.title,
          severity: a.severity,
          description: a.description.substring(0, 200)
        }))
      };
    });

    console.log("Generating professional newsletter with AI...\n");

    const prompt = `You are writing the Observius Daily Security Briefing - a professional newsletter that summarizes global security events from the last 24 hours.

NEWSLETTER REQUIREMENTS:
- MAXIMUM: 2,000 words (aim for 1,800-2,000 words for comprehensive coverage)
- Professional, journalistic tone suitable for security professionals and executives
- Structure: Opening summary → TRAVEL HOT SPOTS → Regional analysis → Closing insights
- Cover the most significant incidents across all 7 regions: Africa, Asia, Europe, Middle East, South America, North America, and Central/South Asia
- Use clear, professional language with specific details
- Include specific details (countries, cities, casualty numbers when available)
- Prioritize critical and high-severity incidents, but include moderate-level events when space allows
- Group similar incidents together for efficiency
- For EVERY alert or issue, provide forward-looking analysis about what could happen next (2-3 sentences per major incident)
- End with a comprehensive forward-looking statement

FORMAT:
Start with "OBSERVIUS DAILY SECURITY BRIEFING" as the title, followed by the date.

Include a brief executive summary (2-3 sentences) highlighting the most critical developments.

IMMEDIATELY AFTER the executive summary, include a "TRAVEL HOT SPOTS" section that lists specific locations (cities, regions, border crossings) travelers should avoid based on the alerts. Be as specific as possible with location names and explain WHY each location is dangerous right now.

Then organize by region with clear headers. For each region, synthesize related incidents into coherent paragraphs rather than listing them individually. CRITICALLY IMPORTANT: For each incident or issue discussed, include forward-looking analysis about what could happen in the future (e.g., "This incident may escalate to...", "Expect further developments in...", "The situation could deteriorate if...", "This trend suggests...", etc.)

End with a "Global Outlook" section (3-4 sentences) offering perspective on broader trends and future implications.

DATA TO ANALYZE (ALL alerts from the last 24 hours across ALL regions):
${JSON.stringify(summaryData, null, 2)}

Generate a professional, well-structured newsletter that security professionals would value. Target 1,800-2,000 words for comprehensive coverage. Include predictive analysis for every incident.`;

    const response = await openai.chat.completions.create({
      model: "gpt-5", // the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
      messages: [
        {
          role: "system",
          content: "You are a professional security analyst writing a daily briefing for executives and security professionals. Write in a clear, authoritative, journalistic style."
        },
        {
          role: "user",
          content: prompt
        }
      ],
      max_completion_tokens: 8192
    });

    const newsletter = response.choices[0]?.message?.content || "";

    if (!newsletter) {
      console.log("DEBUG: Response object:", JSON.stringify(response, null, 2));
      throw new Error("Newsletter generation failed - no content received");
    }

    console.log("=" .repeat(80));
    console.log("NEWSLETTER EXAMPLE");
    console.log("=" .repeat(80));
    console.log(newsletter);
    console.log("=" .repeat(80));
    console.log(`\nWord count: approximately ${newsletter.split(/\s+/).length} words`);
    console.log("\nThis is an example of what subscribers would receive daily.\n");

  } catch (error) {
    console.error("Error generating newsletter:", error);
    throw error;
  }
}

generateNewsletterExample();
