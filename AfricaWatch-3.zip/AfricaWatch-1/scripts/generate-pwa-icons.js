// Simple script to generate PWA icons
// This creates placeholder icons with the app colors

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import sharp from 'sharp';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Create SVG icons
const createSVGIcon = (size) => {
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
  <!-- Background -->
  <rect width="${size}" height="${size}" fill="#0A0A0A"/>
  
  <!-- Bell icon (alert symbol) -->
  <g transform="translate(${size * 0.25}, ${size * 0.2})">
    <path d="M ${size * 0.25} ${size * 0.05} 
             C ${size * 0.25} ${size * 0.02} ${size * 0.27} 0 ${size * 0.25} 0
             C ${size * 0.23} 0 ${size * 0.25} ${size * 0.02} ${size * 0.25} ${size * 0.05}
             L ${size * 0.25} ${size * 0.1}
             C ${size * 0.15} ${size * 0.1} ${size * 0.08} ${size * 0.18} ${size * 0.08} ${size * 0.28}
             L ${size * 0.08} ${size * 0.38}
             C ${size * 0.08} ${size * 0.42} ${size * 0.05} ${size * 0.45} ${size * 0.02} ${size * 0.48}
             L 0 ${size * 0.5}
             L ${size * 0.5} ${size * 0.5}
             L ${size * 0.48} ${size * 0.48}
             C ${size * 0.45} ${size * 0.45} ${size * 0.42} ${size * 0.42} ${size * 0.42} ${size * 0.38}
             L ${size * 0.42} ${size * 0.28}
             C ${size * 0.42} ${size * 0.18} ${size * 0.35} ${size * 0.1} ${size * 0.25} ${size * 0.1}
             Z" 
          fill="#C2410C" stroke="#EA580C" stroke-width="${size * 0.01}"/>
    
    <!-- Bell clapper -->
    <circle cx="${size * 0.25}" cy="${size * 0.54}" r="${size * 0.03}" fill="#EA580C"/>
  </g>
  
  <!-- Africa text -->
  <text x="${size * 0.5}" y="${size * 0.85}" 
        font-family="Arial, sans-serif" 
        font-size="${size * 0.12}" 
        font-weight="bold" 
        text-anchor="middle" 
        fill="#C2410C">AfricaWatch</text>
</svg>`;
};

// Save icons
const outputDir = path.join(__dirname, '..', 'client', 'public');

// Function to convert SVG to PNG using Sharp
async function convertSvgToPng(svgContent, outputPath, size) {
  const buffer = Buffer.from(svgContent);
  await sharp(buffer)
    .resize(size, size)
    .png()
    .toFile(outputPath);
}

// Generate icons
(async () => {
  try {
    // Generate 192x192 icon
    const svg192 = createSVGIcon(192);
    fs.writeFileSync(path.join(outputDir, 'pwa-192x192.svg'), svg192);
    await convertSvgToPng(svg192, path.join(outputDir, 'pwa-192x192.png'), 192);
    
    // Generate 512x512 icon
    const svg512 = createSVGIcon(512);
    fs.writeFileSync(path.join(outputDir, 'pwa-512x512.svg'), svg512);
    await convertSvgToPng(svg512, path.join(outputDir, 'pwa-512x512.png'), 512);
    
    console.log('PWA icons generated successfully!');
    console.log('✅ Created: pwa-192x192.svg, pwa-192x192.png');
    console.log('✅ Created: pwa-512x512.svg, pwa-512x512.png');
  } catch (error) {
    console.error('Error generating icons:', error);
    process.exit(1);
  }
})();
