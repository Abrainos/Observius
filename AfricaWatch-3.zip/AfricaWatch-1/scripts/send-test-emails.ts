import { generateDailyNewsletter } from "../server/services/newsletter-generator";
import { emailService } from "../server/services/email-service";

async function sendTestEmails() {
  const testEmail = "abrain@gmail.com";
  
  emailService.initialize();
  
  if (!emailService.isConfigured()) {
    console.log("Email service not configured!");
    return;
  }
  
  console.log("Generating newsletter...");
  const newsletter = await generateDailyNewsletter();
  console.log("Newsletter generated:", newsletter.subject);
  console.log("Content preview:", newsletter.textContent.substring(0, 500));
  
  console.log("\nSending test newsletter to", testEmail);
  const regularResult = await emailService.sendNewsletterToSubscriber(
    { email: testEmail },
    newsletter.subject,
    newsletter.htmlContent,
    newsletter.textContent
  );
  console.log("Regular newsletter sent:", regularResult);
  
  const welcomeHtml = newsletter.htmlContent.replace(
    '<div style="font-size: 15px; line-height: 1.7;">',
    `<div style="font-size: 15px; line-height: 1.7;">
      <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 30px; border-left: 4px solid #d4653e;">
        <h2 style="color: #d4653e; margin-top: 0; margin-bottom: 12px;">Welcome to Observius!</h2>
        <p style="margin: 8px 0; color: #333;">Thank you for subscribing.</p>
        <p style="margin: 8px 0;"><strong>What to expect:</strong></p>
        <ul style="margin: 8px 0 12px 20px;">
          <li>Executive Summary of global security events</li>
          <li>Travel Advisory with danger ratings</li>
          <li>Coup Watch for government instability</li>
        </ul>
        <p><strong>Next briefing:</strong> 3:00 AM EST daily</p>
      </div>`
  );
  
  console.log("\nSending welcome newsletter to", testEmail);
  const welcomeResult = await emailService.sendNewsletterToSubscriber(
    { email: testEmail },
    "Welcome to Observius - Your Daily Security Briefing",
    welcomeHtml,
    "WELCOME TO OBSERVIUS\n\n" + newsletter.textContent
  );
  console.log("Welcome newsletter sent:", welcomeResult);
  
  console.log("\nDone! Check inbox for both emails.");
  process.exit(0);
}

sendTestEmails().catch(err => {
  console.error("Error:", err);
  process.exit(1);
});
