import { Request, Response, NextFunction } from 'express';
import rateLimit from 'express-rate-limit';

/**
 * List of known bot/scraper user agents to block
 * Note: We don't block 'axios' or 'fetch' as these are legitimate frontend libraries
 */
const BLOCKED_USER_AGENTS = [
  'curl',
  'wget',
  'python-requests',
  'python-urllib',
  'scrapy',
  'httpie',
  'postman',
  'insomnia',
  'java/',
  'apache-httpclient',
  'okhttp',
  'pycurl',
  'mechanize',
  'beautifulsoup',
  'selenium',
  'phantomjs',
  'headlesschrome',
  'puppeteer',
  'playwright',
];

/**
 * Rate limiting middleware - limits requests per IP
 * Allows 100 requests per 15 minutes per IP
 */
export const apiRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: {
    error: 'Too many requests from this IP, please try again later.',
  },
  standardHeaders: true, // Return rate limit info in the `RateLimit-*` headers
  legacyHeaders: false, // Disable the `X-RateLimit-*` headers
  handler: (req, res) => {
    console.log(`[SECURITY] Rate limit exceeded for IP: ${req.ip}`);
    res.status(429).json({
      error: 'Too many requests. Please slow down and try again later.',
    });
  },
});

/**
 * Stricter rate limiting for write operations (POST, PUT, DELETE)
 * Allows 20 requests per 15 minutes per IP
 */
export const writeRateLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // Limit each IP to 20 write requests per windowMs
  message: {
    error: 'Too many write requests from this IP, please try again later.',
  },
  skip: (req) => {
    return req.method === 'GET' || req.method === 'HEAD';
  },
  handler: (req, res) => {
    console.log(`[SECURITY] Write rate limit exceeded for IP: ${req.ip} on ${req.method} ${req.path}`);
    res.status(429).json({
      error: 'Too many write operations. Please slow down.',
    });
  },
});

/**
 * Bot/Scraper detection middleware
 * Blocks known automated tools and scrapers
 */
export function botDetectionMiddleware(req: Request, res: Response, next: NextFunction) {
  const userAgent = (req.get('user-agent') || '').toLowerCase();
  
  // Allow requests without user-agent from same origin (for fetch API calls)
  if (!userAgent && isSameOrigin(req)) {
    return next();
  }
  
  // Require user-agent header for external requests
  if (!userAgent) {
    console.log(`[SECURITY] Blocked request without user-agent from IP: ${req.ip}`);
    return res.status(403).json({
      error: 'Access denied. Please use a web browser to access this service.',
    });
  }
  
  // Check for known bot/scraper patterns
  for (const blockedAgent of BLOCKED_USER_AGENTS) {
    if (userAgent.includes(blockedAgent)) {
      console.log(`[SECURITY] Blocked bot/scraper: ${blockedAgent} from IP: ${req.ip}`);
      return res.status(403).json({
        error: 'Automated access detected. Please use a web browser to access this service.',
      });
    }
  }
  
  next();
}

/**
 * Origin validation middleware
 * Ensures requests come from the legitimate frontend
 */
export function originValidationMiddleware(req: Request, res: Response, next: NextFunction) {
  // Allow GET requests (for initial page loads and public data)
  if (req.method === 'GET' || req.method === 'HEAD') {
    return next();
  }
  
  // For state-changing operations, validate origin
  const origin = req.get('origin');
  const referer = req.get('referer');
  const host = req.get('host');
  
  // Check if request comes from same origin
  const isSameOriginRequest = 
    (origin && origin.includes(host || '')) ||
    (referer && referer.includes(host || '')) ||
    (!origin && !referer); // Allow requests without origin/referer from server-side
  
  if (!isSameOriginRequest) {
    console.log(`[SECURITY] Blocked cross-origin request from origin: ${origin}, referer: ${referer}, IP: ${req.ip}`);
    return res.status(403).json({
      error: 'Cross-origin requests not allowed for this operation.',
    });
  }
  
  next();
}

/**
 * Check if request is from same origin
 */
function isSameOrigin(req: Request): boolean {
  const origin = req.get('origin');
  const referer = req.get('referer');
  const host = req.get('host');
  
  if (origin && host && origin.includes(host)) {
    return true;
  }
  
  if (referer && host && referer.includes(host)) {
    return true;
  }
  
  return false;
}

/**
 * API key validation middleware (optional - for future use)
 * Can be enabled if you want to add API keys later
 */
export function apiKeyMiddleware(req: Request, res: Response, next: NextFunction) {
  const apiKey = req.get('x-api-key');
  
  // For now, just log if API key is present
  if (apiKey) {
    console.log(`[SECURITY] Request with API key from IP: ${req.ip}`);
  }
  
  next();
}

/**
 * Security headers middleware
 * Adds security-related HTTP headers
 */
export function securityHeadersMiddleware(req: Request, res: Response, next: NextFunction) {
  // Prevent clickjacking
  res.setHeader('X-Frame-Options', 'SAMEORIGIN');
  
  // Prevent MIME type sniffing
  res.setHeader('X-Content-Type-Options', 'nosniff');
  
  // Enable XSS protection
  res.setHeader('X-XSS-Protection', '1; mode=block');
  
  // Referrer policy
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  
  // Content Security Policy (basic)
  res.setHeader(
    'Content-Security-Policy',
    "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; img-src 'self' data: https:; font-src 'self' data: https://fonts.gstatic.com; connect-src 'self' https: https://cdn.jsdelivr.net;"
  );
  
  next();
}
