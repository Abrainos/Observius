import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertAlertSchema, insertMonitoredCountrySchema, insertNewsletterSubscriberSchema } from "@shared/schema";
import { startMonitoringScheduler, runMonitoringCycle, getMonitoringInterval, restartMonitoringScheduler } from "./services/monitor";
import { startNewsletterScheduler, triggerManualNewsletterSend, sendWelcomeNewsletter } from "./services/newsletter-scheduler";
import { generateAlertAnalysis } from "./services/openai";
import { writeFileSync, readFileSync } from "fs";
import { join } from "path";

// Admin authentication middleware
function requireAdmin(req: any, res: any, next: any) {
  if (req.session && req.session.isAdmin) {
    return next();
  }
  res.status(401).json({ error: "Unauthorized - Admin access required" });
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Start the monitoring scheduler
  startMonitoringScheduler();
  
  // Start the newsletter scheduler
  startNewsletterScheduler();

  // Admin authentication routes
  app.post("/api/admin/login", (req: any, res) => {
    const { username, password } = req.body;
    
    const adminUsername = process.env.ADMIN_USERNAME;
    const adminPassword = process.env.ADMIN_PASSWORD;
    
    if (!adminUsername || !adminPassword) {
      return res.status(500).json({ error: "Admin credentials not configured" });
    }
    
    if (username === adminUsername && password === adminPassword) {
      req.session.isAdmin = true;
      return res.json({ message: "Login successful" });
    }
    
    res.status(401).json({ error: "Invalid username or password" });
  });

  app.post("/api/admin/logout", (req: any, res) => {
    req.session.destroy((err: any) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.json({ message: "Logout successful" });
    });
  });

  app.get("/api/admin/status", (req: any, res) => {
    res.json({ isAuthenticated: req.session?.isAdmin || false });
  });

  // Alert routes (now global - no authentication required)
  app.get("/api/alerts", async (req: any, res) => {
    try {
      const region = req.query.region as string | undefined;
      const since = req.query.since as string | undefined;
      const limit = Math.min(parseInt(req.query.limit as string) || 2000, 5000); // Max 5000 alerts
      
      let alerts = await storage.getAllAlerts(region, limit);
      
      // PERFORMANCE OPTIMIZATION: Incremental sync - only return alerts since timestamp
      if (since) {
        const sinceDate = new Date(since);
        alerts = alerts.filter(alert => new Date(alert.timestamp) > sinceDate);
      }
      
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching alerts:", error);
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  // Export route must come BEFORE :id route to avoid "export" being treated as an ID
  app.get("/api/alerts/export", async (req: any, res) => {
    try {
      const alerts = await storage.getAllAlerts();
      
      // Create CSV content
      const headers = ["Timestamp", "Country", "Severity", "Title", "Description", "Location", "Source", "URL"];
      const csvRows = [headers.join(",")];
      
      for (const alert of alerts) {
        const row = [
          new Date(alert.timestamp).toISOString(),
          `"${alert.country}"`,
          alert.severity,
          `"${(alert.title || '').replace(/"/g, '""')}"`,
          `"${(alert.description || '').replace(/"/g, '""')}"`,
          `"${(alert.location || '').replace(/"/g, '""')}"`,
          `"${(alert.source || '').replace(/"/g, '""')}"`,
          `"${(alert.sourceUrl || '').replace(/"/g, '""')}"`
        ];
        csvRows.push(row.join(","));
      }
      
      const csvContent = csvRows.join("\n");
      
      // Set headers for file download
      res.setHeader("Content-Type", "text/csv");
      res.setHeader("Content-Disposition", `attachment; filename="earthenwatch-alerts-${new Date().toISOString().split('T')[0]}.csv"`);
      res.send(csvContent);
    } catch (error) {
      console.error("Error exporting alerts:", error);
      res.status(500).json({ error: "Failed to export alerts" });
    }
  });

  app.get("/api/alerts/:id", async (req: any, res) => {
    try {
      const alert = await storage.getAlertById(req.params.id);
      if (!alert) {
        return res.status(404).json({ error: "Alert not found" });
      }
      res.json(alert);
    } catch (error) {
      console.error("Error fetching alert:", error);
      res.status(500).json({ error: "Failed to fetch alert" });
    }
  });

  app.post("/api/alerts/:id/analyze", async (req: any, res) => {
    try {
      const alert = await storage.getAlertById(req.params.id);
      if (!alert) {
        return res.status(404).json({ error: "Alert not found" });
      }

      // Return cached analysis if available
      if (alert.aiAnalysis) {
        return res.json({ analysis: alert.aiAnalysis });
      }

      // Sanitize inputs - use fallback values for missing fields
      const title = alert.title || "Security incident";
      const description = alert.description || "No description available";
      const country = alert.country || "Unknown";
      const location = alert.location || country;
      const severity = alert.severity || "info";

      const result = await generateAlertAnalysis(
        title,
        description,
        country,
        location,
        severity
      );

      if (!result || !result.analysis) {
        return res.status(502).json({ error: "AI service unavailable. Please try again later." });
      }

      // Cache the analysis in the database
      await storage.updateAlertAnalysis(req.params.id, result.analysis);

      res.json({ analysis: result.analysis });
    } catch (error) {
      console.error("Error generating alert analysis:", error);
      res.status(502).json({ error: "AI service error. Please try again later." });
    }
  });

  app.post("/api/alerts", async (req: any, res) => {
    try {
      const validatedData = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert(validatedData);
      res.status(201).json(alert);
    } catch (error) {
      console.error("Error creating alert:", error);
      res.status(400).json({ error: "Invalid alert data" });
    }
  });

  app.delete("/api/alerts/:id", async (req: any, res) => {
    try {
      await storage.deleteAlert(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting alert:", error);
      res.status(500).json({ error: "Failed to delete alert" });
    }
  });

  // Delete all alerts must come BEFORE :id route
  app.delete("/api/alerts", async (req: any, res) => {
    try {
      await storage.deleteAllAlerts();
      res.json({ message: "All alerts cleared successfully" });
    } catch (error) {
      console.error("Error clearing alerts:", error);
      res.status(500).json({ error: "Failed to clear alerts" });
    }
  });

  // Monitored countries routes (now global)
  app.get("/api/monitored-countries", async (req: any, res) => {
    try {
      const region = req.query.region as string | undefined;
      const countries = await storage.getMonitoredCountries(region);
      res.json(countries);
    } catch (error) {
      console.error("Error fetching monitored countries:", error);
      res.status(500).json({ error: "Failed to fetch monitored countries" });
    }
  });

  app.post("/api/monitored-countries", async (req: any, res) => {
    try {
      const validatedData = insertMonitoredCountrySchema.parse(req.body);
      const country = await storage.createMonitoredCountry(validatedData);
      res.status(201).json(country);
    } catch (error) {
      console.error("Error creating monitored country:", error);
      res.status(400).json({ error: "Invalid country data" });
    }
  });

  app.delete("/api/monitored-countries/:id", async (req: any, res) => {
    try {
      await storage.deleteMonitoredCountry(req.params.id);
      res.status(204).send();
    } catch (error) {
      console.error("Error deleting monitored country:", error);
      res.status(500).json({ error: "Failed to delete monitored country" });
    }
  });

  app.patch("/api/monitored-countries/:id", async (req: any, res) => {
    try {
      const { enabled } = req.body;
      const country = await storage.toggleMonitoredCountry(req.params.id, enabled);
      res.json(country);
    } catch (error) {
      console.error("Error updating monitored country:", error);
      res.status(500).json({ error: "Failed to update monitored country" });
    }
  });

  // Manual trigger for monitoring (for testing)
  app.post("/api/monitor/trigger", async (req, res) => {
    try {
      // Run monitoring cycle asynchronously
      runMonitoringCycle().catch(console.error);
      res.json({ message: "Monitoring cycle triggered" });
    } catch (error) {
      console.error("Error triggering monitor:", error);
      res.status(500).json({ error: "Failed to trigger monitoring" });
    }
  });

  // Monitoring settings routes
  app.get("/api/settings/monitoring", (req, res) => {
    try {
      const intervalMinutes = getMonitoringInterval();
      res.json({ 
        intervalMinutes,
        message: `Monitoring runs every ${intervalMinutes} minutes` 
      });
    } catch (error) {
      console.error("Error fetching monitoring settings:", error);
      res.status(500).json({ error: "Failed to fetch monitoring settings" });
    }
  });

  app.post("/api/settings/monitoring", (req, res) => {
    try {
      const { intervalMinutes } = req.body;
      
      if (!intervalMinutes || isNaN(intervalMinutes) || intervalMinutes < 1) {
        return res.status(400).json({ error: "Invalid interval. Must be a positive number." });
      }

      // Update environment variable for current session
      process.env.MONITORING_INTERVAL_MINUTES = String(intervalMinutes);
      
      // Restart the scheduler with new interval
      restartMonitoringScheduler();
      
      res.json({ 
        intervalMinutes,
        message: `Monitoring interval updated to ${intervalMinutes} minutes. Scheduler restarted.` 
      });
    } catch (error) {
      console.error("Error updating monitoring settings:", error);
      res.status(500).json({ error: "Failed to update monitoring settings" });
    }
  });

  // Newsletter routes
  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const parsed = insertNewsletterSubscriberSchema.safeParse(req.body);
      
      if (!parsed.success) {
        return res.status(400).json({ error: "Invalid email address" });
      }

      // Check if email already exists
      const existing = await storage.getNewsletterSubscriberByEmail(parsed.data.email);
      if (existing) {
        if (existing.isActive) {
          return res.status(400).json({ error: "Email already subscribed to newsletter" });
        } else {
          // Reactivate existing subscription
          await storage.createNewsletterSubscriber({ email: parsed.data.email, isActive: true });
          return res.json({ message: "Successfully resubscribed to newsletter!" });
        }
      }

      const subscriber = await storage.createNewsletterSubscriber(parsed.data);
      
      // Send welcome email with latest newsletter (non-blocking)
      sendWelcomeNewsletter(subscriber).catch(err => {
        console.error("Error sending welcome newsletter:", err);
      });
      
      res.json({ message: "Successfully subscribed to daily security briefing!", subscriber: { email: subscriber.email } });
    } catch (error) {
      console.error("Error subscribing to newsletter:", error);
      res.status(500).json({ error: "Failed to subscribe to newsletter" });
    }
  });

  app.post("/api/newsletter/unsubscribe/:token", async (req, res) => {
    try {
      const { token } = req.params;
      
      const subscriber = await storage.getNewsletterSubscriberByToken(token);
      if (!subscriber) {
        return res.status(404).json({ error: "Invalid unsubscribe link" });
      }

      await storage.unsubscribeNewsletter(token);
      res.json({ message: "Successfully unsubscribed from newsletter" });
    } catch (error) {
      console.error("Error unsubscribing from newsletter:", error);
      res.status(500).json({ error: "Failed to unsubscribe from newsletter" });
    }
  });

  app.get("/api/newsletter/subscribers", requireAdmin, async (req, res) => {
    try {
      const subscribers = await storage.getAllNewsletterSubscribers();
      res.json(subscribers);
    } catch (error) {
      console.error("Error fetching newsletter subscribers:", error);
      res.status(500).json({ error: "Failed to fetch newsletter subscribers" });
    }
  });

  app.delete("/api/newsletter/subscribers/:id", requireAdmin, async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deleteNewsletterSubscriber(id);
      res.json({ message: "Subscriber deleted successfully" });
    } catch (error) {
      console.error("Error deleting newsletter subscriber:", error);
      res.status(500).json({ error: "Failed to delete subscriber" });
    }
  });

  // Admin-only endpoint for testing newsletter send (requires authentication)
  app.post("/api/admin/newsletter/send-test", requireAdmin, async (req, res) => {
    try {
      console.log("=== ADMIN NEWSLETTER TEST SEND RECEIVED ===");
      console.log("Request IP:", req.ip);
      console.log("Request user-agent:", req.headers['user-agent']);
      
      const result = await triggerManualNewsletterSend();
      
      console.log("=== NEWSLETTER SEND COMPLETE ===");
      console.log("Sent:", result.sent, "Failed:", result.failed);
      
      res.json({
        message: "Newsletter send complete",
        sent: result.sent,
        failed: result.failed,
      });
    } catch (error: any) {
      console.error("=== NEWSLETTER SEND ERROR ===");
      console.error("Error details:", error);
      console.error("Error stack:", error.stack);
      res.status(500).json({ error: error.message || "Failed to send newsletter" });
    }
  });

  // Get newsletter enabled status
  app.get("/api/admin/newsletter/status", requireAdmin, async (req, res) => {
    try {
      const enabled = await storage.isNewsletterEnabled();
      res.json({ enabled });
    } catch (error: any) {
      console.error("Error fetching newsletter status:", error);
      res.status(500).json({ error: "Failed to fetch newsletter status" });
    }
  });

  // Toggle newsletter feature
  app.post("/api/admin/newsletter/toggle", requireAdmin, async (req, res) => {
    try {
      const { enabled } = req.body;
      await storage.setNewsletterEnabled(enabled);
      
      if (enabled) {
        console.log("Newsletter feature enabled - restarting scheduler");
        const { restartNewsletterScheduler } = await import("./services/newsletter-scheduler");
        await restartNewsletterScheduler();
      } else {
        console.log("Newsletter feature disabled - stopping scheduler");
        const { stopNewsletterScheduler } = await import("./services/newsletter-scheduler");
        stopNewsletterScheduler();
      }
      
      res.json({ 
        message: `Newsletter ${enabled ? 'enabled' : 'disabled'} successfully`,
        enabled 
      });
    } catch (error: any) {
      console.error("Error toggling newsletter:", error);
      res.status(500).json({ error: "Failed to toggle newsletter" });
    }
  });

  app.post("/api/newsletter/send", async (req, res) => {
    try {
      console.log("=== NEWSLETTER SEND REQUEST RECEIVED ===");
      console.log("Manual newsletter send triggered via API");
      console.log("Request headers:", req.headers);
      console.log("Request IP:", req.ip);
      
      const result = await triggerManualNewsletterSend();
      
      console.log("=== NEWSLETTER SEND COMPLETE ===");
      console.log("Sent:", result.sent, "Failed:", result.failed);
      
      res.json({
        message: "Newsletter send complete",
        sent: result.sent,
        failed: result.failed,
      });
    } catch (error: any) {
      console.error("=== NEWSLETTER SEND ERROR ===");
      console.error("Error sending newsletter:", error);
      res.status(500).json({ error: error.message || "Failed to send newsletter" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
