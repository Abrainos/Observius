import { storage } from "../storage";
import type { Alert, InsertAlert } from "@shared/schema";

/**
 * Calculate similarity between two strings using Levenshtein distance
 * Returns a value between 0 (completely different) and 1 (identical)
 */
function calculateSimilarity(str1: string, str2: string): number {
  const s1 = str1.toLowerCase().trim();
  const s2 = str2.toLowerCase().trim();
  
  if (s1 === s2) return 1;
  if (s1.length === 0 || s2.length === 0) return 0;
  
  // Simple word-based similarity (faster than full Levenshtein)
  const words1 = new Set(s1.split(/\s+/));
  const words2 = new Set(s2.split(/\s+/));
  
  const words1Array = Array.from(words1);
  const words2Array = Array.from(words2);
  
  const intersection = new Set(words1Array.filter(x => words2.has(x)));
  const union = new Set([...words1Array, ...words2Array]);
  
  return intersection.size / union.size;
}

/**
 * Normalize location strings for comparison
 */
function normalizeLocation(location: string): string {
  return location
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .replace(/,/g, '')
    .trim();
}

/**
 * Check if two alerts are duplicates based on:
 * - Title similarity (>80%)
 * - Same country
 * - Similar location
 * - Timestamp within 48 hours of EACH OTHER
 * - Same or adjacent severity level
 */
function isDuplicate(alert1: InsertAlert, alert2: Alert): boolean {
  // Must be same country
  if (alert1.country !== alert2.country) {
    return false;
  }
  
  // Check timestamp proximity (within 48 hours OF EACH OTHER, not from now)
  // Use the source timestamp if provided (e.g., from GDELT), otherwise use current time
  const alert1Time = alert1.timestamp ?? new Date();
  const alert2Time = new Date(alert2.timestamp);
  const hoursDiff = Math.abs(alert1Time.getTime() - alert2Time.getTime()) / (1000 * 60 * 60);
  
  if (hoursDiff > 48) {
    return false;
  }
  
  // Check title similarity
  const titleSimilarity = calculateSimilarity(alert1.title, alert2.title);
  
  if (titleSimilarity > 0.8) {
    console.log(`[DEDUP] High title similarity (${(titleSimilarity * 100).toFixed(0)}%): "${alert1.title}" vs "${alert2.title}"`);
    return true;
  }
  
  // Check location similarity if titles are moderately similar
  if (titleSimilarity > 0.6) {
    const loc1 = normalizeLocation(alert1.location);
    const loc2 = normalizeLocation(alert2.location);
    
    if (loc1 === loc2 || loc1.includes(loc2) || loc2.includes(loc1)) {
      console.log(`[DEDUP] Same location with similar titles: "${loc1}" = "${loc2}"`);
      return true;
    }
  }
  
  // Check if description contains very similar content
  const descSimilarity = calculateSimilarity(alert1.description, alert2.description);
  if (descSimilarity > 0.85) {
    console.log(`[DEDUP] High description similarity (${(descSimilarity * 100).toFixed(0)}%)`);
    return true;
  }
  
  return false;
}

/**
 * Check if an alert is a duplicate of any existing alert
 * Returns the existing alert if duplicate found, otherwise null
 * 
 * CRITICAL: Checks across ALL regions to prevent cross-region duplicates
 * OPTIMIZED: Uses indexed query for recent alerts by country instead of full table scan
 * TIME-AWARE: Anchors the lookback window to the alert's event timestamp, not "now"
 */
export async function findDuplicateAlert(newAlert: InsertAlert): Promise<Alert | null> {
  try {
    // Use the alert's source timestamp if available (e.g., from GDELT backfill)
    // This ensures we find duplicates even for historical events processed late
    const referenceTime = newAlert.timestamp ?? new Date();
    
    // Get alerts within 48 hours of THIS event's timestamp (bidirectional window)
    // This query uses the (country, timestamp) index for performance
    const recentAlerts = await storage.getRecentAlertsByCountry(newAlert.country, 48, referenceTime);
    
    // Check for duplicates among recent alerts
    for (const existingAlert of recentAlerts) {
      if (isDuplicate(newAlert, existingAlert)) {
        return existingAlert;
      }
    }
    
    return null;
  } catch (error) {
    console.error("[DEDUP] Error checking for duplicates:", error);
    return null; // On error, allow the alert (better to have duplicates than miss alerts)
  }
}

/**
 * Create alert only if it's not a duplicate
 * Returns the created alert or null if duplicate was found
 */
export async function createAlertIfNotDuplicate(alertData: InsertAlert): Promise<Alert | null> {
  const duplicate = await findDuplicateAlert(alertData);
  
  if (duplicate) {
    console.log(`[DEDUP] ✗ Skipping duplicate alert for ${alertData.country}: "${alertData.title}"`);
    console.log(`[DEDUP]   Original alert from ${new Date(duplicate.timestamp).toLocaleString()}`);
    return null;
  }
  
  // Not a duplicate, create the alert
  const newAlert = await storage.createAlert(alertData);
  console.log(`[DEDUP] ✓ Created new unique alert for ${alertData.country}: "${alertData.title}"`);
  return newAlert;
}
