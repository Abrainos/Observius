import nodemailer from "nodemailer";
import type { NewsletterSubscriber } from "@shared/schema";

export interface EmailOptions {
  to: string;
  subject: string;
  html: string;
  text: string;
}

class EmailService {
  private transporter: nodemailer.Transporter | null = null;

  initialize() {
    // Check if SMTP settings are configured
    const smtpHost = process.env.SMTP_HOST;
    const smtpPort = process.env.SMTP_PORT;
    const smtpUser = process.env.SMTP_USER;
    const smtpPass = process.env.SMTP_PASS;
    const smtpFrom = process.env.SMTP_FROM || "Observius <noreply@observius.com>";

    if (!smtpHost || !smtpPort || !smtpUser || !smtpPass) {
      console.warn("SMTP settings not configured. Email sending will be disabled.");
      console.warn("To enable email, set: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS");
      return;
    }

    console.log(`[EMAIL] Initializing SMTP transport...`);
    console.log(`[EMAIL] Host: ${smtpHost}`);
    console.log(`[EMAIL] Port: ${smtpPort}`);
    console.log(`[EMAIL] Secure: ${parseInt(smtpPort) === 465}`);
    console.log(`[EMAIL] User: ${smtpUser}`);
    console.log(`[EMAIL] From: ${smtpFrom}`);

    this.transporter = nodemailer.createTransport({
      host: smtpHost,
      port: parseInt(smtpPort),
      secure: parseInt(smtpPort) === 465, // Use TLS for port 465
      auth: {
        user: smtpUser,
        pass: smtpPass,
      },
    });

    console.log("[EMAIL] Email service initialized successfully");
  }

  async sendEmail(options: EmailOptions): Promise<boolean> {
    if (!this.transporter) {
      console.error("Email service not initialized. Skipping email send.");
      return false;
    }

    try {
      console.log(`[EMAIL] Attempting to send email to ${options.to}...`);
      const info = await this.transporter.sendMail({
        from: process.env.SMTP_FROM || "Observius <noreply@observius.com>",
        to: options.to,
        subject: options.subject,
        text: options.text,
        html: options.html,
      });

      console.log(`[EMAIL] ✓ Email sent successfully to ${options.to}: ${info.messageId}`);
      return true;
    } catch (error: any) {
      console.error(`[EMAIL] ✗ Failed to send email to ${options.to}`);
      console.error(`[EMAIL] Error name: ${error.name}`);
      console.error(`[EMAIL] Error message: ${error.message}`);
      console.error(`[EMAIL] Error code: ${error.code}`);
      console.error(`[EMAIL] SMTP response: ${error.response}`);
      console.error(`[EMAIL] Response code: ${error.responseCode}`);
      console.error(`[EMAIL] Command: ${error.command}`);
      console.error(`[EMAIL] Full error object:`, JSON.stringify(error, null, 2));
      return false;
    }
  }

  async sendNewsletterToSubscriber(
    subscriber: NewsletterSubscriber,
    subject: string,
    htmlContent: string,
    textContent: string,
    baseUrl: string = "https://observius.com"
  ): Promise<boolean> {
    const unsubscribeUrl = `${baseUrl}/unsubscribe/${subscriber.unsubscribeToken}`;
    
    // Replace unsubscribe URL placeholder in HTML
    const finalHtml = htmlContent.replace(/\{\{unsubscribeUrl\}\}/g, unsubscribeUrl);
    
    // Add unsubscribe link to text version
    const finalText = `${textContent}\n\n---\n\nTo unsubscribe, visit: ${unsubscribeUrl}`;

    return this.sendEmail({
      to: subscriber.email,
      subject,
      html: finalHtml,
      text: finalText,
    });
  }

  async sendBulkNewsletter(
    subscribers: NewsletterSubscriber[],
    subject: string,
    htmlContent: string,
    textContent: string,
    baseUrl: string = "https://observius.com"
  ): Promise<{ sent: number; failed: number }> {
    let sent = 0;
    let failed = 0;

    console.log(`Starting bulk newsletter send to ${subscribers.length} subscribers...`);

    for (const subscriber of subscribers) {
      const success = await this.sendNewsletterToSubscriber(
        subscriber,
        subject,
        htmlContent,
        textContent,
        baseUrl
      );

      if (success) {
        sent++;
      } else {
        failed++;
      }

      // Add a small delay between emails to avoid rate limiting
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    console.log(`Bulk newsletter send complete: ${sent} sent, ${failed} failed`);

    return { sent, failed };
  }

  isConfigured(): boolean {
    return this.transporter !== null;
  }
}

// Singleton instance
export const emailService = new EmailService();
