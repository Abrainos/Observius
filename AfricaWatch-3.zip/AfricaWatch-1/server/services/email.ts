import nodemailer from "nodemailer";
import { type Alert } from "@shared/schema";

// Email configuration - using a simple transport for MVP
// In production, this would use a proper email service like SendGrid or Resend
const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST || "smtp.gmail.com",
  port: parseInt(process.env.SMTP_PORT || "587"),
  secure: false,
  auth: process.env.SMTP_USER ? {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  } : undefined,
});

export async function sendAlertEmail(
  to: string,
  alert: Alert
): Promise<boolean> {
  try {
    // If no SMTP configured, log instead of sending
    if (!process.env.SMTP_USER) {
      console.log(`[EMAIL] Would send alert to ${to}:`, {
        country: alert.country,
        severity: alert.severity,
        title: alert.title,
        location: alert.location,
      });
      return true;
    }

    const severityColors = {
      critical: "#dc2626",
      high: "#f59e0b",
      moderate: "#fbbf24",
      info: "#3b82f6",
    };

    const color = severityColors[alert.severity as keyof typeof severityColors] || "#3b82f6";

    await transporter.sendMail({
      from: process.env.SMTP_FROM || "alerts@africawatch.com",
      to,
      subject: `🚨 ${alert.severity.toUpperCase()} Alert: ${alert.country} - ${alert.title}`,
      html: `
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
          </head>
          <body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #1f2937; max-width: 600px; margin: 0 auto; padding: 20px;">
            <div style="border-left: 4px solid ${color}; padding-left: 20px; margin-bottom: 24px;">
              <h1 style="color: #111827; margin: 0 0 8px 0; font-size: 24px;">
                ${alert.title}
              </h1>
              <p style="margin: 0; color: #6b7280; font-size: 14px;">
                <strong>${alert.country}</strong> • ${new Date(alert.timestamp).toLocaleString()}
              </p>
            </div>

            <div style="background: #f9fafb; border-radius: 8px; padding: 16px; margin-bottom: 20px;">
              <div style="display: flex; align-items: start; gap: 8px;">
                <span style="font-size: 20px;">📍</span>
                <div>
                  <p style="margin: 0; font-weight: 600; color: #111827;">Location</p>
                  <p style="margin: 4px 0 0 0; color: #374151;">${alert.location}</p>
                </div>
              </div>
            </div>

            <div style="margin-bottom: 20px;">
              <p style="color: #374151; font-size: 16px; line-height: 1.7; margin: 0;">
                ${alert.description}
              </p>
            </div>

            ${alert.violenceDetails ? `
              <div style="background: #fef2f2; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
                <p style="margin: 0 0 8px 0; font-weight: 600; text-transform: uppercase; font-size: 12px; color: #991b1b; letter-spacing: 0.05em;">Violence Details</p>
                <p style="margin: 0; color: #7f1d1d;">${alert.violenceDetails}</p>
              </div>
            ` : ''}

            ${alert.policeIntervention ? `
              <div style="background: #eff6ff; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
                <p style="margin: 0 0 8px 0; font-weight: 600; text-transform: uppercase; font-size: 12px; color: #1e40af; letter-spacing: 0.05em;">Police Intervention</p>
                <p style="margin: 0; color: #1e3a8a;">${alert.policeIntervention}</p>
              </div>
            ` : ''}

            <div style="border-top: 1px solid #e5e7eb; padding-top: 16px; margin-top: 20px;">
              <p style="margin: 0; color: #6b7280; font-size: 14px;">
                <strong>Source:</strong> ${alert.source}
              </p>
              ${alert.sourceUrl ? `
                <p style="margin: 8px 0 0 0;">
                  <a href="${alert.sourceUrl}" style="color: #2563eb; text-decoration: none;">
                    View Original Article →
                  </a>
                </p>
              ` : ''}
            </div>

            <div style="margin-top: 32px; padding-top: 20px; border-top: 2px solid #e5e7eb; text-align: center;">
              <p style="margin: 0; color: #9ca3af; font-size: 12px;">
                AfricaWatch Monitoring System • Automated Alert
              </p>
            </div>
          </body>
        </html>
      `,
    });

    return true;
  } catch (error) {
    console.error("Error sending email:", error);
    return false;
  }
}

export async function sendBulkAlertEmails(
  emails: string[],
  alert: Alert
): Promise<void> {
  for (const email of emails) {
    await sendAlertEmail(email, alert);
    // Rate limiting
    await new Promise(resolve => setTimeout(resolve, 100));
  }
}
