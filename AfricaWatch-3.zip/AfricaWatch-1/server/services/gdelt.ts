import { spawn } from "child_process";
import { africanCountries, asianCountries, europeanCountries, middleEasternCountries, southAmericanCountries, northAmericanCountries, centralSouthAsianCountries, type Region } from "@shared/schema";

// GDELT Event Codes (CAMEO taxonomy)
// https://www.gdeltproject.org/data/documentation/CAMEO.Manual.1.1b3.pdf
const CONFLICT_EVENT_CODES = {
  PROTEST: "14",           // Protest, demonstrate, rally
  ASSAULT: "18",           // Assault (armed attacks, physical violence)
  FIGHT: "19",             // Fight (combat, armed clashes)
  MASS_VIOLENCE: "20",     // Engage in unconventional mass violence
  COERCE: "17",            // Coerce (threats, intimidation)
  REDUCE_RELATIONS: "13",  // Reduce relations (includes sanctions, expulsions)
};

// Map GDELT GoldsteinScale to EarthenWatch severity (revised per architect review)
// GoldsteinScale ranges from -10 (most severe conflict) to +10 (most cooperative)
// Tightened thresholds to better reflect true risk levels
function mapGoldsteinToSeverity(goldstein: number): "critical" | "high" | "moderate" | "info" {
  if (goldstein <= -5) return "critical";  // Extreme violence (war, mass casualties)
  if (goldstein <= -3) return "high";      // Severe conflict (armed clashes, major protests)
  if (goldstein <= -1) return "moderate";  // Moderate conflict (protests, demonstrations)
  return "info";                            // Low-level incidents
}

// Determine region from country code
function getRegionFromCountry(countryName: string): Region | null {
  if (africanCountries.includes(countryName as any)) return "africa";
  if (asianCountries.includes(countryName as any)) return "asia";
  if (europeanCountries.includes(countryName as any)) return "europe";
  if (middleEasternCountries.includes(countryName as any)) return "middleeast";
  if (southAmericanCountries.includes(countryName as any)) return "southamerica";
  if (northAmericanCountries.includes(countryName as any)) return "northamerica";
  if (centralSouthAsianCountries.includes(countryName as any)) return "centralsouthasia";
  return null;
}

// Country code to country name mapping (ISO 3166-1 alpha-2 and alternatives)
// Covers all 178 monitored countries from shared/schema.ts (54 Africa + 49 Asia + 44 Europe + 18 Middle East + 13 South America)
const COUNTRY_CODE_MAP: Record<string, string> = {
  // Africa (54 countries)
  "DZ": "Algeria", "AO": "Angola", "BJ": "Benin", "BW": "Botswana",
  "BF": "Burkina Faso", "BI": "Burundi", "CV": "Cabo Verde", "CM": "Cameroon",
  "CF": "Central African Republic", "TD": "Chad", "KM": "Comoros", "CG": "Congo",
  "CD": "Democratic Republic of Congo", "COD": "Democratic Republic of Congo", // Alternative code
  "DJ": "Djibouti", "EG": "Egypt",
  "GQ": "Equatorial Guinea", "ER": "Eritrea", "SZ": "Eswatini", "ET": "Ethiopia",
  "GA": "Gabon", "GM": "Gambia", "GH": "Ghana", "GN": "Guinea", "GW": "Guinea-Bissau",
  "CI": "Ivory Coast", "KE": "Kenya", "LS": "Lesotho", "LR": "Liberia",
  "LY": "Libya", "MG": "Madagascar", "MW": "Malawi", "ML": "Mali",
  "MR": "Mauritania", "MU": "Mauritius", "MA": "Morocco", "MZ": "Mozambique",
  "NA": "Namibia", "NE": "Niger", "NG": "Nigeria", "RW": "Rwanda",
  "ST": "Sao Tome and Principe", "SN": "Senegal", "SC": "Seychelles", "SL": "Sierra Leone",
  "SO": "Somalia", "ZA": "South Africa", "SS": "South Sudan", "SD": "Sudan", "SDN": "Sudan",
  "TZ": "Tanzania", "TG": "Togo", "TN": "Tunisia", "UG": "Uganda",
  "ZM": "Zambia", "ZW": "Zimbabwe",
  
  // Asia (49 countries, including Middle East overlap)
  "AF": "Afghanistan", "AFG": "Afghanistan", // Alternative code
  "AM": "Armenia", "AZ": "Azerbaijan", "BH": "Bahrain",
  "BD": "Bangladesh", "BT": "Bhutan", "BN": "Brunei", "KH": "Cambodia",
  "CN": "China", "CY": "Cyprus", "GE": "Georgia", "IN": "India",
  "ID": "Indonesia", "IR": "Iran", "IQ": "Iraq", "IL": "Israel",
  "JP": "Japan", "JO": "Jordan", "JOR": "Jordan", // Alternative code
  "KZ": "Kazakhstan", "KW": "Kuwait",
  "KG": "Kyrgyzstan", "LA": "Laos", "LB": "Lebanon", "MY": "Malaysia",
  "MV": "Maldives", "MN": "Mongolia", "MM": "Myanmar", "NP": "Nepal",
  "KP": "North Korea", "OM": "Oman", "PK": "Pakistan", "PS": "Palestine", "PSE": "Palestine",
  "PH": "Philippines", "QA": "Qatar", "RU": "Russia", "SA": "Saudi Arabia", "SAU": "Saudi Arabia",
  "SG": "Singapore", "KR": "South Korea", "LK": "Sri Lanka", "SY": "Syria", "SYR": "Syria",
  "TW": "Taiwan", "TJ": "Tajikistan", "TH": "Thailand", "TL": "Timor-Leste", "TLS": "Timor-Leste",
  "TR": "Turkey", "TUR": "Turkey", // Alternative code
  "TM": "Turkmenistan", "AE": "United Arab Emirates", "ARE": "United Arab Emirates",
  "UZ": "Uzbekistan", "VN": "Vietnam", "YE": "Yemen", "YEM": "Yemen", // Alternative code
  
  // Europe (44 countries)
  "AL": "Albania", "AD": "Andorra", "AT": "Austria", "BY": "Belarus",
  "BE": "Belgium", "BA": "Bosnia and Herzegovina", "BG": "Bulgaria", "HR": "Croatia",
  "CZ": "Czechia", "CZE": "Czechia", // Alternative codes for Czechia (formerly Czech Republic)
  "DK": "Denmark", "EE": "Estonia", "FI": "Finland",
  "FR": "France", "DE": "Germany", "GR": "Greece", "HU": "Hungary",
  "IS": "Iceland", "IE": "Ireland", "IT": "Italy", "XK": "Kosovo", "XKS": "Kosovo",
  "LV": "Latvia", "LI": "Liechtenstein", "LT": "Lithuania", "LU": "Luxembourg",
  "MT": "Malta", "MD": "Moldova", "MC": "Monaco", "ME": "Montenegro",
  "NL": "Netherlands", "MK": "North Macedonia", "MKD": "North Macedonia",
  "NO": "Norway", "PL": "Poland",
  "PT": "Portugal", "RO": "Romania", "SM": "San Marino", "RS": "Serbia",
  "SK": "Slovakia", "SI": "Slovenia", "ES": "Spain", "SE": "Sweden",
  "CH": "Switzerland", "UA": "Ukraine", "GB": "United Kingdom", "UK": "United Kingdom",
  "VA": "Vatican City", "VAT": "Vatican City",
  
  // South America (13 countries)
  "AR": "Argentina", "ARG": "Argentina", // Alternative code
  "BO": "Bolivia", "BOL": "Bolivia",
  "BR": "Brazil", "BRA": "Brazil",
  "CL": "Chile", "CHL": "Chile",
  "CO": "Colombia", "COL": "Colombia",
  "EC": "Ecuador", "ECU": "Ecuador",
  "GY": "Guyana", "GUY": "Guyana",
  "PY": "Paraguay", "PRY": "Paraguay",
  "PE": "Peru", "PER": "Peru",
  "SR": "Suriname", "SUR": "Suriname",
  "UY": "Uruguay", "URY": "Uruguay",
  "VE": "Venezuela", "VEN": "Venezuela",
  "GF": "French Guiana", "GUF": "French Guiana",
};

// Build validation set from schema to ensure complete coverage
const ALL_MONITORED_COUNTRIES = new Set([
  ...africanCountries,
  ...asianCountries,
  ...europeanCountries,
  ...middleEasternCountries,
  ...southAmericanCountries,
  ...northAmericanCountries,
  ...centralSouthAsianCountries,
]);

// Log mapping coverage on module load for debugging
const mappedCountries = new Set(Object.values(COUNTRY_CODE_MAP));
const unmappedFromSchema: string[] = [];
for (const country of Array.from(ALL_MONITORED_COUNTRIES)) {
  if (!mappedCountries.has(country)) {
    unmappedFromSchema.push(country);
  }
}
if (unmappedFromSchema.length > 0) {
  console.warn(`[GDELT] Warning: ${unmappedFromSchema.length} countries in schema lack GDELT code mappings:`, unmappedFromSchema);
}

export interface GDELTEvent {
  date: string;
  actor1: string;
  actor2: string;
  eventCode: string;
  eventRootCode: string;
  goldsteinScale: number;
  numMentions: number;
  avgTone: number;
  country: string;
  countryCode: string;
  latitude: number | null;
  longitude: number | null;
  sourceUrl: string;
}

/**
 * Fetch GDELT events for the last 24 hours
 * Uses Python gdelt library via child process with timeout protection
 */
export async function fetchGDELTEvents(): Promise<GDELTEvent[]> {
  return new Promise((resolve, reject) => {
    // Timeout after 60 seconds to prevent hanging
    const TIMEOUT_MS = 60000;
    let timeoutHandle: NodeJS.Timeout | null = null;
    let processKilled = false;
    
    const pythonScript = `
import json
import sys
import warnings
from datetime import datetime, timedelta

# Suppress all warnings
warnings.filterwarnings('ignore')

# Capture result to ensure only clean JSON goes to stdout
json_output = None

try:
    import gdelt
    import pandas as pd
except ImportError as e:
    json_output = json.dumps([])
    sys.exit(0)

try:
    # Initialize GDELT v2 (gdelt >= 0.1.16)
    gd = gdelt.gdelt(version=2)

    # Get events from last 3 days (GDELT updates with delay)
    start_date = (datetime.now() - timedelta(days=3)).strftime('%Y %m %d')
    end_date = (datetime.now() - timedelta(days=1)).strftime('%Y %m %d')

    # Fetch events - returns pandas DataFrame
    # Note: This may produce warnings to stderr which are suppressed
    results = gd.Search(
        [start_date, end_date],
        table='events',
        coverage=False  # Disable coverage to reduce stdout contamination
    )
    
    if results is None or (isinstance(results, pd.DataFrame) and results.empty):
        json_output = json.dumps([])
    else:
        # Filter for conflict events (protest, assault, fight, mass violence)
        conflict_codes = ['14', '18', '19', '20']
        
        # Filter DataFrame for conflict events
        if 'EventRootCode' in results.columns:
            mask = results['EventRootCode'].astype(str).str.startswith(tuple(conflict_codes))
            filtered = results[mask]
            
            # Convert to JSON (limit to 500 events)
            filtered_limited = filtered.head(500)
            
            # Convert DataFrame to list of dicts
            output = filtered_limited.to_dict('records')
            json_output = json.dumps(output)
        else:
            json_output = json.dumps([])
        
except Exception as e:
    # Always return empty array on error - never fail
    json_output = json.dumps([])

# Only now print the clean JSON output (nothing else should have printed to stdout)
if json_output is not None:
    print(json_output, flush=True)
    
# Always exit with success
sys.exit(0)
`;

    const python = spawn("python3", ["-c", pythonScript]);
    let stdout = "";
    let stderr = "";

    // Set timeout to kill process if it hangs
    timeoutHandle = setTimeout(() => {
      if (!processKilled) {
        console.error("[GDELT] Timeout - killing Python process after", TIMEOUT_MS, "ms");
        processKilled = true;
        python.kill("SIGKILL");
        resolve([]); // Gracefully degrade to empty results
      }
    }, TIMEOUT_MS);

    python.stdout.on("data", (data) => {
      stdout += data.toString();
    });

    python.stderr.on("data", (data) => {
      stderr += data.toString();
    });

    python.on("close", (code) => {
      // Clear timeout
      if (timeoutHandle) clearTimeout(timeoutHandle);
      
      // If process was killed by timeout, already resolved
      if (processKilled) return;
      
      if (code !== 0) {
        console.error("[GDELT] Python script failed:", stderr);
        // Gracefully degrade instead of rejecting
        resolve([]);
        return;
      }

      try {
        const rawData = JSON.parse(stdout);
        
        if (rawData.error) {
          console.error("[GDELT] Error from Python:", rawData.error);
          resolve([]);
          return;
        }

        if (!Array.isArray(rawData)) {
          console.error("[GDELT] Invalid data format - expected array, got:", typeof rawData);
          resolve([]);
          return;
        }

        // Parse and map GDELT events to our format
        const events: GDELTEvent[] = rawData
          .map((event: any) => {
            const countryCode = event.ActionGeo_CountryCode || event.Actor1Geo_CountryCode;
            const countryName = COUNTRY_CODE_MAP[countryCode];
            
            // Skip if not in our monitored regions
            if (!countryName) return null;
            
            return {
              date: event.SQLDATE || event.Day || "",
              actor1: event.Actor1Name || "Unknown",
              actor2: event.Actor2Name || "",
              eventCode: event.EventCode || "",
              eventRootCode: event.EventRootCode || "",
              goldsteinScale: parseFloat(event.GoldsteinScale || "0"),
              numMentions: parseInt(event.NumMentions || "1"),
              avgTone: parseFloat(event.AvgTone || "0"),
              country: countryName,
              countryCode: countryCode,
              latitude: event.ActionGeo_Lat ? parseFloat(event.ActionGeo_Lat) : null,
              longitude: event.ActionGeo_Long ? parseFloat(event.ActionGeo_Long) : null,
              sourceUrl: event.SOURCEURL || "",
            };
          })
          .filter((event): event is GDELTEvent => event !== null);

        console.log(`[GDELT] Fetched ${events.length} conflict events from last 24 hours`);
        resolve(events);
      } catch (error) {
        console.error("[GDELT] Failed to parse results:", error);
        console.error("[GDELT] Raw Python stdout:", stdout.substring(0, 500)); // First 500 chars for debugging
        resolve([]);
      }
    });

    python.on("error", (error) => {
      // Clear timeout
      if (timeoutHandle) clearTimeout(timeoutHandle);
      
      console.error("[GDELT] Failed to spawn Python:", error);
      // Gracefully degrade instead of rejecting
      resolve([]);
    });
  });
}

/**
 * Convert GDELT event to EarthenWatch alert format
 */
export function convertGDELTToAlert(event: GDELTEvent) {
  const region = getRegionFromCountry(event.country);
  if (!region) return null;

  // Create title based on event type
  let eventType = "Security Incident";
  if (event.eventRootCode === "14") eventType = "Protest";
  else if (event.eventRootCode === "18") eventType = "Assault";
  else if (event.eventRootCode === "19") eventType = "Armed Conflict";
  else if (event.eventRootCode === "20") eventType = "Mass Violence";

  const title = `${eventType} in ${event.country}`;
  
  // Create description
  let description = `${event.actor1}`;
  if (event.actor2) {
    description += ` vs ${event.actor2}`;
  }
  description += ` - ${eventType} event detected`;

  // Determine severity from GoldsteinScale
  const severity = mapGoldsteinToSeverity(event.goldsteinScale);

  // Create location string
  const location = event.country;

  // AI analysis based on tone and mentions
  let analysis = `GDELT detected ${eventType.toLowerCase()} activity in ${event.country}. `;
  analysis += `Event intensity: ${event.goldsteinScale.toFixed(1)} (scale -10 to +10). `;
  analysis += `Media coverage: ${event.numMentions} mention${event.numMentions > 1 ? 's' : ''}. `;
  
  if (event.avgTone < -5) {
    analysis += "Media tone is highly negative, indicating serious concerns.";
  } else if (event.avgTone < 0) {
    analysis += "Media tone is negative.";
  } else {
    analysis += "Media tone is neutral to positive.";
  }

  // Parse GDELT timestamp (format: YYYYMMDD or YYYYMMDDHHMMSS)
  let eventTimestamp: Date | undefined;
  if (event.date) {
    try {
      const dateStr = event.date.toString();
      if (dateStr.length === 8) {
        // YYYYMMDD format
        const year = parseInt(dateStr.substring(0, 4));
        const month = parseInt(dateStr.substring(4, 6)) - 1; // JS months are 0-indexed
        const day = parseInt(dateStr.substring(6, 8));
        eventTimestamp = new Date(year, month, day);
      } else if (dateStr.length >= 14) {
        // YYYYMMDDHHMMSS format
        const year = parseInt(dateStr.substring(0, 4));
        const month = parseInt(dateStr.substring(4, 6)) - 1;
        const day = parseInt(dateStr.substring(6, 8));
        const hour = parseInt(dateStr.substring(8, 10));
        const minute = parseInt(dateStr.substring(10, 12));
        const second = parseInt(dateStr.substring(12, 14));
        eventTimestamp = new Date(year, month, day, hour, minute, second);
      }
    } catch (error) {
      console.warn(`[GDELT] Failed to parse timestamp: ${event.date}`);
    }
  }

  return {
    region,
    country: event.country,
    title,
    description,
    location,
    severity,
    source: "GDELT Global Event Database",
    sourceUrl: event.sourceUrl || "https://www.gdeltproject.org/",
    violenceDetails: `Event code: ${event.eventCode}, Goldstein Scale: ${event.goldsteinScale}`,
    policeIntervention: null,
    aiAnalysis: analysis,
    latitude: event.latitude?.toString() || null,
    longitude: event.longitude?.toString() || null,
    timestamp: eventTimestamp, // Include source timestamp for deduplication
  };
}
