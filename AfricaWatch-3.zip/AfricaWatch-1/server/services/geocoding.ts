import axios from 'axios';

interface GeocodeResult {
  latitude: number;
  longitude: number;
  displayName: string;
}

/**
 * Geocode a location string to latitude/longitude coordinates using Nominatim API
 * @param location - Location string (e.g., "Lagos, Nigeria" or "Addis Ababa, Ethiopia")
 * @param country - Optional country to help narrow down the search
 * @returns Coordinates if found, null otherwise
 */
export async function geocodeLocation(
  location: string,
  country?: string
): Promise<GeocodeResult | null> {
  try {
    // Build search query
    let searchQuery = location;
    
    // If location is just a country name, add "capital" to get the capital city
    if (country && location.toLowerCase() === country.toLowerCase()) {
      searchQuery = `${location} capital`;
    } else if (country && !location.toLowerCase().includes(country.toLowerCase())) {
      // Add country to query if not already included
      searchQuery = `${location}, ${country}`;
    }

    // Make request to Nominatim API
    const response = await axios.get('https://nominatim.openstreetmap.org/search', {
      params: {
        q: searchQuery,
        format: 'json',
        limit: 1,
        countrycodes: getCountryCode(country || location),
      },
      headers: {
        'User-Agent': 'GlobalWatch-SecurityMonitor/1.0',
      },
      timeout: 5000, // 5 second timeout
    });

    if (response.data && response.data.length > 0) {
      const result = response.data[0];
      return {
        latitude: parseFloat(result.lat),
        longitude: parseFloat(result.lon),
        displayName: result.display_name,
      };
    }

    return null;
  } catch (error) {
    console.error(`Geocoding error for "${location}":`, error instanceof Error ? error.message : error);
    return null;
  }
}

/**
 * Get ISO country code for African countries
 */
function getCountryCode(countryName: string): string | undefined {
  const countryCodeMap: { [key: string]: string } = {
    'algeria': 'dz',
    'angola': 'ao',
    'benin': 'bj',
    'botswana': 'bw',
    'burkina faso': 'bf',
    'burundi': 'bi',
    'cabo verde': 'cv',
    'cape verde': 'cv',
    'cameroon': 'cm',
    'central african republic': 'cf',
    'chad': 'td',
    'comoros': 'km',
    'congo': 'cg',
    'democratic republic of congo': 'cd',
    'drc': 'cd',
    'djibouti': 'dj',
    'egypt': 'eg',
    'equatorial guinea': 'gq',
    'eritrea': 'er',
    'eswatini': 'sz',
    'ethiopia': 'et',
    'gabon': 'ga',
    'gambia': 'gm',
    'ghana': 'gh',
    'guinea': 'gn',
    'guinea-bissau': 'gw',
    'ivory coast': 'ci',
    "cote d'ivoire": 'ci',
    'kenya': 'ke',
    'lesotho': 'ls',
    'liberia': 'lr',
    'libya': 'ly',
    'madagascar': 'mg',
    'malawi': 'mw',
    'mali': 'ml',
    'mauritania': 'mr',
    'mauritius': 'mu',
    'morocco': 'ma',
    'mozambique': 'mz',
    'namibia': 'na',
    'niger': 'ne',
    'nigeria': 'ng',
    'rwanda': 'rw',
    'sao tome and principe': 'st',
    'senegal': 'sn',
    'seychelles': 'sc',
    'sierra leone': 'sl',
    'somalia': 'so',
    'south africa': 'za',
    'south sudan': 'ss',
    'sudan': 'sd',
    'tanzania': 'tz',
    'togo': 'tg',
    'tunisia': 'tn',
    'uganda': 'ug',
    'zambia': 'zm',
    'zimbabwe': 'zw',
    
    // Asian countries
    'afghanistan': 'af',
    'armenia': 'am',
    'azerbaijan': 'az',
    'bahrain': 'bh',
    'bangladesh': 'bd',
    'bhutan': 'bt',
    'brunei': 'bn',
    'cambodia': 'kh',
    'china': 'cn',
    'cyprus': 'cy',
    'georgia': 'ge',
    'india': 'in',
    'indonesia': 'id',
    'iran': 'ir',
    'iraq': 'iq',
    'israel': 'il',
    'japan': 'jp',
    'jordan': 'jo',
    'kazakhstan': 'kz',
    'kuwait': 'kw',
    'kyrgyzstan': 'kg',
    'laos': 'la',
    'lebanon': 'lb',
    'malaysia': 'my',
    'maldives': 'mv',
    'mongolia': 'mn',
    'myanmar': 'mm',
    'burma': 'mm',
    'nepal': 'np',
    'north korea': 'kp',
    'oman': 'om',
    'pakistan': 'pk',
    'palestine': 'ps',
    'philippines': 'ph',
    'qatar': 'qa',
    'russia': 'ru',
    'saudi arabia': 'sa',
    'singapore': 'sg',
    'south korea': 'kr',
    'sri lanka': 'lk',
    'syria': 'sy',
    'taiwan': 'tw',
    'tajikistan': 'tj',
    'thailand': 'th',
    'timor-leste': 'tl',
    'east timor': 'tl',
    'turkey': 'tr',
    'turkmenistan': 'tm',
    'united arab emirates': 'ae',
    'uae': 'ae',
    'uzbekistan': 'uz',
    'vietnam': 'vn',
    'yemen': 'ye',
    
    // European countries
    'albania': 'al',
    'andorra': 'ad',
    'austria': 'at',
    'belarus': 'by',
    'belgium': 'be',
    'bosnia and herzegovina': 'ba',
    'bosnia': 'ba',
    'bulgaria': 'bg',
    'croatia': 'hr',
    'czech republic': 'cz',
    'czechia': 'cz',
    'denmark': 'dk',
    'estonia': 'ee',
    'finland': 'fi',
    'france': 'fr',
    'germany': 'de',
    'greece': 'gr',
    'hungary': 'hu',
    'iceland': 'is',
    'ireland': 'ie',
    'italy': 'it',
    'kosovo': 'xk',
    'latvia': 'lv',
    'liechtenstein': 'li',
    'lithuania': 'lt',
    'luxembourg': 'lu',
    'malta': 'mt',
    'moldova': 'md',
    'monaco': 'mc',
    'montenegro': 'me',
    'netherlands': 'nl',
    'north macedonia': 'mk',
    'macedonia': 'mk',
    'norway': 'no',
    'poland': 'pl',
    'portugal': 'pt',
    'romania': 'ro',
    'san marino': 'sm',
    'serbia': 'rs',
    'slovakia': 'sk',
    'slovenia': 'si',
    'spain': 'es',
    'sweden': 'se',
    'switzerland': 'ch',
    'ukraine': 'ua',
    'united kingdom': 'gb',
    'uk': 'gb',
    'britain': 'gb',
    'vatican city': 'va',
  };

  return countryCodeMap[countryName.toLowerCase()];
}

/**
 * Batch geocode multiple locations with rate limiting
 * Nominatim has a rate limit of 1 request per second
 */
export async function batchGeocodeLocations(
  locations: Array<{ location: string; country?: string }>
): Promise<Array<GeocodeResult | null>> {
  const results: Array<GeocodeResult | null> = [];
  
  for (const loc of locations) {
    const result = await geocodeLocation(loc.location, loc.country);
    results.push(result);
    
    // Rate limiting: wait 1 second between requests
    if (locations.indexOf(loc) < locations.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 1100));
    }
  }
  
  return results;
}
