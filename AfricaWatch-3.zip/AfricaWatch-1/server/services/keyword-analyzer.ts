import type { AnalysisResult } from './openai';

// Keywords for security incident detection
const CRITICAL_KEYWORDS = [
  // Armed conflicts & warfare
  'armed conflict', 'military offensive', 'combat', 'warfare', 'battle', 'airstrike', 'bombing', 'shelling',
  'armed forces', 'soldiers killed', 'military operation', 'insurgency', 'rebel attack', 'militant attack',
  
  // Terrorism & extremism
  'terrorist attack', 'terrorism', 'suicide bomber', 'extremist', 'jihadist', 'boko haram', 'al-shabab',
  'isis', 'aqim', 'terrorist group', 'militant group', 'armed group',
  
  // Violence against civilians
  'massacre', 'genocide', 'ethnic cleansing', 'mass killing', 'civilian casualties', 'civilians killed',
  'attack on civilians', 'sectarian violence', 'religious violence',
  
  // Instability indicators
  'coup', 'military coup', 'overthrow', 'uprising', 'civil war', 'armed rebellion', 'insurrection',
  
  // Drug cartels & major drug violence
  'drug cartel', 'cartel war', 'cartel violence', 'narco terrorism', 'drug war', 'cartel killing',
  'mass grave', 'fentanyl trafficking', 'drug lord killed', 'cartel massacre',
];

// Prescreening result interface
interface PrescreenResult {
  shouldProcess: boolean;
  confidenceLevel: 'critical' | 'high' | 'moderate' | 'low';
  matchedKeywords: string[];
}

// Fast keyword prescreening to reduce unnecessary AI calls
// Returns true if article likely contains security-relevant content
export function prescreenArticle(title: string, content: string): PrescreenResult {
  const text = `${title} ${content}`.toLowerCase();
  const matchedKeywords: string[] = [];
  
  // CRITICAL keywords = immediate pass (high confidence)
  for (const keyword of CRITICAL_KEYWORDS) {
    if (text.includes(keyword.toLowerCase())) {
      matchedKeywords.push(keyword);
      return {
        shouldProcess: true,
        confidenceLevel: 'critical',
        matchedKeywords,
      };
    }
  }
  
  // HIGH keywords = immediate pass (high confidence)
  let highMatches = 0;
  for (const keyword of HIGH_KEYWORDS) {
    if (text.includes(keyword.toLowerCase())) {
      highMatches++;
      matchedKeywords.push(keyword);
      if (highMatches >= 1) {
        return {
          shouldProcess: true,
          confidenceLevel: 'high',
          matchedKeywords,
        };
      }
    }
  }
  
  // MODERATE keywords = need 2 matches OR 1 match + location cue
  let moderateMatches = 0;
  for (const keyword of MODERATE_KEYWORDS) {
    if (text.includes(keyword.toLowerCase())) {
      moderateMatches++;
      matchedKeywords.push(keyword);
    }
  }
  
  // Check if there's a location mention (country or city)
  const hasLocation = AFRICAN_COUNTRIES.some(c => text.includes(c.toLowerCase())) ||
                      ASIAN_COUNTRIES.some(c => text.includes(c.toLowerCase())) ||
                      EUROPEAN_COUNTRIES.some(c => text.includes(c.toLowerCase())) ||
                      MIDDLEEASTERN_COUNTRIES.some(c => text.includes(c.toLowerCase())) ||
                      SOUTHAMERICAN_COUNTRIES.some(c => text.includes(c.toLowerCase()));
  
  // Pass if 2+ moderate matches OR 1 moderate + location
  if (moderateMatches >= 2 || (moderateMatches >= 1 && hasLocation)) {
    return {
      shouldProcess: true,
      confidenceLevel: 'moderate',
      matchedKeywords,
    };
  }
  
  // No sufficient matches - filter out
  return {
    shouldProcess: false,
    confidenceLevel: 'low',
    matchedKeywords,
  };
}

const HIGH_KEYWORDS = [
  // Protests & unrest
  'violent protest', 'riot', 'clashes', 'police brutality', 'tear gas', 'rubber bullets',
  'protest violence', 'demonstrators killed', 'protesters shot', 'security forces fired',
  
  // Political violence
  'political assassination', 'opposition leader killed', 'activist killed', 'journalist killed',
  'targeted killing', 'extrajudicial killing',
  
  // Displacement & humanitarian crisis
  'refugees fleeing', 'mass displacement', 'humanitarian crisis', 'famine', 'starvation',
  'internally displaced', 'refugee crisis',
  
  // Drug-related violence
  'drug trafficking', 'cocaine seizure', 'heroin seizure', 'fentanyl seized', 'drug bust',
  'narcotics trafficking', 'drug smuggling', 'cartel shootout', 'narco violence', 'drug gang',
];

const MODERATE_KEYWORDS = [
  // Security concerns
  'security threat', 'security alert', 'military deployment', 'troops deployed', 'curfew',
  'state of emergency', 'martial law', 'border closure', 'heightened security',
  
  // Protests & demonstrations
  'mass protest', 'demonstration', 'strike', 'walkout', 'sit-in', 'blockade',
  'anti-government protest', 'opposition rally',
  
  // Tensions & warnings
  'ethnic tensions', 'sectarian tensions', 'rising tensions', 'conflict escalation',
  'warning signs', 'potential violence',
  
  // Drug enforcement & seizures
  'drug seizure', 'drugs seized', 'cocaine', 'heroin', 'fentanyl', 'methamphetamine',
  'opium', 'marijuana trafficking', 'illicit drugs', 'narcotics', 'drug arrest', 'drug raid',
];

const INFO_KEYWORDS = [
  'peacekeeping', 'peace talks', 'ceasefire', 'negotiation', 'diplomatic effort',
  'humanitarian aid', 'relief operation', 'security advisory', 'travel warning',
  'drug policy', 'anti-drug operation', 'drug enforcement', 'border patrol',
];

// African countries for location extraction
const AFRICAN_COUNTRIES = [
  'Nigeria', 'South Africa', 'Kenya', 'Ethiopia', 'Egypt', 'Ghana', 'Tanzania', 'Uganda', 'Algeria',
  'Sudan', 'Morocco', 'Angola', 'Mozambique', 'Madagascar', 'Cameroon', 'Niger', 'Mali', 'Burkina Faso',
  'Malawi', 'Zambia', 'Somalia', 'Senegal', 'Chad', 'Zimbabwe', 'Guinea', 'Rwanda', 'Benin', 'Tunisia',
  'Burundi', 'South Sudan', 'Togo', 'Sierra Leone', 'Libya', 'Liberia', 'Mauritania', 'Central African Republic',
  'Eritrea', 'Gambia', 'Botswana', 'Namibia', 'Gabon', 'Lesotho', 'Guinea-Bissau', 'Equatorial Guinea',
  'Mauritius', 'Eswatini', 'Djibouti', 'Comoros', 'Cape Verde', 'Sao Tome and Principe', 'Seychelles',
  'Congo', 'Democratic Republic of Congo', 'DRC', 'Ivory Coast', "Cote d'Ivoire",
];

// Asian countries for location extraction
const ASIAN_COUNTRIES = [
  'Afghanistan', 'Armenia', 'Azerbaijan', 'Bahrain', 'Bangladesh', 'Bhutan', 'Brunei', 'Cambodia',
  'China', 'Cyprus', 'Georgia', 'India', 'Indonesia', 'Iran', 'Iraq', 'Israel', 'Japan',
  'Jordan', 'Kazakhstan', 'Kuwait', 'Kyrgyzstan', 'Laos', 'Lebanon', 'Malaysia', 'Maldives',
  'Mongolia', 'Myanmar', 'Burma', 'Nepal', 'North Korea', 'Oman', 'Pakistan', 'Palestine', 'Philippines',
  'Qatar', 'Russia', 'Saudi Arabia', 'Singapore', 'South Korea', 'Sri Lanka', 'Syria', 'Taiwan',
  'Tajikistan', 'Thailand', 'Timor-Leste', 'East Timor', 'Turkey', 'Turkmenistan', 'United Arab Emirates',
  'UAE', 'Uzbekistan', 'Vietnam', 'Yemen',
];

// European countries for location extraction
const EUROPEAN_COUNTRIES = [
  'Albania', 'Andorra', 'Austria', 'Belarus', 'Belgium', 'Bosnia and Herzegovina', 'Bosnia', 'Herzegovina',
  'Bulgaria', 'Croatia', 'Czech Republic', 'Czechia', 'Denmark', 'Estonia', 'Finland', 'France', 'Germany',
  'Greece', 'Hungary', 'Iceland', 'Ireland', 'Italy', 'Kosovo', 'Latvia', 'Liechtenstein', 'Lithuania',
  'Luxembourg', 'Malta', 'Moldova', 'Monaco', 'Montenegro', 'Netherlands', 'North Macedonia', 'Macedonia',
  'Norway', 'Poland', 'Portugal', 'Romania', 'San Marino', 'Serbia', 'Slovakia', 'Slovenia', 'Spain',
  'Sweden', 'Switzerland', 'Ukraine', 'United Kingdom', 'UK', 'Britain', 'Vatican City',
];

// Middle Eastern countries for location extraction
const MIDDLEEASTERN_COUNTRIES = [
  'Bahrain', 'Cyprus', 'Egypt', 'Iran', 'Iraq', 'Israel', 'Jordan', 'Kuwait',
  'Lebanon', 'Oman', 'Palestine', 'Qatar', 'Saudi Arabia', 'Syria', 'Turkey',
  'United Arab Emirates', 'UAE', 'Yemen', 'Afghanistan',
];

// South American countries for location extraction
const SOUTHAMERICAN_COUNTRIES = [
  'Argentina', 'Bolivia', 'Brazil', 'Chile', 'Colombia', 'Ecuador', 'Guyana',
  'Paraguay', 'Peru', 'Suriname', 'Uruguay', 'Venezuela', 'French Guiana',
];

// Major African cities and regions to map to countries
const AFRICAN_LOCATIONS: { [key: string]: string } = {
  // Nigeria
  'lagos': 'Nigeria', 'abuja': 'Nigeria', 'kano': 'Nigeria', 'ibadan': 'Nigeria', 'borno': 'Nigeria',
  'kaduna': 'Nigeria', 'plateau': 'Nigeria', 'benue': 'Nigeria', 'maiduguri': 'Nigeria',
  
  // South Africa
  'johannesburg': 'South Africa', 'cape town': 'South Africa', 'durban': 'South Africa', 
  'pretoria': 'South Africa', 'soweto': 'South Africa', 'gauteng': 'South Africa',
  
  // Kenya
  'nairobi': 'Kenya', 'mombasa': 'Kenya', 'kisumu': 'Kenya', 'nakuru': 'Kenya',
  
  // Ethiopia
  'addis ababa': 'Ethiopia', 'tigray': 'Ethiopia', 'amhara': 'Ethiopia', 'oromia': 'Ethiopia',
  
  // Egypt
  'cairo': 'Egypt', 'alexandria': 'Egypt', 'giza': 'Egypt', 'sinai': 'Egypt',
  
  // Somalia
  'mogadishu': 'Somalia', 'puntland': 'Somalia', 'somaliland': 'Somalia',
  
  // Sudan
  'khartoum': 'Sudan', 'darfur': 'Sudan', 'south kordofan': 'Sudan',
  
  // DRC
  'kinshasa': 'Democratic Republic of Congo', 'goma': 'Democratic Republic of Congo', 
  'kivu': 'Democratic Republic of Congo', 'katanga': 'Democratic Republic of Congo',
  
  // Other major cities
  'tripoli': 'Libya', 'benghazi': 'Libya', 'casablanca': 'Morocco', 'tunis': 'Tunisia',
  'algiers': 'Algeria', 'kampala': 'Uganda', 'dar es salaam': 'Tanzania', 'accra': 'Ghana',
  'harare': 'Zimbabwe', 'lusaka': 'Zambia', 'maputo': 'Mozambique', 'luanda': 'Angola',
  
  // Regions
  'sahel': 'Mali', 'lake chad': 'Nigeria', 'horn of africa': 'Somalia',
};

// Major Asian cities and regions to map to countries
const ASIAN_LOCATIONS: { [key: string]: string } = {
  // India
  'mumbai': 'India', 'delhi': 'India', 'new delhi': 'India', 'bangalore': 'India', 'kolkata': 'India',
  'chennai': 'India', 'hyderabad': 'India', 'pune': 'India', 'kashmir': 'India', 'punjab': 'India',
  
  // China
  'beijing': 'China', 'shanghai': 'China', 'hong kong': 'China', 'shenzhen': 'China', 'guangzhou': 'China',
  'xinjiang': 'China', 'tibet': 'China', 'wuhan': 'China',
  
  // Pakistan
  'islamabad': 'Pakistan', 'karachi': 'Pakistan', 'lahore': 'Pakistan', 'peshawar': 'Pakistan',
  'balochistan': 'Pakistan', 'khyber pakhtunkhwa': 'Pakistan',
  
  // Afghanistan
  'kabul': 'Afghanistan', 'kandahar': 'Afghanistan', 'herat': 'Afghanistan', 'helmand': 'Afghanistan',
  
  // Myanmar
  'yangon': 'Myanmar', 'rangoon': 'Myanmar', 'mandalay': 'Myanmar', 'rakhine': 'Myanmar',
  
  // Thailand
  'bangkok': 'Thailand', 'phuket': 'Thailand',
  
  // Philippines
  'manila': 'Philippines', 'mindanao': 'Philippines', 'davao': 'Philippines',
  
  // Indonesia
  'jakarta': 'Indonesia', 'bali': 'Indonesia', 'java': 'Indonesia', 'sumatra': 'Indonesia',
  
  // Middle East
  'baghdad': 'Iraq', 'mosul': 'Iraq', 'basra': 'Iraq',
  'damascus': 'Syria', 'aleppo': 'Syria',
  'beirut': 'Lebanon',
  'jerusalem': 'Israel', 'tel aviv': 'Israel', 'gaza': 'Palestine', 'west bank': 'Palestine',
  'riyadh': 'Saudi Arabia', 'jeddah': 'Saudi Arabia',
  'tehran': 'Iran',
  'sanaa': 'Yemen', 'aden': 'Yemen',
  
  // Other major cities
  'tokyo': 'Japan', 'seoul': 'South Korea', 'pyongyang': 'North Korea',
  'singapore': 'Singapore', 'kuala lumpur': 'Malaysia',
  'dhaka': 'Bangladesh', 'kathmandu': 'Nepal', 'colombo': 'Sri Lanka',
};

// Major European cities and regions to map to countries
const EUROPEAN_LOCATIONS: { [key: string]: string } = {
  // Western Europe
  'london': 'United Kingdom', 'manchester': 'United Kingdom', 'birmingham': 'United Kingdom',
  'glasgow': 'United Kingdom', 'belfast': 'United Kingdom', 'edinburgh': 'United Kingdom',
  'paris': 'France', 'marseille': 'France', 'lyon': 'France', 'nice': 'France',
  'berlin': 'Germany', 'munich': 'Germany', 'frankfurt': 'Germany', 'hamburg': 'Germany',
  'madrid': 'Spain', 'barcelona': 'Spain', 'valencia': 'Spain', 'catalonia': 'Spain', 'basque': 'Spain',
  'rome': 'Italy', 'milan': 'Italy', 'naples': 'Italy', 'turin': 'Italy', 'sicily': 'Italy',
  'amsterdam': 'Netherlands', 'rotterdam': 'Netherlands', 'the hague': 'Netherlands',
  'brussels': 'Belgium', 'antwerp': 'Belgium', 'bruges': 'Belgium',
  'lisbon': 'Portugal', 'porto': 'Portugal',
  'zurich': 'Switzerland', 'geneva': 'Switzerland', 'bern': 'Switzerland',
  'vienna': 'Austria',
  
  // Northern Europe
  'stockholm': 'Sweden', 'oslo': 'Norway', 'copenhagen': 'Denmark', 'helsinki': 'Finland',
  'reykjavik': 'Iceland', 'dublin': 'Ireland',
  
  // Eastern Europe
  'kyiv': 'Ukraine', 'kiev': 'Ukraine', 'odesa': 'Ukraine', 'kharkiv': 'Ukraine', 'donbas': 'Ukraine',
  'donetsk': 'Ukraine', 'luhansk': 'Ukraine', 'crimea': 'Ukraine',
  'moscow': 'Russia', 'st petersburg': 'Russia', 'sochi': 'Russia', 'chechnya': 'Russia',
  'warsaw': 'Poland', 'krakow': 'Poland',
  'prague': 'Czech Republic',
  'budapest': 'Hungary',
  'bucharest': 'Romania',
  'minsk': 'Belarus',
  
  // Southern Europe & Balkans
  'athens': 'Greece',
  'belgrade': 'Serbia',
  'sarajevo': 'Bosnia and Herzegovina',
  'zagreb': 'Croatia',
  'pristina': 'Kosovo',
  'skopje': 'North Macedonia',
  'tirana': 'Albania',
  'sofia': 'Bulgaria',
};

// Major Middle Eastern cities and regions to map to countries
const MIDDLEEASTERN_LOCATIONS: { [key: string]: string } = {
  // Gulf States
  'dubai': 'United Arab Emirates', 'abu dhabi': 'United Arab Emirates',
  'riyadh': 'Saudi Arabia', 'jeddah': 'Saudi Arabia', 'mecca': 'Saudi Arabia', 'medina': 'Saudi Arabia',
  'doha': 'Qatar',
  'kuwait city': 'Kuwait',
  'manama': 'Bahrain',
  'muscat': 'Oman',
  
  // Levant
  'jerusalem': 'Israel', 'tel aviv': 'Israel', 'haifa': 'Israel',
  'gaza': 'Palestine', 'gaza strip': 'Palestine', 'west bank': 'Palestine', 'ramallah': 'Palestine',
  'beirut': 'Lebanon', 'tripoli': 'Lebanon',
  'damascus': 'Syria', 'aleppo': 'Syria', 'homs': 'Syria',
  'amman': 'Jordan',
  
  // Iraq
  'baghdad': 'Iraq', 'mosul': 'Iraq', 'basra': 'Iraq', 'erbil': 'Iraq', 'kirkuk': 'Iraq',
  'kurdistan': 'Iraq',
  
  // Iran
  'tehran': 'Iran', 'isfahan': 'Iran', 'shiraz': 'Iran',
  
  // Yemen
  'sanaa': 'Yemen', 'aden': 'Yemen',
  
  // Egypt (North Africa/Middle East)
  'cairo': 'Egypt', 'alexandria': 'Egypt', 'giza': 'Egypt', 'sinai': 'Egypt',
  
  // Turkey
  'ankara': 'Turkey', 'istanbul': 'Turkey', 'izmir': 'Turkey',
  
  // Afghanistan
  'kabul': 'Afghanistan', 'kandahar': 'Afghanistan', 'herat': 'Afghanistan', 'helmand': 'Afghanistan',
  
  // Cyprus
  'nicosia': 'Cyprus',
};

// Major South American cities and regions to map to countries
const SOUTHAMERICAN_LOCATIONS: { [key: string]: string } = {
  // Brazil
  'sao paulo': 'Brazil', 'rio de janeiro': 'Brazil', 'brasilia': 'Brazil', 'salvador': 'Brazil',
  'fortaleza': 'Brazil', 'belo horizonte': 'Brazil', 'manaus': 'Brazil', 'recife': 'Brazil',
  'porto alegre': 'Brazil', 'favela': 'Brazil', 'amazonia': 'Brazil', 'amazon': 'Brazil',
  
  // Argentina
  'buenos aires': 'Argentina', 'cordoba': 'Argentina', 'rosario': 'Argentina', 'mendoza': 'Argentina',
  
  // Colombia
  'bogota': 'Colombia', 'medellin': 'Colombia', 'cali': 'Colombia', 'barranquilla': 'Colombia',
  'cartagena': 'Colombia', 'antioquia': 'Colombia', 'narino': 'Colombia', 'cauca': 'Colombia',
  
  // Peru
  'lima': 'Peru', 'cusco': 'Peru', 'arequipa': 'Peru', 'ayacucho': 'Peru',
  
  // Venezuela
  'caracas': 'Venezuela', 'maracaibo': 'Venezuela', 'valencia': 'Venezuela', 'zulia': 'Venezuela',
  
  // Chile
  'santiago': 'Chile', 'valparaiso': 'Chile', 'concepcion': 'Chile',
  
  // Ecuador
  'quito': 'Ecuador', 'guayaquil': 'Ecuador', 'cuenca': 'Ecuador',
  
  // Bolivia
  'la paz': 'Bolivia', 'santa cruz': 'Bolivia', 'cochabamba': 'Bolivia', 'sucre': 'Bolivia',
  
  // Paraguay
  'asuncion': 'Paraguay',
  
  // Uruguay
  'montevideo': 'Uruguay',
  
  // Guyana
  'georgetown': 'Guyana',
  
  // Suriname
  'paramaribo': 'Suriname',
  
  // French Guiana
  'cayenne': 'French Guiana',
};

interface KeywordMatch {
  keyword: string;
  severity: 'critical' | 'high' | 'moderate' | 'info';
}

// Region-specific exclusion keywords to prevent cross-region contamination
const REGION_EXCLUSIONS: Record<string, string[]> = {
  africa: [
    // Exclude Asia/Middle East/South America conflicts
    'gaza', 'palestine', 'israel', 'hamas', 'west bank',
    'syria', 'iraq', 'iran', 'yemen', 'lebanon',
    'ukraine', 'russia', 'afghanistan', 'pakistan',
    'colombia', 'brazil', 'venezuela', 'mexico',
  ],
  asia: [
    // Exclude purely African/European/South American conflicts (keep Middle East as part of Asia)
    'south africa', 'nigeria', 'kenya', 'ethiopia',
    'france', 'germany', 'spain', 'italy',
    'colombia', 'brazil', 'venezuela', 'argentina',
  ],
  europe: [
    // Exclude purely African/Asian/Middle Eastern/South American conflicts
    'south africa', 'nigeria', 'kenya', 'ethiopia',
    'gaza', 'palestine', 'israel', 'hamas',
    'syria', 'iraq', 'iran', 'yemen', 'lebanon', 'saudi arabia',
    'colombia', 'brazil', 'venezuela', 'argentina',
  ],
  middleeast: [
    // Exclude purely African/Asian/European/South American conflicts
    'south africa', 'nigeria', 'kenya', 'ethiopia',
    'china', 'japan', 'korea', 'india',
    'france', 'germany', 'spain', 'italy',
    'colombia', 'brazil', 'venezuela', 'argentina',
  ],
  southamerica: [
    // Exclude purely African/Asian/European/Middle Eastern conflicts
    'south africa', 'nigeria', 'kenya', 'ethiopia',
    'china', 'japan', 'korea', 'india', 'pakistan',
    'france', 'germany', 'spain', 'italy', 'ukraine',
    'gaza', 'palestine', 'israel', 'syria', 'iraq', 'yemen',
  ],
};

export function analyzeWithKeywords(
  title: string,
  content: string,
  source: string,
  country?: string,
  region: 'africa' | 'asia' | 'europe' | 'middleeast' | 'southamerica' | 'northamerica' | 'centralsouthasia' = 'africa'
): AnalysisResult | null {
  const text = `${title} ${content}`.toLowerCase();
  
  // FIRST: Check if article is about other regions (reject cross-region contamination)
  const exclusions = REGION_EXCLUSIONS[region] || [];
  for (const zone of exclusions) {
    if (text.includes(zone.toLowerCase())) {
      console.log(`[KEYWORD] ✗ Rejected - cross-region conflict detected (${region}): ${zone} in "${title.substring(0, 60)}..."`);
      return null;
    }
  }
  
  // Find all matching keywords
  const matches: KeywordMatch[] = [];
  
  for (const keyword of CRITICAL_KEYWORDS) {
    if (text.includes(keyword.toLowerCase())) {
      matches.push({ keyword, severity: 'critical' });
    }
  }
  
  for (const keyword of HIGH_KEYWORDS) {
    if (text.includes(keyword.toLowerCase())) {
      matches.push({ keyword, severity: 'high' });
    }
  }
  
  for (const keyword of MODERATE_KEYWORDS) {
    if (text.includes(keyword.toLowerCase())) {
      matches.push({ keyword, severity: 'moderate' });
    }
  }
  
  for (const keyword of INFO_KEYWORDS) {
    if (text.includes(keyword.toLowerCase())) {
      matches.push({ keyword, severity: 'info' });
    }
  }
  
  // If no security keywords found, not relevant
  if (matches.length === 0) {
    return null;
  }
  
  // Determine severity (highest priority match wins)
  let severity: 'critical' | 'high' | 'moderate' | 'info' = 'info';
  if (matches.some(m => m.severity === 'critical')) severity = 'critical';
  else if (matches.some(m => m.severity === 'high')) severity = 'high';
  else if (matches.some(m => m.severity === 'moderate')) severity = 'moderate';
  
  // Extract location - MUST match the target region to be relevant
  let location = '';
  let foundRegionLocation = false;
  
  // Select the appropriate country and location lists based on region
  const countryList = region === 'africa' ? AFRICAN_COUNTRIES :
                       region === 'asia' ? ASIAN_COUNTRIES :
                       region === 'europe' ? EUROPEAN_COUNTRIES :
                       region === 'middleeast' ? MIDDLEEASTERN_COUNTRIES :
                       SOUTHAMERICAN_COUNTRIES;
  
  const locationMap = region === 'africa' ? AFRICAN_LOCATIONS :
                       region === 'asia' ? ASIAN_LOCATIONS :
                       region === 'europe' ? EUROPEAN_LOCATIONS :
                       region === 'middleeast' ? MIDDLEEASTERN_LOCATIONS :
                       SOUTHAMERICAN_LOCATIONS;
  
  // ALWAYS search for regional country/location in content (don't trust source country alone)
  for (const regionCountry of countryList) {
    if (text.includes(regionCountry.toLowerCase())) {
      location = regionCountry;
      foundRegionLocation = true;
      break;
    }
  }
  
  // If no country found, try to find regional city/region
  if (!foundRegionLocation) {
    for (const [cityOrRegion, mappedCountry] of Object.entries(locationMap)) {
      if (text.includes(cityOrRegion.toLowerCase())) {
        location = mappedCountry;
        foundRegionLocation = true;
        break;
      }
    }
  }
  
  // CRITICAL: If no regional location found, this is NOT a relevant security incident for this region
  if (!foundRegionLocation || !location) {
    console.log(`[KEYWORD] ✗ Rejected - security keywords found but NO ${region} location: ${title.substring(0, 60)}...`);
    return null;
  }
  
  // Generate title and description with more context
  const alertTitle = title.length > 120 ? title.substring(0, 117) + '...' : title;
  
  // Build analysis summary with context
  const keywordList = matches.slice(0, 3).map(m => m.keyword).join(', ');
  
  // Extract a meaningful snippet from content (first 250 chars that aren't HTML/ads)
  const contentPreview = content
    .replace(/<[^>]*>/g, '') // Remove HTML tags
    .replace(/\s+/g, ' ') // Normalize whitespace
    .trim()
    .substring(0, 250);
  
  const description = `${severity.toUpperCase()} security incident in ${location}. Keywords detected: ${keywordList}. ${contentPreview}... (Source: ${source})`;
  
  console.log(`[KEYWORD] ✓ Matched for ${location}: ${severity.toUpperCase()} - ${title.substring(0, 60)}...`);
  
  // Generate contextual analysis based on available information
  const contextualAnalysis = generateContextualAnalysis(location, severity, matches[0]?.keyword || '', contentPreview);
  
  return {
    isRelevant: true,
    severity,
    title: alertTitle,
    description,
    location,
    incidentType: matches[0]?.keyword || 'security incident',
    aiAnalysis: contextualAnalysis,
  };
}

// Generate historical context based on location and incident type
function generateContextualAnalysis(location: string, severity: string, incidentType: string, content: string): string {
  const regionalContext: { [key: string]: string } = {
    'Nigeria': 'Nigeria faces ongoing security challenges from Boko Haram insurgency in the northeast, banditry in the northwest, and farmer-herder conflicts across the middle belt. Economic inequality and ethnic tensions contribute to instability.',
    'Ethiopia': 'Ethiopia has experienced ethnic conflicts particularly in Tigray, Amhara, and Oromia regions. Historical grievances, political power struggles, and resource competition drive violence in these areas.',
    'Somalia': 'Somalia continues to battle Al-Shabab militants while dealing with clan-based conflicts and weak central governance. Decades of civil war have left deep divisions and limited state capacity.',
    'South Sudan': 'South Sudan faces intercommunal violence and political instability stemming from the 2013 civil war. Ethnic divisions, resource disputes, and competition for political power fuel ongoing conflicts.',
    'Democratic Republic of Congo': 'Eastern DRC experiences persistent militia violence driven by mineral wealth competition, ethnic tensions, and spillover from regional conflicts. Weak governance enables armed group proliferation.',
    'Mali': 'Mali battles jihadist insurgencies and ethnic conflicts in the Sahel region. Weak state presence, poverty, and regional instability from Libya and Algeria contribute to security challenges.',
    'Burkina Faso': 'Burkina Faso faces escalating jihadist violence linked to regional Sahel insurgencies. Ethnic tensions, poverty, and governance gaps enable militant group recruitment and operations.',
    'Sudan': 'Sudan experiences conflict driven by power struggles between military factions, ethnic tensions in Darfur and other regions, and economic instability following years of authoritarian rule.',
    'Central African Republic': 'CAR suffers from armed group conflicts over resources and territory. Weak central authority, religious tensions, and regional interference perpetuate violence.',
    'Cameroon': 'Cameroon faces Anglophone separatist violence in western regions and Boko Haram attacks in the north. Historical marginalization and linguistic divisions fuel these conflicts.',
  };

  const context = regionalContext[location] || `${location} experiences security challenges stemming from regional instability, political tensions, and socio-economic factors common across the African continent.`;
  
  // Truncate to ensure under 200 words
  const analysis = `${context} This ${severity}-level incident involving ${incidentType} reflects these underlying tensions.`;
  return analysis.substring(0, 600); // Roughly 200 words max
}
