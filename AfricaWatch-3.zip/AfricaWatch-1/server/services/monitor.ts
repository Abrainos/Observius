import * as cron from "node-cron";
import { storage } from "../storage";
import { fetchAllRSSFeeds } from "./rss-feeds";
import { scrapeRedditSecurity } from "./reddit";
import { fetchNewsAPI } from "./newsapi";
import { searchTwitterSecurity } from "./twitter";
import { analyzeNewsContent } from "./openai";
import { analyzeWithKeywords, prescreenArticle } from "./keyword-analyzer";
import { sendBulkAlertEmails } from "./email";
import { translateArticle } from "./translator";
import { geocodeLocation } from "./geocoding";
import { africanCountries, asianCountries, europeanCountries, middleEasternCountries, countriesByRegion } from "@shared/schema";
import { aggregateByCountry, createCombinedAlert } from "./social-media-aggregator";
import { fetchGDELTEvents, convertGDELTToAlert } from "./gdelt";
import { createAlertIfNotDuplicate } from "./deduplication";

// COST REDUCTION: Use keyword analyzer by default to eliminate AI API costs
// Set USE_AI_ANALYSIS=true in environment to enable AI (expensive)
const USE_KEYWORD_ANALYZER = process.env.USE_AI_ANALYSIS !== 'true';

console.log(`[MONITOR] Analysis mode: ${USE_KEYWORD_ANALYZER ? 'KEYWORD-BASED (no AI costs)' : 'AI-POWERED ($$)'}`);

let isMonitoring = false;
let currentScheduler: cron.ScheduledTask | null = null;

// Get monitoring interval from environment or default to 30 minutes
export function getMonitoringInterval(): number {
  const interval = parseInt(process.env.MONITORING_INTERVAL_MINUTES || "30", 10);
  return isNaN(interval) || interval < 1 ? 30 : interval;
}

export async function runMonitoringCycle(): Promise<void> {
  if (isMonitoring) {
    console.log("[MONITOR] Already running, skipping...");
    return;
  }

  isMonitoring = true;
  console.log("[MONITOR] Starting monitoring cycle...");

  try {
    // Step 1: Fetch articles from RSS feeds (covers all African countries)
    const articles = await fetchAllRSSFeeds();
    console.log(`[MONITOR] Fetched ${articles.length} articles from RSS feeds`);

    // Step 2: Fetch from social media sources and GDELT
    const [redditPosts, newsApiArticles, tweets, gdeltEvents] = await Promise.all([
      scrapeRedditSecurity(),
      fetchNewsAPI(),
      searchTwitterSecurity(),
      fetchGDELTEvents().catch(err => {
        console.error("[MONITOR] GDELT fetch failed:", err);
        return [];
      })
    ]);
    
    console.log(`[MONITOR] Fetched ${redditPosts.length} posts from Reddit`);
    console.log(`[MONITOR] Fetched ${newsApiArticles.length} articles from NewsAPI`);
    console.log(`[MONITOR] Fetched ${tweets.length} tweets from Twitter/X`);
    console.log(`[MONITOR] Fetched ${gdeltEvents.length} events from GDELT`);

    // Step 2a: Initialize counters
    let newAlerts = 0;
    let totalAnalyses = 0;

    // Step 2b: Process social media posts with aggregation logic
    // Only create alerts when there are 2+ instances for the same country
    
    // Translate social media posts before aggregation
    console.log(`[MONITOR] Translating ${redditPosts.length} Reddit posts, ${newsApiArticles.length} NewsAPI articles, ${tweets.length} tweets...`);
    
    const translatedRedditPosts = await Promise.all(
      redditPosts.map(async post => {
        const translation = await translateArticle(post.title, post.content);
        if (translation.wasTranslated) {
          console.log(`[MONITOR] ✓ Translated Reddit post from ${translation.language}: "${translation.title.substring(0, 60)}..."`);
        }
        return {
          source: `Reddit (r/${post.subreddit})`,
          sourceUrl: post.permalink,
          title: translation.title,
          content: translation.content,
          author: post.author
        };
      })
    );
    
    const translatedNewsApiArticles = await Promise.all(
      newsApiArticles.map(async article => {
        const translation = await translateArticle(article.title, article.content || article.description);
        if (translation.wasTranslated) {
          console.log(`[MONITOR] ✓ Translated NewsAPI article from ${translation.language}: "${translation.title.substring(0, 60)}..."`);
        }
        return {
          source: article.source,
          sourceUrl: article.sourceUrl,
          title: translation.title,
          content: translation.content,
        };
      })
    );
    
    const translatedTweets = await Promise.all(
      tweets.map(async tweet => {
        // Pass full tweet text for both title and content to ensure reliable language detection
        const translation = await translateArticle(tweet.text, tweet.text);
        if (translation.wasTranslated) {
          console.log(`[MONITOR] ✓ Translated tweet from ${translation.language}: "${translation.title.substring(0, 60)}..."`);
        }
        return {
          source: `Twitter (@${tweet.author})`,
          sourceUrl: tweet.url,
          title: translation.title.substring(0, 100), // Truncate after translation
          content: translation.content,
          author: tweet.author
        };
      })
    );
    
    const socialMediaPosts = [
      ...translatedRedditPosts,
      ...translatedNewsApiArticles,
      ...translatedTweets
    ];
    
    console.log(`[MONITOR] Translation complete. Processing ${socialMediaPosts.length} social media posts.`);

    // Aggregate social media posts by country (requires 2+ instances)
    const socialMediaAggregations = aggregateByCountry(socialMediaPosts);
    console.log(`[MONITOR] Found ${socialMediaAggregations.length} countries with 2+ social media instances`);

    // Create combined alerts for social media aggregations
    for (const aggregation of socialMediaAggregations) {
      const { title, description, sources } = createCombinedAlert(aggregation);
      const country = aggregation.country;

      // Geocode location (use country capital as fallback)
      const geocoded = await geocodeLocation(country, country);

      // Determine region for this country
      let region: "africa" | "asia" | "europe" | "middleeast" = "africa";
      if (asianCountries.includes(country as any)) {
        region = "asia";
      } else if (europeanCountries.includes(country as any)) {
        region = "europe";
      } else if (middleEasternCountries.includes(country as any)) {
        region = "middleeast";
      }

      // Create one global alert per incident (with deduplication)
      const alert = await createAlertIfNotDuplicate({
        country,
        region,
        title,
        description,
        location: country,
        severity: "high", // Social media aggregation indicates significant activity
        source: "Social Media Aggregation",
        violenceDetails: `${aggregation.posts.length} social media posts detected`,
        policeIntervention: null,
        aiAnalysis: `Multiple social media sources (${aggregation.posts.length} posts) are reporting security incidents in ${country}. This aggregation suggests coordinated or widespread activity.`,
        sourceUrl: sources,
        latitude: geocoded?.latitude.toString(),
        longitude: geocoded?.longitude.toString(),
      });
      
      if (alert) {
        newAlerts++;
        console.log(`[SOCIAL MEDIA] ✓ Created global aggregated alert for ${country} (${aggregation.posts.length} posts)`);
      }
    }

    // Step 2c: Process GDELT events (with deduplication)
    console.log(`[MONITOR] Processing ${gdeltEvents.length} GDELT events...`);
    for (const event of gdeltEvents) {
      const alertData = convertGDELTToAlert(event);
      if (alertData) {
        const alert = await createAlertIfNotDuplicate(alertData);
        if (alert) {
          newAlerts++;
          console.log(`[GDELT] ✓ Created ${alertData.severity} alert for ${alertData.country}: ${alertData.title}`);
        }
      }
    }

    // Step 3: Process RSS feed articles with keyword prescreening (reduces AI usage by ~90%)
    const allArticles = articles;
    console.log(`[MONITOR] Total RSS articles to analyze: ${allArticles.length} items`);
    
    let prescreenPassed = 0;
    let prescreenSkipped = 0;
    
    for (const article of allArticles) {
      // Use original article title/content for analysis
      const articleTitle = article.title;
      const articleContent = article.content;
      
      // PRESCREEN: Fast keyword check to filter out irrelevant articles (90% reduction in AI calls)
      const prescreen = prescreenArticle(articleTitle, articleContent);
      if (!prescreen.shouldProcess) {
        prescreenSkipped++;
        continue; // Skip articles without security keywords
      }
      prescreenPassed++;
      
      console.log(`[MONITOR] Processing article "${articleTitle.substring(0, 60)}..." from ${article.source} [${prescreen.confidenceLevel}]`);
      
      // For pan-African sources, let AI determine relevant countries
      // For specific country sources, analyze for those countries only
      if (article.countries.includes("all")) {
        totalAnalyses++;
        
        let analysis;
        // Only use AI for critical/high confidence prescreens (further reduces AI usage)
        // Use keyword analyzer for moderate confidence to save costs
        if (USE_KEYWORD_ANALYZER || prescreen.confidenceLevel === 'moderate') {
          // Use keyword-based analysis directly with region from feed
          analysis = analyzeWithKeywords(articleTitle, articleContent, article.source, undefined, article.region);
        } else {
          // Only use AI for critical/high confidence matches (best 10% of articles)
          analysis = await analyzeNewsContent(
            articleContent,
            "Africa (determine specific countries)",
            article.sourceUrl
          );
          
          // If AI returns null/empty, use keyword analyzer as fallback
          if (!analysis || !analysis.isRelevant) {
            analysis = analyzeWithKeywords(articleTitle, articleContent, article.source, undefined, article.region);
          }
        }

        if (analysis && analysis.isRelevant) {
          // Extract country from location or use a default approach
          // The AI should specify location which often includes country
          // Use the appropriate country list based on the article's region
          const regionCountries = countriesByRegion[article.region];
          const countryFromLocation = regionCountries.find(c => 
            analysis.location?.includes(c) || analysis.title?.includes(c) || analysis.description?.includes(c)
          );
          
          const targetCountry = countryFromLocation || "Unknown";
          
          if (countryFromLocation) {
            // Always attempt translation - translateArticle will auto-detect language
            let finalTitle = analysis.title;
            let finalDescription = analysis.description;
            let originalTitle: string | undefined;
            let originalDescription: string | undefined;
            let detectedLanguage: string | undefined;
            let wasTranslated = false;
            
            // Always translate - the translateArticle function will detect language
            // and skip translation if already in English
            try {
              const translation = await translateArticle(article.title, article.content);
              if (translation.wasTranslated) {
                // Store original text
                originalTitle = article.title;
                originalDescription = article.content;
                detectedLanguage = translation.language;
                wasTranslated = true;
                
                // Use translated title/description for the alert
                finalTitle = translation.title;
                finalDescription = translation.content;
                
                console.log(`[MONITOR] ✓ Translated alert from ${translation.language}: "${finalTitle.substring(0, 60)}..."`);
              }
            } catch (error) {
              console.error('[MONITOR] Translation failed, using original text:', error instanceof Error ? error.message : 'Unknown error');
            }
            
            // Geocode the location to get coordinates
            const geocoded = await geocodeLocation(analysis.location, countryFromLocation);
            
            // Create one global alert per incident (with deduplication)
            const alert = await createAlertIfNotDuplicate({
              country: countryFromLocation,
              region: article.region,
              title: finalTitle,
              description: finalDescription,
              location: analysis.location,
              severity: analysis.severity,
              source: article.source,
              sourceUrl: article.sourceUrl,
              violenceDetails: analysis.violenceDetails,
              policeIntervention: analysis.policeIntervention,
              aiAnalysis: analysis.aiAnalysis,
              latitude: geocoded?.latitude.toString(),
              longitude: geocoded?.longitude.toString(),
              originalTitle: originalTitle,
              originalDescription: originalDescription,
              detectedLanguage: detectedLanguage,
              wasTranslated: wasTranslated,
            });
            
            if (alert) {
              newAlerts++;
              if (geocoded) {
                console.log(`[MONITOR] ✓ Geocoded location: ${geocoded.displayName}`);
              }
              console.log(`[MONITOR] ✓ New global ${analysis.severity} alert for ${countryFromLocation}: ${analysis.title}`);
            }
          } else {
            console.log(`[MONITOR] ✗ Relevant but couldn't determine country from: ${analysis.location}`);
          }
        } else {
          console.log(`[MONITOR] ✗ Not relevant African security news`);
        }
      } else {
        // Specific country sources - analyze for designated countries
        for (const country of article.countries) {
          totalAnalyses++;
          
          let analysis;
          // Only use AI for critical/high confidence prescreens (reduces AI usage by ~90%)
          // Use keyword analyzer for moderate confidence to save costs
          if (USE_KEYWORD_ANALYZER || prescreen.confidenceLevel === 'moderate') {
            // Use keyword-based analysis directly with region from feed
            analysis = analyzeWithKeywords(articleTitle, articleContent, article.source, country, article.region);
          } else {
            // Only use AI for critical/high confidence matches
            analysis = await analyzeNewsContent(
              articleContent,
              country,
              article.sourceUrl
            );
            
            // If AI returns null/empty, use keyword analyzer as fallback
            if (!analysis || !analysis.isRelevant) {
              analysis = analyzeWithKeywords(articleTitle, articleContent, article.source, country, article.region);
            }
          }

          if (analysis && analysis.isRelevant) {
            // Always attempt translation - translateArticle will auto-detect language
            let finalTitle = analysis.title;
            let finalDescription = analysis.description;
            let originalTitle: string | undefined;
            let originalDescription: string | undefined;
            let detectedLanguage: string | undefined;
            let wasTranslated = false;
            
            // Always translate - the translateArticle function will detect language
            // and skip translation if already in English
            try {
              const translation = await translateArticle(article.title, article.content);
              if (translation.wasTranslated) {
                // Store original text
                originalTitle = article.title;
                originalDescription = article.content;
                detectedLanguage = translation.language;
                wasTranslated = true;
                
                // Use translated title/description for the alert
                finalTitle = translation.title;
                finalDescription = translation.content;
                
                console.log(`[MONITOR] ✓ Translated alert from ${translation.language}: "${finalTitle.substring(0, 60)}..."`);
              }
            } catch (error) {
              console.error('[MONITOR] Translation failed, using original text:', error instanceof Error ? error.message : 'Unknown error');
            }
            
            // Geocode the location to get coordinates
            const geocoded = await geocodeLocation(analysis.location, country);
            
            // Create one global alert per incident (with deduplication)
            const alert = await createAlertIfNotDuplicate({
              country,
              region: article.region,
              title: finalTitle,
              description: finalDescription,
              location: analysis.location,
              severity: analysis.severity,
              source: article.source,
              sourceUrl: article.sourceUrl,
              violenceDetails: analysis.violenceDetails,
              policeIntervention: analysis.policeIntervention,
              aiAnalysis: analysis.aiAnalysis,
              latitude: geocoded?.latitude.toString(),
              longitude: geocoded?.longitude.toString(),
              originalTitle: originalTitle,
              originalDescription: originalDescription,
              detectedLanguage: detectedLanguage,
              wasTranslated: wasTranslated,
            });
            
            if (alert) {
              newAlerts++;
              if (geocoded) {
                console.log(`[MONITOR] ✓ Geocoded location: ${geocoded.displayName}`);
              }
              console.log(`[MONITOR] ✓ New global ${analysis.severity} alert for ${country}: ${analysis.title}`);
            }
          } else {
            console.log(`[MONITOR] ✗ Not relevant for ${country}`);
          }

          // Rate limiting for API calls
          await new Promise(resolve => setTimeout(resolve, 500));
        }
      }
      
      // Rate limiting between articles
      await new Promise(resolve => setTimeout(resolve, 500));
    }

    console.log(`[MONITOR] Prescreening: ${prescreenPassed} passed, ${prescreenSkipped} filtered out (${Math.round(prescreenSkipped / (prescreenPassed + prescreenSkipped) * 100)}% reduction)`);
    console.log(`[MONITOR] Completed ${totalAnalyses} analyses, created ${newAlerts} alerts`);

    // Prune old alerts to keep only the 2000 most recent
    if (newAlerts > 0) {
      try {
        const pruned = await storage.pruneOldAlerts(2000);
        if (pruned > 0) {
          console.log(`[MONITOR] Pruned ${pruned} old alerts (keeping 2000 most recent)`);
        }
      } catch (pruneError) {
        console.error("[MONITOR] Error pruning old alerts:", pruneError);
      }
    }

    console.log(`[MONITOR] Monitoring cycle complete. Created ${newAlerts} new alerts.`);
  } catch (error) {
    console.error("[MONITOR] Error during monitoring cycle:", error);
  } finally {
    isMonitoring = false;
  }
}

export function startMonitoringScheduler(): void {
  stopMonitoringScheduler(); // Stop existing scheduler if any
  
  const intervalMinutes = getMonitoringInterval();
  
  // Create cron expression based on interval
  // For intervals >= 60, use hourly cron (every N hours)
  // For intervals < 60, use minute-based cron (every N minutes)
  let cronExpression: string;
  
  if (intervalMinutes >= 60) {
    const hours = Math.floor(intervalMinutes / 60);
    cronExpression = `0 */${hours} * * *`; // Every N hours at minute 0
  } else {
    cronExpression = `*/${intervalMinutes} * * * *`; // Every N minutes
  }
  
  currentScheduler = cron.schedule(cronExpression, async () => {
    console.log("[MONITOR] Scheduled monitoring cycle triggered");
    await runMonitoringCycle();
  });

  console.log(`[MONITOR] Scheduler started - monitoring every ${intervalMinutes} minutes`);
  
  // Run immediately on startup (for testing)
  setTimeout(() => {
    console.log("[MONITOR] Running initial monitoring cycle...");
    runMonitoringCycle();
  }, 5000);
}

export function stopMonitoringScheduler(): void {
  if (currentScheduler) {
    currentScheduler.stop();
    currentScheduler = null;
    console.log("[MONITOR] Scheduler stopped");
  }
}

export function restartMonitoringScheduler(): void {
  console.log("[MONITOR] Restarting scheduler with new interval...");
  startMonitoringScheduler();
}
