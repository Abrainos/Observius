import axios from "axios";

// African countries for NewsAPI filtering
const AFRICAN_COUNTRY_CODES = [
  "za", // South Africa
  "ng", // Nigeria
  "eg", // Egypt
  "ke", // Kenya
  "ma", // Morocco
  "tn", // Tunisia
];

// Asian countries for NewsAPI filtering
const ASIAN_COUNTRY_CODES = [
  "in", // India
  "cn", // China
  "jp", // Japan
  "kr", // South Korea
  "id", // Indonesia
  "th", // Thailand
  "ph", // Philippines
  "my", // Malaysia
  "sg", // Singapore
  "pk", // Pakistan
  "ae", // UAE
  "sa", // Saudi Arabia
  "il", // Israel
  "tr", // Turkey
];

// Security keywords for filtering
const SECURITY_KEYWORDS = [
  "conflict", "violence", "protest", "military", "armed", "attack",
  "terrorism", "security", "police", "unrest", "crisis", "coup",
  "militant", "extremist", "clashes"
];

interface NewsAPIArticle {
  source: string;
  sourceUrl: string;
  title: string;
  description: string;
  content: string;
  publishedAt: Date;
  country?: string;
}

export async function fetchNewsAPI(): Promise<NewsAPIArticle[]> {
  // NewsAPI requires API key - check if available
  const apiKey = process.env.NEWSAPI_KEY;
  
  if (!apiKey) {
    console.log("[NewsAPI] API key not configured - skipping NewsAPI");
    return [];
  }

  const articles: NewsAPIArticle[] = [];

  try {
    // Search for Africa security news in English
    const searchQuery = `(${SECURITY_KEYWORDS.slice(0, 5).join(" OR ")}) AND Africa`;
    
    const response = await axios.get("https://newsapi.org/v2/everything", {
      params: {
        q: searchQuery,
        language: "en",
        sortBy: "publishedAt",
        pageSize: 20,
        apiKey: apiKey,
      },
      timeout: 10000,
    });

    if (response.data?.articles) {
      for (const article of response.data.articles) {
        // Check if article is relevant to African security
        const combinedText = `${article.title} ${article.description || ""}`.toLowerCase();
        const isRelevant = SECURITY_KEYWORDS.some(kw => combinedText.includes(kw));

        if (isRelevant && article.url) {
          articles.push({
            source: article.source?.name || "NewsAPI",
            sourceUrl: article.url,
            title: article.title,
            description: article.description || "",
            content: article.content || article.description || "",
            publishedAt: new Date(article.publishedAt),
          });
        }
      }
    }

    console.log(`[NewsAPI] Fetched ${articles.length} articles`);
  } catch (error) {
    if (axios.isAxiosError(error) && error.response?.status === 401) {
      console.error("[NewsAPI] Invalid API key");
    } else if (axios.isAxiosError(error) && error.response?.status === 429) {
      console.error("[NewsAPI] Rate limit exceeded");
    } else {
      console.error("[NewsAPI] Error:", error instanceof Error ? error.message : "Unknown error");
    }
  }

  return articles;
}
