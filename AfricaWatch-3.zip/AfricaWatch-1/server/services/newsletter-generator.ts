import OpenAI from "openai";
import { storage } from "../storage";
import { type Alert } from "@shared/schema";
import { subDays } from "date-fns";

let openai: OpenAI | null = null;

function getOpenAI(): OpenAI {
  if (!openai) {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error("OPENAI_API_KEY is not configured. Newsletter generation requires OpenAI API access.");
    }
    openai = new OpenAI({
      apiKey: process.env.OPENAI_API_KEY,
    });
  }
  return openai;
}

interface NewsletterContent {
  subject: string;
  htmlContent: string;
  textContent: string;
}

export async function generateDailyNewsletter(): Promise<NewsletterContent> {
  // Fetch all alerts from the last 24 hours (global database, not per-user)
  const yesterday = subDays(new Date(), 1);
  const allAlerts = await storage.getAllAlerts();
  
  // Filter to alerts from last 24 hours
  const recentAlerts = allAlerts.filter(alert => {
    const alertTime = new Date(alert.timestamp);
    return alertTime >= yesterday;
  });

  if (recentAlerts.length === 0) {
    return generateEmptyNewsletter();
  }

  // Group alerts by region for better analysis
  const alertsByRegion = groupAlertsByRegion(recentAlerts);

  // Prepare alert data for AI analysis
  const alertSummaries = recentAlerts.map(alert => ({
    country: alert.country,
    region: alert.region,
    severity: alert.severity,
    title: alert.title,
    description: alert.description,
    location: alert.location,
    timestamp: alert.timestamp,
    aiAnalysis: alert.aiAnalysis,
  }));

  // Generate newsletter content using OpenAI
  const newsletterText = await generateNewsletterWithAI(alertSummaries, alertsByRegion);

  // Convert to HTML
  const htmlContent = convertToHTML(newsletterText);

  return {
    subject: `Observius Daily Security Briefing - ${new Date().toLocaleDateString('en-US', { 
      month: 'long', 
      day: 'numeric', 
      year: 'numeric' 
    })}`,
    htmlContent,
    textContent: newsletterText,
  };
}

function groupAlertsByRegion(alerts: Alert[]): Record<string, Alert[]> {
  const grouped: Record<string, Alert[]> = {};
  
  for (const alert of alerts) {
    const region = alert.region || "unknown";
    if (!grouped[region]) {
      grouped[region] = [];
    }
    grouped[region].push(alert);
  }
  
  return grouped;
}

async function generateNewsletterWithAI(
  alerts: any[],
  alertsByRegion: Record<string, Alert[]>
): Promise<string> {
  const systemPrompt = `You are a senior global security analyst writing the daily Observius Security Briefing. This is a concise, one-page professional intelligence newsletter.

Your task is to create a BRIEF daily briefing with EXACTLY 3 sections. Keep it short and scannable.

STRUCTURE (MANDATORY - USE EXACTLY THESE 3 SECTION HEADERS):

1. EXECUTIVE SUMMARY (EXACTLY 150 words)
   - Brief overview of key security events from the past 24 hours
   - Cover all regions with significant activity
   - Focus on the most critical incidents only

2. TRAVEL ADVISORY (list format)
   - List countries experiencing instability
   - Format: "COUNTRY - Danger Level: X/10 - Brief reason"
   - Only include countries with active security concerns
   - Danger scale: 1 (minor) to 10 (extreme danger)
   - Maximum 10 countries

3. COUP WATCH (list format)
   - List any coup attempts, military takeovers, or government overthrows from the last 24 hours
   - Format: "COUNTRY: Brief description of coup activity"
   - If no coup activity, write "No coup activity reported in the last 24 hours."

RULES:
- Keep the ENTIRE newsletter under 400 words total
- Be direct and concise - no filler text
- Use bullet points for Travel Advisory and Coup Watch sections
- Professional tone
- No hedging language ("might", "possibly") - be direct
- Use active voice
- Focus on actionable intelligence

OUTPUT FORMAT:
Return ONLY the newsletter text with the 3 section headers. No preamble or explanations.`;

  const userPrompt = `Generate today's concise Observius Security Briefing based on these alerts from the past 24 hours:

ALERTS DATA (${alerts.length} total incidents):
${JSON.stringify(alerts.slice(0, 50), null, 2)}

REGIONAL BREAKDOWN:
${Object.entries(alertsByRegion).map(([region, regionAlerts]) => 
  `${region.toUpperCase()}: ${regionAlerts.length} incidents`
).join('\n')}

Create a brief, one-page newsletter with exactly 3 sections: EXECUTIVE SUMMARY (150 words), TRAVEL ADVISORY (countries with danger ratings 1-10), and COUP WATCH (any coup activity). Keep total under 400 words.`;

  try {
    const client = getOpenAI();
    const completion = await client.chat.completions.create({
      model: "gpt-4o-mini", // Use mini model to reduce costs
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: userPrompt },
      ],
      temperature: 0.5,
      max_tokens: 800, // Reduced for shorter newsletter
    });

    return completion.choices[0].message.content || "Failed to generate newsletter content";
  } catch (error) {
    console.error("Error generating newsletter with AI:", error);
    return generateFallbackNewsletter(alerts, alertsByRegion);
  }
}

function generateFallbackNewsletter(
  alerts: any[],
  alertsByRegion: Record<string, Alert[]>
): string {
  let content = `OBSERVIUS DAILY SECURITY BRIEFING\n`;
  content += `${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}\n\n`;
  
  // Executive Summary
  content += `EXECUTIVE SUMMARY\n\n`;
  const criticalCount = alerts.filter(a => a.severity === 'critical').length;
  const highCount = alerts.filter(a => a.severity === 'high').length;
  content += `Observius detected ${alerts.length} security incidents across ${Object.keys(alertsByRegion).length} regions in the last 24 hours. `;
  if (criticalCount > 0) content += `${criticalCount} critical incidents require immediate attention. `;
  if (highCount > 0) content += `${highCount} high-severity events were recorded. `;
  content += `Monitor developments closely.\n\n`;
  
  // Travel Advisory
  content += `TRAVEL ADVISORY\n\n`;
  const countriesWithAlerts = new Map<string, { count: number; severity: string }>();
  for (const alert of alerts) {
    const existing = countriesWithAlerts.get(alert.country);
    const severityRank = alert.severity === 'critical' ? 4 : alert.severity === 'high' ? 3 : alert.severity === 'moderate' ? 2 : 1;
    if (!existing || severityRank > (existing.severity === 'critical' ? 4 : existing.severity === 'high' ? 3 : 2)) {
      countriesWithAlerts.set(alert.country, { count: (existing?.count || 0) + 1, severity: alert.severity });
    } else {
      existing.count++;
    }
  }
  const sortedCountries = Array.from(countriesWithAlerts.entries())
    .map(([country, data]) => ({ country, ...data, danger: data.severity === 'critical' ? 9 : data.severity === 'high' ? 7 : data.severity === 'moderate' ? 5 : 3 }))
    .sort((a, b) => b.danger - a.danger)
    .slice(0, 10);
  for (const c of sortedCountries) {
    content += `• ${c.country} - Danger Level: ${c.danger}/10 - ${c.count} incident(s)\n`;
  }
  content += `\n`;
  
  // Coup Watch
  content += `COUP WATCH\n\n`;
  const coupAlerts = alerts.filter(a => 
    a.title?.toLowerCase().includes('coup') || 
    a.description?.toLowerCase().includes('coup') ||
    a.title?.toLowerCase().includes('military takeover') ||
    a.description?.toLowerCase().includes('overthrow')
  );
  if (coupAlerts.length > 0) {
    for (const alert of coupAlerts) {
      content += `• ${alert.country}: ${alert.title}\n`;
    }
  } else {
    content += `No coup activity reported in the last 24 hours.\n`;
  }
  
  content += `\nFor real-time updates, visit observius.com\n`;
  
  return content;
}

function generateEmptyNewsletter(): NewsletterContent {
  const textContent = `OBSERVIUS DAILY SECURITY BRIEFING
${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}

EXECUTIVE SUMMARY

No significant security incidents were detected in the past 24 hours across our monitored regions. This represents an unusually quiet period in global security monitoring. Remain vigilant.

TRAVEL ADVISORY

No countries currently require elevated travel warnings based on the last 24 hours of monitoring.

COUP WATCH

No coup activity reported in the last 24 hours.

For real-time updates, visit observius.com`;

  return {
    subject: `Observius Daily Security Briefing - ${new Date().toLocaleDateString('en-US', { 
      month: 'long', 
      day: 'numeric', 
      year: 'numeric' 
    })} - All Clear`,
    htmlContent: convertToHTML(textContent),
    textContent,
  };
}

function convertToHTML(text: string): string {
  // Convert plain text to HTML with proper formatting
  let html = text;
  
  // Convert ONLY the main section headers to h2 tags (must be on their own line)
  const sectionHeaders = [
    'EXECUTIVE SUMMARY',
    'TRAVEL HOTSPOTS TO AVOID',
    'TRAVEL HOT SPOTS TO AVOID',
    'REGIONAL ANALYSIS',
    'GLOBAL OUTLOOK'
  ];
  
  for (const header of sectionHeaders) {
    const headerRegex = new RegExp(`^${header}$`, 'gm');
    html = html.replace(headerRegex, `<h2 style="color: #d4653e; margin-top: 32px; margin-bottom: 16px; font-size: 22px; font-weight: bold; border-bottom: 2px solid #d4653e; padding-bottom: 8px;">${header}</h2>`);
  }
  
  // Add line breaks
  html = html.replace(/\n\n/g, '</p><p>');
  html = html.replace(/\n/g, '<br>');
  
  // Convert bullet points
  html = html.replace(/• /g, '<li>');
  html = html.replace(/<li>/g, '<li style="margin-bottom: 8px;">');
  
  // Wrap in paragraphs
  html = `<p>${html}</p>`;
  
  // Fix lists
  html = html.replace(/(<li[^>]*>.*?)<\/p>/g, '$1</li>');
  html = html.replace(/(<li[\s\S]*?<\/li>)/g, '<ul style="margin: 12px 0; padding-left: 24px;">$1</ul>');
  
  return `
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Observius Daily Security Briefing</title>
</head>
<body style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif; line-height: 1.6; color: #333; max-width: 900px; margin: 0 auto; padding: 20px; background-color: #f5f5f5;">
  <div style="background-color: #ffffff; padding: 40px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
    <div style="text-align: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 3px solid #d4653e;">
      <h1 style="color: #1a1a1a; margin: 0; font-size: 32px;">Observius</h1>
      <p style="color: #d4653e; margin: 8px 0 0 0; font-size: 16px; font-weight: 600;">Daily Security Briefing</p>
      <p style="color: #666; margin: 4px 0 0 0; font-size: 12px;">${new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>
    </div>
    <div style="font-size: 15px; line-height: 1.8;">
      ${html}
    </div>
    <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #e0e0e0; text-align: center; color: #666; font-size: 12px;">
      <p>© ${new Date().getFullYear()} Observius. All rights reserved.</p>
      <p style="margin-top: 8px;">
        <a href="https://observius.com" style="color: #d4653e; text-decoration: none;">Visit Observius</a> •
        <a href="{{unsubscribeUrl}}" style="color: #666; text-decoration: none;">Unsubscribe</a>
      </p>
    </div>
  </div>
</body>
</html>`;
}

export { NewsletterContent };
