import cron, { type ScheduledTask } from "node-cron";
import { storage } from "../storage";
import { generateDailyNewsletter } from "./newsletter-generator";
import { emailService } from "./email-service";

let scheduledTask: ScheduledTask | null = null;

export async function startNewsletterScheduler() {
  // Initialize email service
  emailService.initialize();

  if (!emailService.isConfigured()) {
    console.log("Newsletter scheduler disabled: Email service not configured");
    return;
  }

  // Check if newsletter is enabled in database
  const isEnabled = await storage.isNewsletterEnabled();
  if (!isEnabled) {
    console.log("Newsletter scheduler disabled: Feature is currently turned off");
    return;
  }

  // Get schedule from environment or default to 6 AM daily
  const schedule = process.env.NEWSLETTER_CRON_SCHEDULE || "0 6 * * *"; // Every day at 6 AM
  
  console.log(`Starting newsletter scheduler: ${schedule}`);
  
  scheduledTask = cron.schedule(schedule, async () => {
    // Double-check if newsletter is still enabled before sending
    const stillEnabled = await storage.isNewsletterEnabled();
    if (!stillEnabled) {
      console.log("Newsletter scheduler triggered but feature is disabled - skipping send");
      return;
    }
    console.log("Newsletter scheduler triggered - Starting daily newsletter send...");
    await sendDailyNewsletter();
  });

  console.log("Newsletter scheduler started successfully");
}

export function stopNewsletterScheduler() {
  if (scheduledTask) {
    scheduledTask.stop();
    scheduledTask = null;
    console.log("Newsletter scheduler stopped");
  }
}

export function restartNewsletterScheduler() {
  stopNewsletterScheduler();
  startNewsletterScheduler();
}

export async function sendDailyNewsletter(): Promise<{ sent: number; failed: number }> {
  try {
    console.log("Generating daily newsletter...");
    
    // Generate newsletter content
    const newsletter = await generateDailyNewsletter();
    
    console.log(`Newsletter generated: ${newsletter.subject}`);
    
    // Get active subscribers
    const subscribers = await storage.getActiveNewsletterSubscribers();
    
    if (subscribers.length === 0) {
      console.log("No active subscribers found. Skipping newsletter send.");
      return { sent: 0, failed: 0 };
    }

    console.log(`Sending newsletter to ${subscribers.length} active subscribers...`);
    
    // Send to all subscribers
    const result = await emailService.sendBulkNewsletter(
      subscribers,
      newsletter.subject,
      newsletter.htmlContent,
      newsletter.textContent
    );

    console.log(`Daily newsletter send complete: ${result.sent} sent, ${result.failed} failed`);
    
    return result;
  } catch (error) {
    console.error("Error sending daily newsletter:", error);
    return { sent: 0, failed: 0 };
  }
}

// Manually trigger newsletter send (for testing or admin use)
export async function triggerManualNewsletterSend(): Promise<{ sent: number; failed: number }> {
  console.log("Manual newsletter send triggered");
  return sendDailyNewsletter();
}

// Send welcome email with latest newsletter to new subscriber
export async function sendWelcomeNewsletter(subscriber: any): Promise<boolean> {
  try {
    console.log(`Sending welcome newsletter to ${subscriber.email}...`);
    
    if (!emailService.isConfigured()) {
      console.log("Email service not configured. Skipping welcome newsletter.");
      return false;
    }
    
    // Generate the latest newsletter
    const newsletter = await generateDailyNewsletter();
    
    // Get schedule from environment or default to 6 AM
    const scheduleHour = parseInt(process.env.NEWSLETTER_CRON_HOUR || "6");
    const schedulePeriod = scheduleHour >= 12 ? "PM" : "AM";
    const displayHour = scheduleHour > 12 ? scheduleHour - 12 : scheduleHour === 0 ? 12 : scheduleHour;
    
    // Create welcome message
    const welcomeSubject = `Welcome to Observius - Your Daily Security Briefing`;
    
    // Inject welcome message into HTML
    const welcomeHtml = newsletter.htmlContent.replace(
      '<div style="font-size: 15px; line-height: 1.7;">',
      `<div style="font-size: 15px; line-height: 1.7;">
        <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin-bottom: 30px; border-left: 4px solid #d4653e;">
          <h2 style="color: #d4653e; margin-top: 0; margin-bottom: 12px; font-size: 20px; font-weight: bold;">Welcome to Observius!</h2>
          <p style="margin: 8px 0; color: #333;">Thank you for subscribing to our daily security briefing.</p>
          <p style="margin: 8px 0; color: #333;"><strong>What to expect:</strong></p>
          <ul style="margin: 8px 0 12px 20px; color: #333;">
            <li style="margin-bottom: 4px;">Executive Summary of global security events</li>
            <li style="margin-bottom: 4px;">Travel Advisory with danger ratings by country</li>
            <li style="margin-bottom: 4px;">Coup Watch for government instability</li>
          </ul>
          <p style="margin: 8px 0; color: #333;"><strong>Next briefing:</strong> 3:00 AM EST daily</p>
        </div>`
    );
    
    // Inject welcome message into text version
    const welcomeText = `WELCOME TO OBSERVIUS

Thank you for subscribing to our daily security briefing.

WHAT TO EXPECT:
• Executive Summary of global security events
• Travel Advisory with danger ratings by country
• Coup Watch for government instability

NEXT BRIEFING: 3:00 AM EST daily

---

${newsletter.textContent}`;
    
    // Send welcome newsletter
    const success = await emailService.sendNewsletterToSubscriber(
      subscriber,
      welcomeSubject,
      welcomeHtml,
      welcomeText
    );
    
    if (success) {
      console.log(`Welcome newsletter sent successfully to ${subscriber.email}`);
    } else {
      console.log(`Failed to send welcome newsletter to ${subscriber.email}`);
    }
    
    return success;
  } catch (error) {
    console.error(`Error sending welcome newsletter to ${subscriber.email}:`, error);
    return false;
  }
}
