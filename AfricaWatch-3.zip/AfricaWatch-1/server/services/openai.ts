import OpenAI from "openai";

// This is using Replit's AI Integrations service, which provides OpenAI-compatible API access without requiring your own OpenAI API key.
// the newest OpenAI model is "gpt-5" which was released August 7, 2025. do not change this unless explicitly requested by the user
const openai = new OpenAI({
  baseURL: process.env.AI_INTEGRATIONS_OPENAI_BASE_URL,
  apiKey: process.env.AI_INTEGRATIONS_OPENAI_API_KEY
});

export interface AnalysisResult {
  isRelevant: boolean;
  severity: "critical" | "high" | "moderate" | "info";
  title: string;
  description: string;
  location: string;
  incidentType?: string;
  violenceDetails?: string;
  policeIntervention?: string;
  aiAnalysis?: string;
}

export async function analyzeNewsContent(
  content: string,
  country: string,
  sourceUrl: string
): Promise<AnalysisResult | null> {
  try {
    // Try gpt-4.1 first - may not have the same safety restrictions as gpt-5
    const completion = await openai.chat.completions.create({
      model: "gpt-4.1",
      messages: [
        {
          role: "system",
          content: `You are a security monitoring AI. Your ONLY job is to check if content contains security-related keywords, then extract information.

STEP 1 - Check for these keywords (case-insensitive):
genocide, massacre, killing, killed, attack, violence, violent, extremist, terrorist, terrorism, militant, insurgent, protest, demonstration, riot, conflict, clash, combat, war, military operation, persecution, ethnic cleansing, armed group, rebellion, coup, sanctions (if related to violence/security), ceasefire, casualties, deaths, injured, shoot, shooting, bomb, bombing, explosive

STEP 2 - If ANY keyword is found → isRelevant = TRUE
If NO keywords found → {"isRelevant": false}

STEP 3 - If relevant, assign severity:
- critical: Active violence, deaths, attacks, armed conflict, massacres, genocide
- high: Protests, riots, militant activity, threats of violence, persecution claims
- moderate: Political tensions, security warnings, sanctions
- info: Security updates, advisories

STEP 4 - Extract: title, description, location, severity, violenceDetails, policeIntervention, aiAnalysis

STEP 5 - For aiAnalysis field, provide historical context (MAXIMUM 200 words):

Write 2-3 concise paragraphs explaining WHY this event happened. Include:

1. HISTORICAL BACKGROUND (60-80 words):
   - Key historical events and grievances (with specific dates when relevant)
   - Colonial legacy or post-independence developments
   - Ethnic, religious, or political divisions

2. CURRENT POLITICAL LANDSCAPE (60-80 words):
   - Name current leaders and major political actors
   - Recent events (past 1-2 years) that led to this incident
   - Government vs opposition dynamics
   - Economic or social pressures

3. ROOT CAUSES (40-60 words):
   - Immediate triggers and underlying structural factors
   - Why this location and timing
   - Regional or international involvement if relevant

MAXIMUM 200 WORDS TOTAL. Be specific with names, dates, and facts. Keep it concise but informative.

Respond ONLY with valid JSON. Be INCLUSIVE - if security keywords appear, mark as relevant even if it's a report/analysis/claim rather than a direct incident.`
        },
        {
          role: "user",
          content: `Analyze this news content related to ${country}. 

IMPORTANT: This article IS relevant if it discusses, reports on, analyzes, or mentions violence, conflicts, extremism, persecution, protests, or instability in ${country}, even if:
- It's a political analysis or opinion piece
- It's about international reactions to violence
- It's reporting on claims or allegations of violence
- It's discussing sanctions or interventions related to violence

Source: ${sourceUrl}

Content:
${content.substring(0, 3000)}`
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 1500, // Sufficient for 200 word historical context
    });

    const result = JSON.parse(completion.choices[0].message.content || "{}");
    
    // Debug logging
    if (!result.isRelevant) {
      console.log(`[AI DEBUG] Rejected content. AI response:`, JSON.stringify(result).substring(0, 200));
      console.log(`[AI DEBUG] Content preview:`, content.substring(0, 200));
      return null;
    }

    return result as AnalysisResult;
  } catch (error) {
    console.error("OpenAI analysis error:", error);
    return null;
  }
}

export interface OnDemandAnalysisResult {
  analysis: string;
}

export async function generateAlertAnalysis(
  title: string,
  description: string,
  country: string,
  location: string,
  severity: string
): Promise<OnDemandAnalysisResult | null> {
  try {
    const completion = await openai.chat.completions.create({
      model: "gpt-4.1",
      messages: [
        {
          role: "system",
          content: `You are a geopolitical analyst providing historical context for security incidents. 

Write 2-3 concise paragraphs (MAXIMUM 200 words total) explaining WHY this event happened. Include:

1. HISTORICAL BACKGROUND (60-80 words):
   - Key historical events and grievances (with specific dates when relevant)
   - Colonial legacy or post-independence developments
   - Ethnic, religious, or political divisions

2. CURRENT POLITICAL LANDSCAPE (60-80 words):
   - Name current leaders and major political actors
   - Recent events (past 1-2 years) that led to this incident
   - Government vs opposition dynamics
   - Economic or social pressures

3. ROOT CAUSES (40-60 words):
   - Immediate triggers and underlying structural factors
   - Why this location and timing
   - Regional or international involvement if relevant

Be specific with names, dates, and facts. Keep it concise but informative.
Respond ONLY with valid JSON in this format: {"analysis": "your analysis text here"}`
        },
        {
          role: "user",
          content: `Provide historical context and analysis for this security alert:

Country: ${country}
Location: ${location}
Severity: ${severity}
Title: ${title}
Description: ${description}`
        }
      ],
      response_format: { type: "json_object" },
      max_completion_tokens: 600,
    });

    const result = JSON.parse(completion.choices[0].message.content || "{}");
    return result as OnDemandAnalysisResult;
  } catch (error) {
    console.error("OpenAI on-demand analysis error:", error);
    return null;
  }
}
