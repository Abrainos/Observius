import axios from "axios";
import { containsSecurityKeyword } from "./social-media-keywords";

// African country subreddits and security-focused communities
const AFRICAN_SUBREDDITS = [
  "Africa",
  "africanews", 
  "Nigeria",
  "Kenya",
  "SouthAfrica",
  "Ethiopia",
  "Somalia",
  "Sudan",
  "DRC",
  "Egypt",
  "sahel", // Sahel region security
  "geopolitics", // Often covers African conflicts
  "worldnews", // Often has African security news
];

// Asian country subreddits and security-focused communities
const ASIAN_SUBREDDITS = [
  "Asia",
  "Afghanistan",
  "India",
  "Pakistan",
  "China",
  "Myanmar",
  "Syria",
  "Yemen",
  "Israel",
  "Palestine",
  "Iraq",
  "Philippines",
  "Thailand",
  "Indonesia",
  "MiddleEastNews",
  "SouthAsianConflict",
  "geopolitics", // Covers Asian conflicts
  "worldnews", // Often has Asian security news
];

interface RedditPost {
  title: string;
  content: string;
  url: string;
  subreddit: string;
  author: string;
  score: number;
  created: Date;
  permalink: string;
}

export async function scrapeRedditSecurity(): Promise<RedditPost[]> {
  // Check if Reddit scraping is disabled via environment variable
  if (process.env.DISABLE_REDDIT_SCRAPING === 'true') {
    console.log("[Reddit] Reddit scraping disabled via DISABLE_REDDIT_SCRAPING flag");
    return [];
  }

  const posts: RedditPost[] = [];

  // Limit to fewer subreddits to avoid rate limiting
  const prioritySubreddits = AFRICAN_SUBREDDITS.slice(0, 5);

  for (const subreddit of prioritySubreddits) {
    try {
      // Reddit JSON API - no auth required for public posts
      const response = await axios.get(
        `https://www.reddit.com/r/${subreddit}/new.json`,
        {
          headers: {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Accept': 'application/json',
            'Accept-Language': 'en-US,en;q=0.9',
          },
          timeout: 15000,
          params: {
            limit: 15, // Get recent 15 posts
          }
        }
      );

      const data = response.data;
      
      if (data?.data?.children) {
        for (const child of data.data.children) {
          const post = child.data;
          
          // Check if post contains security keywords using multilingual keyword list
          const combinedText = `${post.title || ''} ${post.selftext || ''}`;
          const isSecurityRelated = containsSecurityKeyword(combinedText);

          if (isSecurityRelated && !post.is_video && !post.stickied) {
            posts.push({
              title: post.title,
              content: post.selftext || post.title,
              url: post.url,
              subreddit: post.subreddit,
              author: post.author,
              score: post.score,
              created: new Date(post.created_utc * 1000),
              permalink: `https://reddit.com${post.permalink}`,
            });
          }
        }
      }

      // Rate limiting - Reddit allows 60 requests per minute
      await new Promise(resolve => setTimeout(resolve, 1200));
      
    } catch (error) {
      console.error(`Error scraping r/${subreddit}:`, error instanceof Error ? error.message : 'Unknown error');
    }
  }

  // Sort by score (upvotes) and recency
  return posts
    .sort((a, b) => {
      const scoreWeight = (b.score - a.score) * 0.3;
      const timeWeight = (b.created.getTime() - a.created.getTime()) * 0.7;
      return scoreWeight + timeWeight;
    })
    .slice(0, 15); // Return top 15 most relevant posts
}
