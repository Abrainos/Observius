import Parser from "rss-parser";

interface RSSFeedConfig {
  name: string;
  url: string;
  countries: string[];
  region?: "africa" | "asia" | "europe" | "middleeast" | "southamerica" | "northamerica" | "centralsouthasia"; // Specify which region this feed covers
  language?: string;
}

// Comprehensive RSS feed configuration covering all major African regions
export const AFRICA_RSS_FEEDS: RSSFeedConfig[] = [
  // Pan-African Sources (cover all countries)
  {
    name: "BBC Africa",
    url: "http://feeds.bbci.co.uk/news/world/africa/rss.xml",
    countries: ["all"],
    region: "africa",
  },
  {
    name: "AllAfrica",
    url: "https://allafrica.com/tools/headlines/rdf/latest/headlines.rdf",
    countries: ["all"],
    region: "africa",
  },
  {
    name: "Africanews",
    url: "https://www.africanews.com/feed/rss",
    countries: ["all"],
    region: "africa",
  },
  
  // Southern Africa
  {
    name: "News24 Africa",
    url: "https://feeds.capi24.com/v1/Search/africa",
    countries: ["South Africa", "Zimbabwe", "Namibia", "Botswana", "Lesotho", "Eswatini"],
  },
  {
    name: "Daily Maverick",
    url: "https://www.dailymaverick.co.za/dmrss",
    countries: ["South Africa"],
  },
  
  // East Africa
  {
    name: "The East African",
    url: "https://www.theeastafrican.co.ke/tea/rss",
    countries: ["Kenya", "Tanzania", "Uganda", "Rwanda", "Burundi", "South Sudan"],
  },
  {
    name: "Nation Africa Kenya",
    url: "https://nation.africa/kenya/rss.xml",
    countries: ["Kenya"],
  },
  {
    name: "Capital FM Kenya",
    url: "https://capitalfm.co.ke/news/feed",
    countries: ["Kenya"],
  },
  {
    name: "AllAfrica Ethiopia",
    url: "https://allafrica.com/tools/headlines/rdf/ethiopia/headlines.rdf",
    countries: ["Ethiopia"],
  },
  
  // West Africa
  {
    name: "Premium Times Nigeria",
    url: "https://www.premiumtimesng.com/feed",
    countries: ["Nigeria"],
  },
  {
    name: "AllAfrica Nigeria",
    url: "https://allafrica.com/tools/headlines/rdf/nigeria/headlines.rdf",
    countries: ["Nigeria"],
  },
  {
    name: "MyJoyOnline Ghana",
    url: "https://www.myjoyonline.com/feed/",
    countries: ["Ghana"],
  },
  {
    name: "AllAfrica Ghana",
    url: "https://allafrica.com/tools/headlines/rdf/ghana/headlines.rdf",
    countries: ["Ghana"],
  },
  
  // North Africa
  {
    name: "Egypt Independent",
    url: "https://egyptindependent.com/feed",
    countries: ["Egypt"],
  },
  {
    name: "AllAfrica Egypt",
    url: "https://allafrica.com/tools/headlines/rdf/egypt/headlines.rdf",
    countries: ["Egypt"],
  },
  {
    name: "AllAfrica Morocco",
    url: "https://allafrica.com/tools/headlines/rdf/morocco/headlines.rdf",
    countries: ["Morocco"],
  },
  {
    name: "AllAfrica Algeria",
    url: "https://allafrica.com/tools/headlines/rdf/algeria/headlines.rdf",
    countries: ["Algeria"],
  },
  {
    name: "AllAfrica Tunisia",
    url: "https://allafrica.com/tools/headlines/rdf/tunisia/headlines.rdf",
    countries: ["Tunisia"],
  },
  {
    name: "AllAfrica Libya",
    url: "https://allafrica.com/tools/headlines/rdf/libya/headlines.rdf",
    countries: ["Libya"],
  },
  
  // Central Africa
  {
    name: "AllAfrica DRC",
    url: "https://allafrica.com/tools/headlines/rdf/drcongo/headlines.rdf",
    countries: ["Democratic Republic of the Congo"],
  },
  {
    name: "AllAfrica Cameroon",
    url: "https://allafrica.com/tools/headlines/rdf/cameroon/headlines.rdf",
    countries: ["Cameroon"],
  },
  {
    name: "AllAfrica Central African Republic",
    url: "https://allafrica.com/tools/headlines/rdf/centralafrican/headlines.rdf",
    countries: ["Central African Republic"],
  },
  
  // Additional Regional Coverage
  {
    name: "AllAfrica Zimbabwe",
    url: "https://allafrica.com/tools/headlines/rdf/zimbabwe/headlines.rdf",
    countries: ["Zimbabwe"],
  },
  {
    name: "AllAfrica Zambia",
    url: "https://allafrica.com/tools/headlines/rdf/zambia/headlines.rdf",
    countries: ["Zambia"],
  },
  {
    name: "AllAfrica Angola",
    url: "https://allafrica.com/tools/headlines/rdf/angola/headlines.rdf",
    countries: ["Angola"],
  },
  {
    name: "AllAfrica Mozambique",
    url: "https://allafrica.com/tools/headlines/rdf/mozambique/headlines.rdf",
    countries: ["Mozambique"],
  },
  {
    name: "AllAfrica Malawi",
    url: "https://allafrica.com/tools/headlines/rdf/malawi/headlines.rdf",
    countries: ["Malawi"],
  },
  {
    name: "AllAfrica Sudan",
    url: "https://allafrica.com/tools/headlines/rdf/sudan/headlines.rdf",
    countries: ["Sudan"],
  },
  {
    name: "AllAfrica Somalia",
    url: "https://allafrica.com/tools/headlines/rdf/somalia/headlines.rdf",
    countries: ["Somalia"],
  },
  {
    name: "AllAfrica Mali",
    url: "https://allafrica.com/tools/headlines/rdf/mali/headlines.rdf",
    countries: ["Mali"],
  },
  {
    name: "AllAfrica Burkina Faso",
    url: "https://allafrica.com/tools/headlines/rdf/burkinafaso/headlines.rdf",
    countries: ["Burkina Faso"],
  },
  {
    name: "AllAfrica Niger",
    url: "https://allafrica.com/tools/headlines/rdf/niger/headlines.rdf",
    countries: ["Niger"],
  },
  {
    name: "AllAfrica Chad",
    url: "https://allafrica.com/tools/headlines/rdf/chad/headlines.rdf",
    countries: ["Chad"],
  },
  {
    name: "AllAfrica Senegal",
    url: "https://allafrica.com/tools/headlines/rdf/senegal/headlines.rdf",
    countries: ["Senegal"],
  },
  {
    name: "AllAfrica Ivory Coast",
    url: "https://allafrica.com/tools/headlines/rdf/ivorycoast/headlines.rdf",
    countries: ["Ivory Coast"],
  },
  
  // Additional countries for complete 54-country coverage
  {
    name: "AllAfrica Benin",
    url: "https://allafrica.com/tools/headlines/rdf/benin/headlines.rdf",
    countries: ["Benin"],
  },
  {
    name: "AllAfrica Cabo Verde",
    url: "https://allafrica.com/tools/headlines/rdf/capeverde/headlines.rdf",
    countries: ["Cabo Verde"],
  },
  {
    name: "AllAfrica Comoros",
    url: "https://allafrica.com/tools/headlines/rdf/comoros/headlines.rdf",
    countries: ["Comoros"],
  },
  {
    name: "AllAfrica Congo",
    url: "https://allafrica.com/tools/headlines/rdf/congo/headlines.rdf",
    countries: ["Congo"],
  },
  {
    name: "AllAfrica Djibouti",
    url: "https://allafrica.com/tools/headlines/rdf/djibouti/headlines.rdf",
    countries: ["Djibouti"],
  },
  {
    name: "AllAfrica Equatorial Guinea",
    url: "https://allafrica.com/tools/headlines/rdf/equatorialguinea/headlines.rdf",
    countries: ["Equatorial Guinea"],
  },
  {
    name: "AllAfrica Eritrea",
    url: "https://allafrica.com/tools/headlines/rdf/eritrea/headlines.rdf",
    countries: ["Eritrea"],
  },
  {
    name: "AllAfrica Gabon",
    url: "https://allafrica.com/tools/headlines/rdf/gabon/headlines.rdf",
    countries: ["Gabon"],
  },
  {
    name: "AllAfrica Gambia",
    url: "https://allafrica.com/tools/headlines/rdf/gambia/headlines.rdf",
    countries: ["Gambia"],
  },
  {
    name: "AllAfrica Guinea",
    url: "https://allafrica.com/tools/headlines/rdf/guinea/headlines.rdf",
    countries: ["Guinea"],
  },
  {
    name: "AllAfrica Guinea-Bissau",
    url: "https://allafrica.com/tools/headlines/rdf/guineabissau/headlines.rdf",
    countries: ["Guinea-Bissau"],
  },
  {
    name: "AllAfrica Lesotho",
    url: "https://allafrica.com/tools/headlines/rdf/lesotho/headlines.rdf",
    countries: ["Lesotho"],
  },
  {
    name: "AllAfrica Liberia",
    url: "https://allafrica.com/tools/headlines/rdf/liberia/headlines.rdf",
    countries: ["Liberia"],
  },
  {
    name: "AllAfrica Madagascar",
    url: "https://allafrica.com/tools/headlines/rdf/madagascar/headlines.rdf",
    countries: ["Madagascar"],
  },
  {
    name: "AllAfrica Mauritania",
    url: "https://allafrica.com/tools/headlines/rdf/mauritania/headlines.rdf",
    countries: ["Mauritania"],
  },
  {
    name: "AllAfrica Mauritius",
    url: "https://allafrica.com/tools/headlines/rdf/mauritius/headlines.rdf",
    countries: ["Mauritius"],
  },
  {
    name: "AllAfrica Namibia",
    url: "https://allafrica.com/tools/headlines/rdf/namibia/headlines.rdf",
    countries: ["Namibia"],
  },
  {
    name: "AllAfrica Rwanda",
    url: "https://allafrica.com/tools/headlines/rdf/rwanda/headlines.rdf",
    countries: ["Rwanda"],
  },
  {
    name: "AllAfrica Sao Tome and Principe",
    url: "https://allafrica.com/tools/headlines/rdf/saotome/headlines.rdf",
    countries: ["Sao Tome and Principe"],
  },
  {
    name: "AllAfrica Seychelles",
    url: "https://allafrica.com/tools/headlines/rdf/seychelles/headlines.rdf",
    countries: ["Seychelles"],
  },
  {
    name: "AllAfrica Sierra Leone",
    url: "https://allafrica.com/tools/headlines/rdf/sierraleone/headlines.rdf",
    countries: ["Sierra Leone"],
  },
  {
    name: "AllAfrica South Sudan",
    url: "https://allafrica.com/tools/headlines/rdf/southsudan/headlines.rdf",
    countries: ["South Sudan"],
  },
  {
    name: "AllAfrica Tanzania",
    url: "https://allafrica.com/tools/headlines/rdf/tanzania/headlines.rdf",
    countries: ["Tanzania"],
  },
  {
    name: "AllAfrica Togo",
    url: "https://allafrica.com/tools/headlines/rdf/togo/headlines.rdf",
    countries: ["Togo"],
  },
  {
    name: "AllAfrica Uganda",
    url: "https://allafrica.com/tools/headlines/rdf/uganda/headlines.rdf",
    countries: ["Uganda"],
  },
  {
    name: "AllAfrica Botswana",
    url: "https://allafrica.com/tools/headlines/rdf/botswana/headlines.rdf",
    countries: ["Botswana"],
  },
  {
    name: "AllAfrica Eswatini",
    url: "https://allafrica.com/tools/headlines/rdf/swaziland/headlines.rdf",
    countries: ["Eswatini"],
  },
  
  // Multilingual Sources - French
  {
    name: "AllAfrica French",
    url: "https://fr.allafrica.com/tools/headlines/rdf/latest/headlines.rdf",
    countries: ["all"],
    language: "fr",
  },
  {
    name: "RFI Afrique",
    url: "https://www.rfi.fr/fr/afrique/rss",
    countries: ["all"],
    language: "fr",
  },
  {
    name: "France 24 Afrique",
    url: "https://www.france24.com/fr/afrique/rss",
    countries: ["all"],
    language: "fr",
  },
  {
    name: "Jeune Afrique",
    url: "https://www.jeuneafrique.com/feed/",
    countries: ["all"],
    language: "fr",
  },
  
  // Multilingual Sources - Arabic
  {
    name: "Al Arabiya Arabic",
    url: "https://www.alarabiya.net/rss.xml",
    countries: ["Egypt", "Libya", "Tunisia", "Algeria", "Morocco", "Sudan"],
    language: "ar",
  },
  {
    name: "Al-Masry Al-Youm",
    url: "https://www.almasryalyoum.com/rss/rssfeed",
    countries: ["Egypt"],
    language: "ar",
  },
  {
    name: "Al Jazeera Arabic",
    url: "https://www.aljazeera.net/xml/rss/all.xml",
    countries: ["all"],
    language: "ar",
  },
  
  // Multilingual Sources - Portuguese
  {
    name: "DW África Portuguese",
    url: "https://rss.dw.com/xml/rss-pt-africa",
    countries: ["Angola", "Mozambique", "Guinea-Bissau", "Cabo Verde", "Sao Tome and Principe"],
    language: "pt",
  },
  {
    name: "VOA Portuguese Africa",
    url: "https://www.voaportugues.com/api/zguoqepugi",
    countries: ["Angola", "Mozambique", "Guinea-Bissau", "Cabo Verde", "Sao Tome and Principe"],
    language: "pt",
  },
];

// Comprehensive RSS feed configuration covering major Asian regions
export const ASIA_RSS_FEEDS: RSSFeedConfig[] = [
  // Pan-Asian Sources
  {
    name: "BBC Asia",
    url: "http://feeds.bbci.co.uk/news/world/asia/rss.xml",
    countries: ["all"],
    region: "asia",
  },
  {
    name: "Al Jazeera Asia",
    url: "https://www.aljazeera.com/xml/rss/asia.xml",
    countries: ["all"],
    region: "asia",
  },
  {
    name: "Asia Times",
    url: "https://asiatimes.com/feed/",
    countries: ["all"],
    region: "asia",
  },
  
  // East Asia
  {
    name: "The Japan Times",
    url: "https://www.japantimes.co.jp/feed/",
    countries: ["Japan"],
    region: "asia",
  },
  {
    name: "The Korea Herald",
    url: "http://www.koreaherald.com/rss/020702000000.xml",
    countries: ["South Korea"],
    region: "asia",
  },
  {
    name: "China Daily",
    url: "https://www.chinadaily.com.cn/rss/world.xml",
    countries: ["China"],
    region: "asia",
  },
  {
    name: "Taiwan News",
    url: "https://www.taiwannews.com.tw/en/RSS",
    countries: ["Taiwan"],
    region: "asia",
  },
  
  // South Asia
  {
    name: "The Hindu India",
    url: "https://www.thehindu.com/news/national/feeder/default.rss",
    countries: ["India"],
    region: "asia",
  },
  {
    name: "Times of India",
    url: "https://timesofindia.indiatimes.com/rssfeedstopstories.cms",
    countries: ["India"],
    region: "asia",
  },
  {
    name: "Dawn Pakistan",
    url: "https://www.dawn.com/feeds/home",
    countries: ["Pakistan"],
    region: "asia",
  },
  {
    name: "Daily Star Bangladesh",
    url: "https://www.thedailystar.net/frontpage/rss.xml",
    countries: ["Bangladesh"],
    region: "asia",
  },
  {
    name: "Daily Mirror Sri Lanka",
    url: "http://www.dailymirror.lk/RSS_Feeds/breaking-news",
    countries: ["Sri Lanka"],
    region: "asia",
  },
  
  // Southeast Asia
  {
    name: "The Straits Times Singapore",
    url: "https://www.straitstimes.com/news/asia/rss.xml",
    countries: ["Singapore", "Malaysia", "Indonesia", "Thailand", "Vietnam", "Philippines"],
    region: "asia",
  },
  {
    name: "Bangkok Post",
    url: "https://www.bangkokpost.com/rss/data/news.xml",
    countries: ["Thailand"],
    region: "asia",
  },
  {
    name: "The Jakarta Post",
    url: "https://www.thejakartapost.com/rss",
    countries: ["Indonesia"],
    region: "asia",
  },
  {
    name: "Vietnam News",
    url: "https://vietnamnews.vn/rss/home.rss",
    countries: ["Vietnam"],
    region: "asia",
  },
  {
    name: "Philippine Daily Inquirer",
    url: "https://newsinfo.inquirer.net/feed",
    countries: ["Philippines"],
    region: "asia",
  },
  {
    name: "The Star Malaysia",
    url: "https://www.thestar.com.my/rss/news/nation/",
    countries: ["Malaysia"],
    region: "asia",
  },
  
  // Middle East
  {
    name: "The National UAE",
    url: "https://www.thenationalnews.com/rss",
    countries: ["United Arab Emirates", "Saudi Arabia", "Kuwait", "Qatar", "Bahrain", "Oman"],
    region: "asia",
  },
  {
    name: "Arab News",
    url: "https://www.arabnews.com/rss.xml",
    countries: ["Saudi Arabia", "United Arab Emirates", "Kuwait", "Qatar", "Bahrain", "Oman"],
    region: "asia",
  },
  {
    name: "The Times of Israel",
    url: "https://www.timesofisrael.com/feed/",
    countries: ["Israel", "Palestine"],
    region: "asia",
  },
  {
    name: "Haaretz",
    url: "https://www.haaretz.com/misc/tags/TAG-middle-east-1.5599265?lts=1598277532384",
    countries: ["Israel", "Palestine"],
    region: "asia",
  },
  {
    name: "The Jordan Times",
    url: "https://jordantimes.com/rss.xml",
    countries: ["Jordan"],
    region: "asia",
  },
  {
    name: "Lebanon Daily Star",
    url: "https://www.dailystar.com.lb/RSS",
    countries: ["Lebanon"],
    region: "asia",
  },
];

// Comprehensive RSS feed configuration covering major European regions
export const EUROPE_RSS_FEEDS: RSSFeedConfig[] = [
  // Pan-European Sources
  {
    name: "BBC Europe",
    url: "http://feeds.bbci.co.uk/news/world/europe/rss.xml",
    countries: ["all"],
    region: "europe",
  },
  {
    name: "Euronews",
    url: "https://www.euronews.com/rss",
    countries: ["all"],
    region: "europe",
  },
  {
    name: "Politico Europe",
    url: "https://www.politico.eu/feed/",
    countries: ["all"],
    region: "europe",
  },
  
  // Western Europe
  {
    name: "The Guardian UK",
    url: "https://www.theguardian.com/uk/rss",
    countries: ["United Kingdom"],
    region: "europe",
  },
  {
    name: "Le Monde France",
    url: "https://www.lemonde.fr/rss/une.xml",
    countries: ["France"],
    region: "europe",
    language: "fr",
  },
  {
    name: "Der Spiegel Germany",
    url: "https://www.spiegel.de/schlagzeilen/index.rss",
    countries: ["Germany"],
    region: "europe",
    language: "de",
  },
  {
    name: "El País Spain",
    url: "https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/portada",
    countries: ["Spain"],
    region: "europe",
    language: "es",
  },
  {
    name: "Corriere della Sera Italy",
    url: "https://www.corriere.it/rss/homepage.xml",
    countries: ["Italy"],
    region: "europe",
    language: "it",
  },
  {
    name: "NOS Netherlands",
    url: "https://feeds.nos.nl/nosnieuwsalgemeen",
    countries: ["Netherlands"],
    region: "europe",
    language: "nl",
  },
  {
    name: "De Standaard Belgium",
    url: "https://www.standaard.be/rss/section/1f2838d4-99ea-49f0-9102-138784c7ea7c",
    countries: ["Belgium"],
    region: "europe",
    language: "nl",
  },
  
  // Northern Europe
  {
    name: "The Local Sweden",
    url: "https://feeds.thelocal.com/rss/se",
    countries: ["Sweden"],
    region: "europe",
  },
  {
    name: "The Local Norway",
    url: "https://feeds.thelocal.com/rss/no",
    countries: ["Norway"],
    region: "europe",
  },
  {
    name: "The Local Denmark",
    url: "https://feeds.thelocal.com/rss/dk",
    countries: ["Denmark"],
    region: "europe",
  },
  {
    name: "Yle Finland",
    url: "https://feeds.yle.fi/uutiset/v1/majorHeadlines/YLE_UUTISET.rss",
    countries: ["Finland"],
    region: "europe",
    language: "fi",
  },
  
  // Eastern Europe
  {
    name: "Kyiv Post Ukraine",
    url: "https://www.kyivpost.com/feed",
    countries: ["Ukraine"],
    region: "europe",
  },
  {
    name: "The Moscow Times Russia",
    url: "https://www.themoscowtimes.com/rss/news",
    countries: ["Russia"],
    region: "europe",
  },
  {
    name: "Notes from Poland",
    url: "https://notesfrompoland.com/feed/",
    countries: ["Poland"],
    region: "europe",
  },
  {
    name: "Prague Morning Czech",
    url: "https://praguemorning.cz/feed/",
    countries: ["Czech Republic"],
    region: "europe",
  },
  {
    name: "Budapest Business Journal Hungary",
    url: "https://bbj.hu/feed",
    countries: ["Hungary"],
    region: "europe",
  },
  
  // Southern Europe
  {
    name: "Kathimerini Greece",
    url: "https://www.ekathimerini.com/rss",
    countries: ["Greece"],
    region: "europe",
  },
  {
    name: "Balkan Insight",
    url: "https://balkaninsight.com/feed/",
    countries: ["Albania", "Bosnia and Herzegovina", "Kosovo", "Montenegro", "North Macedonia", "Serbia"],
    region: "europe",
  },
  {
    name: "Romania Insider",
    url: "https://www.romania-insider.com/feed",
    countries: ["Romania"],
    region: "europe",
  },
  {
    name: "Sofia Globe Bulgaria",
    url: "https://sofiaglobe.com/feed/",
    countries: ["Bulgaria"],
    region: "europe",
  },
];

// Comprehensive RSS feed configuration covering Middle Eastern regions
export const MIDDLEEAST_RSS_FEEDS: RSSFeedConfig[] = [
  // Pan-Middle East Sources
  {
    name: "BBC Middle East",
    url: "http://feeds.bbci.co.uk/news/world/middle_east/rss.xml",
    countries: ["all"],
    region: "middleeast",
  },
  {
    name: "Al Jazeera Middle East",
    url: "https://www.aljazeera.com/xml/rss/middle-east.xml",
    countries: ["all"],
    region: "middleeast",
  },
  {
    name: "Middle East Eye",
    url: "https://www.middleeasteye.net/rss",
    countries: ["all"],
    region: "middleeast",
  },
  {
    name: "Al-Monitor Middle East",
    url: "https://www.al-monitor.com/feed",
    countries: ["all"],
    region: "middleeast",
  },
  
  // Gulf States
  {
    name: "The National UAE",
    url: "https://www.thenationalnews.com/rss",
    countries: ["United Arab Emirates"],
    region: "middleeast",
  },
  {
    name: "Arab News Saudi",
    url: "https://www.arabnews.com/rss.xml",
    countries: ["Saudi Arabia"],
    region: "middleeast",
  },
  {
    name: "Gulf News UAE",
    url: "https://gulfnews.com/rss",
    countries: ["United Arab Emirates"],
    region: "middleeast",
  },
  {
    name: "The Peninsula Qatar",
    url: "https://thepeninsulaqatar.com/rss",
    countries: ["Qatar"],
    region: "middleeast",
  },
  {
    name: "Kuwait Times",
    url: "https://www.kuwaittimes.com/feed/",
    countries: ["Kuwait"],
    region: "middleeast",
  },
  {
    name: "Times of Oman",
    url: "https://timesofoman.com/rss",
    countries: ["Oman"],
    region: "middleeast",
  },
  {
    name: "Bahrain News Agency",
    url: "https://www.bna.bh/en/rss.aspx",
    countries: ["Bahrain"],
    region: "middleeast",
  },
  
  // Levant
  {
    name: "The Times of Israel",
    url: "https://www.timesofisrael.com/feed/",
    countries: ["Israel"],
    region: "middleeast",
  },
  {
    name: "Haaretz Israel",
    url: "https://www.haaretz.com/misc/tags/TAG-middle-east-1.5599265?lts=1598277532384",
    countries: ["Israel"],
    region: "middleeast",
  },
  {
    name: "The Jordan Times",
    url: "https://jordantimes.com/rss.xml",
    countries: ["Jordan"],
    region: "middleeast",
  },
  {
    name: "Lebanon Daily Star",
    url: "https://www.dailystar.com.lb/RSS",
    countries: ["Lebanon"],
    region: "middleeast",
  },
  {
    name: "Naharnet Lebanon",
    url: "http://www.naharnet.com/rss/Lebanese",
    countries: ["Lebanon"],
    region: "middleeast",
  },
  {
    name: "Syrian Observer",
    url: "https://syrianobserver.com/feed",
    countries: ["Syria"],
    region: "middleeast",
  },
  
  // Other Middle East
  {
    name: "Iraq News",
    url: "https://www.iraqinews.com/feed/",
    countries: ["Iraq"],
    region: "middleeast",
  },
  {
    name: "Tehran Times Iran",
    url: "https://www.tehrantimes.com/rss/home",
    countries: ["Iran"],
    region: "middleeast",
  },
  {
    name: "Yemen Times",
    url: "https://www.yementimes.com/feed/",
    countries: ["Yemen"],
    region: "middleeast",
  },
  {
    name: "Palestine Chronicle",
    url: "https://www.palestinechronicle.com/feed/",
    countries: ["Palestine"],
    region: "middleeast",
  },
  {
    name: "Rudaw Kurdistan",
    url: "https://www.rudaw.net/rss/en",
    countries: ["Iraq"],
    region: "middleeast",
  },
  
  // North Africa/Middle East crossover (Egypt moved to Middle East perspective)
  {
    name: "Egypt Independent",
    url: "https://egyptindependent.com/feed/",
    countries: ["Egypt"],
    region: "middleeast",
  },
  {
    name: "Ahram Online Egypt",
    url: "http://english.ahram.org.eg/UI/Front/Inner.aspx?RSSFeed=yes",
    countries: ["Egypt"],
    region: "middleeast",
  },
  
  // Turkey (Eurasia crossover - classified as Middle East)
  {
    name: "Daily Sabah Turkey",
    url: "https://www.dailysabah.com/rssFeed/homepage",
    countries: ["Turkey"],
    region: "middleeast",
  },
  {
    name: "Hurriyet Daily News Turkey",
    url: "https://www.hurriyetdailynews.com/rss",
    countries: ["Turkey"],
    region: "middleeast",
  },
  
  // Afghanistan (Central/South Asia crossover - classified as Middle East)
  {
    name: "Tolonews Afghanistan",
    url: "https://tolonews.com/rss",
    countries: ["Afghanistan"],
    region: "middleeast",
  },
  {
    name: "Khaama Press Afghanistan",
    url: "https://www.khaama.com/feed/",
    countries: ["Afghanistan"],
    region: "middleeast",
  },
];

// Combined RSS feeds for all regions
export const SOUTHAMERICA_RSS_FEEDS: RSSFeedConfig[] = [
  // Pan-South American Sources
  {
    name: "MercoPress",
    url: "https://en.mercopress.com/rss/headlines",
    countries: ["all"],
    region: "southamerica",
  },
  
  // Brazil
  {
    name: "Folha de S.Paulo",
    url: "https://www1.folha.uol.com.br/rss/emcimadahora.xml",
    countries: ["Brazil"],
    region: "southamerica",
    language: "pt",
  },
  {
    name: "The Brazilian Report",
    url: "https://brazilian.report/feed/",
    countries: ["Brazil"],
    region: "southamerica",
  },
  
  // Colombia
  {
    name: "Colombia Reports",
    url: "https://colombiareports.com/feed/",
    countries: ["Colombia"],
    region: "southamerica",
  },
  {
    name: "El Tiempo Colombia",
    url: "https://www.eltiempo.com/rss.xml",
    countries: ["Colombia"],
    region: "southamerica",
    language: "es",
  },
  
  // Argentina
  {
    name: "Buenos Aires Herald",
    url: "https://buenosairesherald.com/feed",
    countries: ["Argentina"],
    region: "southamerica",
  },
  {
    name: "Clarín Argentina",
    url: "https://www.clarin.com/rss/lo-ultimo/",
    countries: ["Argentina"],
    region: "southamerica",
    language: "es",
  },
  
  // Venezuela
  {
    name: "Caracas Chronicles",
    url: "https://www.caracaschronicles.com/feed/",
    countries: ["Venezuela"],
    region: "southamerica",
  },
  {
    name: "El Nacional Venezuela",
    url: "https://www.el-nacional.com/feed/",
    countries: ["Venezuela"],
    region: "southamerica",
    language: "es",
  },
  
  // Chile
  {
    name: "Santiago Times",
    url: "https://santiagotimes.cl/feed/",
    countries: ["Chile"],
    region: "southamerica",
  },
  {
    name: "La Tercera Chile",
    url: "https://www.latercera.com/arc/outboundfeeds/rss/",
    countries: ["Chile"],
    region: "southamerica",
    language: "es",
  },
  
  // Peru
  {
    name: "Peru Reports",
    url: "https://perureports.com/feed/",
    countries: ["Peru"],
    region: "southamerica",
  },
  {
    name: "El Comercio Peru",
    url: "https://elcomercio.pe/feed/",
    countries: ["Peru"],
    region: "southamerica",
    language: "es",
  },
  
  // Ecuador
  {
    name: "El Universo Ecuador",
    url: "https://www.eluniverso.com/rss/",
    countries: ["Ecuador"],
    region: "southamerica",
    language: "es",
  },
  
  // Bolivia
  {
    name: "Bolivia Weekly",
    url: "https://boliviaweekly.com/feed/",
    countries: ["Bolivia"],
    region: "southamerica",
  },
  
  // Uruguay
  {
    name: "El País Uruguay",
    url: "https://www.elpais.com.uy/rss/",
    countries: ["Uruguay"],
    region: "southamerica",
    language: "es",
  },
  
  // Paraguay
  {
    name: "ABC Color Paraguay",
    url: "https://www.abc.com.py/rss/",
    countries: ["Paraguay"],
    region: "southamerica",
    language: "es",
  },
  
  // Guyana
  {
    name: "Stabroek News Guyana",
    url: "https://www.stabroeknews.com/feed/",
    countries: ["Guyana"],
    region: "southamerica",
  },
  
  // Suriname
  {
    name: "Suriname News",
    url: "https://suriname-news.com/feed/",
    countries: ["Suriname"],
    region: "southamerica",
  },
  
  // French Guiana (French language)
  {
    name: "Guyane 1ère",
    url: "https://la1ere.francetvinfo.fr/guyane/rss.xml",
    countries: ["French Guiana"],
    region: "southamerica",
    language: "fr",
  },
];

export const NORTHAMERICA_RSS_FEEDS: RSSFeedConfig[] = [
  // Pan-North American Sources
  {
    name: "Reuters North America",
    url: "https://www.reutersagency.com/feed/?taxonomy=best-topics&post_type=best",
    countries: ["all"],
    region: "northamerica",
  },
  
  // United States
  {
    name: "CNN US",
    url: "http://rss.cnn.com/rss/cnn_us.rss",
    countries: ["United States"],
    region: "northamerica",
  },
  {
    name: "NPR News",
    url: "https://feeds.npr.org/1001/rss.xml",
    countries: ["United States"],
    region: "northamerica",
  },
  {
    name: "The New York Times",
    url: "https://rss.nytimes.com/services/xml/rss/nyt/HomePage.xml",
    countries: ["United States"],
    region: "northamerica",
  },
  
  // Canada
  {
    name: "CBC News",
    url: "https://www.cbc.ca/cmlink/rss-topstories",
    countries: ["Canada"],
    region: "northamerica",
  },
  {
    name: "The Globe and Mail",
    url: "https://www.theglobeandmail.com/arc/outboundfeeds/rss/category/canada/",
    countries: ["Canada"],
    region: "northamerica",
  },
  {
    name: "CTV News",
    url: "https://www.ctvnews.ca/rss/ctvnews-ca-top-stories-public-rss-1.822009",
    countries: ["Canada"],
    region: "northamerica",
  },
  
  // Mexico
  {
    name: "Mexico News Daily",
    url: "https://mexiconewsdaily.com/feed/",
    countries: ["Mexico"],
    region: "northamerica",
  },
  {
    name: "El Universal Mexico",
    url: "https://www.eluniversal.com.mx/rss.xml",
    countries: ["Mexico"],
    region: "northamerica",
    language: "es",
  },
  {
    name: "Reforma Mexico",
    url: "https://www.reforma.com/rss/portada.xml",
    countries: ["Mexico"],
    region: "northamerica",
    language: "es",
  },
  
  // Central America
  {
    name: "The Tico Times Costa Rica",
    url: "https://ticotimes.net/feed",
    countries: ["Costa Rica"],
    region: "northamerica",
  },
  {
    name: "La Prensa Libre Guatemala",
    url: "https://www.prensalibre.com/feed/",
    countries: ["Guatemala"],
    region: "northamerica",
    language: "es",
  },
  {
    name: "La Prensa Honduras",
    url: "https://www.laprensa.hn/feed/",
    countries: ["Honduras"],
    region: "northamerica",
    language: "es",
  },
  {
    name: "El Salvador Times",
    url: "https://elsalvadortimes.com/feed/",
    countries: ["El Salvador"],
    region: "northamerica",
  },
  {
    name: "La Prensa Nicaragua",
    url: "https://www.laprensa.com.ni/feed/",
    countries: ["Nicaragua"],
    region: "northamerica",
    language: "es",
  },
  {
    name: "Panama Today",
    url: "https://panamatoday.com/feed/",
    countries: ["Panama"],
    region: "northamerica",
  },
  {
    name: "Belize News",
    url: "https://www.belizenews.com/feed/",
    countries: ["Belize"],
    region: "northamerica",
  },
  
  // Caribbean
  {
    name: "Jamaica Observer",
    url: "https://www.jamaicaobserver.com/feed/",
    countries: ["Jamaica"],
    region: "northamerica",
  },
  {
    name: "Jamaica Gleaner",
    url: "https://jamaica-gleaner.com/feed",
    countries: ["Jamaica"],
    region: "northamerica",
  },
  {
    name: "Trinidad Express",
    url: "https://trinidadexpress.com/feed/",
    countries: ["Trinidad and Tobago"],
    region: "northamerica",
  },
  {
    name: "Barbados Today",
    url: "https://barbadostoday.bb/feed/",
    countries: ["Barbados"],
    region: "northamerica",
  },
  {
    name: "The Bahamas Weekly",
    url: "https://www.thebahamasweekly.com/rss.xml",
    countries: ["Bahamas"],
    region: "northamerica",
  },
  {
    name: "Diario Libre Dominican Republic",
    url: "https://www.diariolibre.com/rss/",
    countries: ["Dominican Republic"],
    region: "northamerica",
    language: "es",
  },
  {
    name: "Haiti Libre",
    url: "https://www.haitilibre.com/rssfeed.php",
    countries: ["Haiti"],
    region: "northamerica",
    language: "fr",
  },
  {
    name: "Cuba Standard",
    url: "https://www.cubastandard.com/feed/",
    countries: ["Cuba"],
    region: "northamerica",
  },
  {
    name: "Antigua Observer",
    url: "https://antiguaobserver.com/feed/",
    countries: ["Antigua and Barbuda"],
    region: "northamerica",
  },
  {
    name: "Dominica News Online",
    url: "https://dominicanewsonline.com/feed/",
    countries: ["Dominica"],
    region: "northamerica",
  },
  {
    name: "The St. Kitts Nevis Observer",
    url: "https://www.thestkittsnevisobserver.com/feed/",
    countries: ["Saint Kitts and Nevis"],
    region: "northamerica",
  },
  {
    name: "The Voice St. Lucia",
    url: "https://www.thevoiceslu.com/feed/",
    countries: ["Saint Lucia"],
    region: "northamerica",
  },
  {
    name: "iWitness News St. Vincent",
    url: "https://www.iwnsvg.com/feed/",
    countries: ["Saint Vincent and the Grenadines"],
    region: "northamerica",
  },
  {
    name: "Now Grenada",
    url: "https://www.nowgrenada.com/feed/",
    countries: ["Grenada"],
    region: "northamerica",
  },
];

export const CENTRALSOUTHASIA_RSS_FEEDS: RSSFeedConfig[] = [
  // Afghanistan
  {
    name: "Tolonews Afghanistan",
    url: "https://tolonews.com/rss",
    countries: ["Afghanistan"],
    region: "centralsouthasia",
  },
  {
    name: "Khaama Press Afghanistan",
    url: "https://www.khaama.com/feed/",
    countries: ["Afghanistan"],
    region: "centralsouthasia",
  },
  
  // Pakistan
  {
    name: "Dawn Pakistan",
    url: "https://www.dawn.com/feeds/home",
    countries: ["Pakistan"],
    region: "centralsouthasia",
  },
  {
    name: "The Express Tribune Pakistan",
    url: "https://tribune.com.pk/feed/home",
    countries: ["Pakistan"],
    region: "centralsouthasia",
  },
  {
    name: "Geo News Pakistan",
    url: "https://www.geo.tv/rss/1/1",
    countries: ["Pakistan"],
    region: "centralsouthasia",
  },
  
  // India
  {
    name: "The Times of India",
    url: "https://timesofindia.indiatimes.com/rssfeedstopstories.cms",
    countries: ["India"],
    region: "centralsouthasia",
  },
  {
    name: "The Hindu",
    url: "https://www.thehindu.com/feeder/default.rss",
    countries: ["India"],
    region: "centralsouthasia",
  },
  {
    name: "NDTV News",
    url: "https://feeds.feedburner.com/ndtvnews-top-stories",
    countries: ["India"],
    region: "centralsouthasia",
  },
  {
    name: "Indian Express",
    url: "https://indianexpress.com/feed/",
    countries: ["India"],
    region: "centralsouthasia",
  },
  
  // Bangladesh
  {
    name: "The Daily Star Bangladesh",
    url: "https://www.thedailystar.net/feed",
    countries: ["Bangladesh"],
    region: "centralsouthasia",
  },
  {
    name: "Dhaka Tribune",
    url: "https://www.dhakatribune.com/feed",
    countries: ["Bangladesh"],
    region: "centralsouthasia",
  },
  
  // Sri Lanka
  {
    name: "Daily Mirror Sri Lanka",
    url: "https://www.dailymirror.lk/RSS_Feeds",
    countries: ["Sri Lanka"],
    region: "centralsouthasia",
  },
  {
    name: "The Island Sri Lanka",
    url: "https://island.lk/feed/",
    countries: ["Sri Lanka"],
    region: "centralsouthasia",
  },
  
  // Nepal
  {
    name: "The Kathmandu Post",
    url: "https://kathmandupost.com/rss",
    countries: ["Nepal"],
    region: "centralsouthasia",
  },
  {
    name: "The Himalayan Times",
    url: "https://thehimalayantimes.com/feed",
    countries: ["Nepal"],
    region: "centralsouthasia",
  },
  
  // Kazakhstan
  {
    name: "The Astana Times",
    url: "https://astanatimes.com/feed/",
    countries: ["Kazakhstan"],
    region: "centralsouthasia",
  },
  {
    name: "Kazinform",
    url: "https://www.inform.kz/en/rss",
    countries: ["Kazakhstan"],
    region: "centralsouthasia",
  },
  
  // Uzbekistan
  {
    name: "UzReport",
    url: "https://uzreport.news/feed",
    countries: ["Uzbekistan"],
    region: "centralsouthasia",
  },
  
  // Kyrgyzstan
  {
    name: "24.kg Kyrgyzstan",
    url: "https://24.kg/rss/",
    countries: ["Kyrgyzstan"],
    region: "centralsouthasia",
  },
  
  // Tajikistan
  {
    name: "Asia-Plus Tajikistan",
    url: "https://asiaplustj.info/en/rss",
    countries: ["Tajikistan"],
    region: "centralsouthasia",
  },
  
  // Maldives
  {
    name: "Maldives Independent",
    url: "https://maldivesindependent.com/feed",
    countries: ["Maldives"],
    region: "centralsouthasia",
  },
  
  // Bhutan
  {
    name: "Kuensel Bhutan",
    url: "https://kuenselonline.com/feed/",
    countries: ["Bhutan"],
    region: "centralsouthasia",
  },
];

export const RSS_FEEDS = [...AFRICA_RSS_FEEDS, ...ASIA_RSS_FEEDS, ...EUROPE_RSS_FEEDS, ...MIDDLEEAST_RSS_FEEDS, ...SOUTHAMERICA_RSS_FEEDS, ...NORTHAMERICA_RSS_FEEDS, ...CENTRALSOUTHASIA_RSS_FEEDS];

export interface RSSArticle {
  source: string;
  sourceUrl: string;
  title: string;
  content: string;
  pubDate?: Date;
  countries: string[];
  region: 'africa' | 'asia' | 'europe' | 'middleeast' | 'southamerica' | 'northamerica' | 'centralsouthasia';
  language?: string;
  originalTitle?: string;
  originalContent?: string;
  wasTranslated?: boolean;
}

const parser = new Parser({
  timeout: 15000,
  customFields: {
    item: [
      ['description', 'description'],
      ['content:encoded', 'contentEncoded'],
      ['summary', 'summary'],
    ],
  },
});

function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function classifyRSSError(error: any): { 
  type: 'rate_limit' | 'not_found' | 'forbidden' | 'timeout' | 'connection' | 'server_error' | 'unknown';
  shouldRetry: boolean;
  backoffMs: number;
} {
  const errorMessage = error instanceof Error ? error.message : String(error);
  
  if (errorMessage.includes('Status code 429') || errorMessage.includes('Too Many Requests')) {
    return { type: 'rate_limit', shouldRetry: true, backoffMs: 5000 };
  }
  
  if (errorMessage.includes('Status code 404') || errorMessage.includes('Not Found')) {
    return { type: 'not_found', shouldRetry: false, backoffMs: 0 };
  }
  
  if (errorMessage.includes('Status code 403') || errorMessage.includes('Forbidden')) {
    return { type: 'forbidden', shouldRetry: true, backoffMs: 10000 };
  }
  
  if (errorMessage.includes('ETIMEDOUT') || errorMessage.includes('timeout') || errorMessage.includes('timed out')) {
    return { type: 'timeout', shouldRetry: true, backoffMs: 3000 };
  }
  
  if (errorMessage.includes('ECONNREFUSED') || errorMessage.includes('ENOTFOUND') || errorMessage.includes('ECONNRESET')) {
    return { type: 'connection', shouldRetry: true, backoffMs: 2000 };
  }
  
  if (errorMessage.includes('Status code 5')) {
    return { type: 'server_error', shouldRetry: true, backoffMs: 4000 };
  }
  
  return { type: 'unknown', shouldRetry: true, backoffMs: 2000 };
}

class HostConcurrencyManager {
  private hostQueues: Map<string, number> = new Map();
  private readonly maxPerHost = 2;
  
  async acquire(hostname: string): Promise<void> {
    while ((this.hostQueues.get(hostname) || 0) >= this.maxPerHost) {
      await sleep(100);
    }
    this.hostQueues.set(hostname, (this.hostQueues.get(hostname) || 0) + 1);
  }
  
  release(hostname: string): void {
    const current = this.hostQueues.get(hostname) || 0;
    this.hostQueues.set(hostname, Math.max(0, current - 1));
  }
}

const hostManager = new HostConcurrencyManager();

export async function fetchRSSFeed(
  feedUrl: string, 
  feedName: string, 
  countries: string[], 
  region: 'africa' | 'asia' | 'europe' | 'middleeast' | 'southamerica' | 'northamerica' | 'centralsouthasia' = 'africa',
  language?: string
): Promise<RSSArticle[]> {
  const articles: RSSArticle[] = [];
  const maxRetries = 3;
  let hostname = 'unknown';
  
  try {
    const url = new URL(feedUrl);
    hostname = url.hostname;
  } catch (e) {
    console.error(`[RSS] Invalid URL for ${feedName}: ${feedUrl}`);
    return articles;
  }

  await hostManager.acquire(hostname);
  
  try {
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        const feed = await parser.parseURL(feedUrl);
        
        const items = feed.items.slice(0, 5);
        
        for (const item of items) {
          const title = item.title || 'Untitled';
          const link = item.link || feedUrl;
          
          let content = '';
          if (item.contentEncoded) {
            content = stripHtml(item.contentEncoded);
          } else if (item.content) {
            content = stripHtml(item.content as string);
          } else if (item.description) {
            content = stripHtml(item.description);
          } else if (item.summary) {
            content = stripHtml(item.summary);
          }
          
          if (!content || content.length < 50) {
            content = title;
          }
          
          if (content.length > 2000) {
            content = content.substring(0, 2000);
          }
          
          const pubDate = item.pubDate ? new Date(item.pubDate) : undefined;
          
          articles.push({
            source: feedName,
            sourceUrl: link,
            title,
            content,
            pubDate,
            countries,
            region,
            language: language || 'en',
          });
        }
        
        console.log(`[RSS] ✓ Fetched ${articles.length} articles from ${feedName}`);
        break;
        
      } catch (error) {
        const classification = classifyRSSError(error);
        const errorMsg = error instanceof Error ? error.message : 'Unknown error';
        
        if (!classification.shouldRetry) {
          console.error(`[RSS] ✗ ${feedName}: ${classification.type} (no retry) - ${errorMsg}`);
          break;
        }
        
        if (attempt < maxRetries - 1) {
          const jitter = Math.random() * 1000;
          const backoff = Math.min(classification.backoffMs * Math.pow(2, attempt) + jitter, 60000);
          console.log(`[RSS] ${feedName}: ${classification.type} (retry ${attempt + 1}/${maxRetries}) - waiting ${Math.round(backoff)}ms`);
          await sleep(backoff);
        } else {
          console.error(`[RSS] ✗ ${feedName}: ${classification.type} (failed after ${maxRetries} attempts) - ${errorMsg}`);
        }
      }
    }
  } finally {
    hostManager.release(hostname);
  }

  return articles;
}

export async function fetchAllRSSFeeds(): Promise<RSSArticle[]> {
  const startTime = Date.now();
  console.log(`[RSS] Fetching from ${RSS_FEEDS.length} RSS feeds...`);
  
  const allArticles: RSSArticle[] = [];
  let successCount = 0;
  let failureCount = 0;
  
  const batchSize = 12;
  for (let i = 0; i < RSS_FEEDS.length; i += batchSize) {
    const batch = RSS_FEEDS.slice(i, i + batchSize);
    const batchPromises = batch.map(async (feed) => {
      const result = await fetchRSSFeed(feed.url, feed.name, feed.countries, feed.region || 'africa', feed.language);
      if (result.length > 0) {
        successCount++;
      } else {
        failureCount++;
      }
      return result;
    });
    
    const batchResults = await Promise.all(batchPromises);
    allArticles.push(...batchResults.flat());
  }
  
  const duration = Math.round((Date.now() - startTime) / 1000);
  console.log(`[RSS] Completed in ${duration}s: ${successCount} feeds successful, ${failureCount} feeds failed, ${allArticles.length} total articles`);
  return allArticles;
}

// Helper function to strip HTML tags from content
function stripHtml(html: string): string {
  return html
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/\s+/g, ' ')
    .trim();
}
