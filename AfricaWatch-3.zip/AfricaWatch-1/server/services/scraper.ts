import axios from "axios";
import * as cheerio from "cheerio";

// Curated African news sources covering pan-African and regional outlets
const NEWS_SOURCES = [
  {
    name: "BBC Africa",
    url: "https://www.bbc.com/news/world/africa",
    countries: ["all"],
  },
  {
    name: "AllAfrica",
    url: "https://allafrica.com/latest/",
    countries: ["all"],
  },
  {
    name: "News24 Africa",
    url: "https://www.news24.com/news24/africa",
    countries: ["South Africa", "Zimbabwe", "Namibia", "Botswana"],
  },
  {
    name: "The East African",
    url: "https://www.theeastafrican.co.ke/tea/news",
    countries: ["Kenya", "Tanzania", "Uganda", "Rwanda", "Burundi", "South Sudan"],
  },
  {
    name: "Premium Times Nigeria",
    url: "https://www.premiumtimesng.com/",
    countries: ["Nigeria"],
  },
  {
    name: "Daily Maverick",
    url: "https://www.dailymaverick.co.za/",
    countries: ["South Africa"],
  },
  {
    name: "Egypt Independent",
    url: "https://egyptindependent.com/",
    countries: ["Egypt"],
  },
];

interface ScrapedArticle {
  source: string;
  sourceUrl: string;
  title: string;
  content: string;
  countries: string[];
}

export async function scrapeNewsSource(sourceUrl: string, sourceName: string): Promise<{ title: string; content: string } | null> {
  try {
    const response = await axios.get(sourceUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      },
      timeout: 10000,
    });

    const $ = cheerio.load(response.data);
    
    // Extract title
    const title = $('h1').first().text().trim() || 
                  $('title').first().text().trim() ||
                  'News Update';

    // Extract main content (try multiple selectors)
    let content = '';
    const contentSelectors = [
      'article p',
      '.article-body p',
      '.story-body p',
      '.entry-content p',
      'main p',
      '.content p',
      'p'
    ];

    for (const selector of contentSelectors) {
      const paragraphs = $(selector);
      if (paragraphs.length > 0) {
        content = paragraphs
          .map((_, el) => $(el).text().trim())
          .get()
          .filter(text => text.length > 50)
          .slice(0, 10)
          .join('\n\n');
        
        if (content.length > 200) break;
      }
    }

    if (!content || content.length < 100) {
      // Fallback: get all text
      content = $('body').text().trim().substring(0, 2000);
    }

    return { title, content };
  } catch (error) {
    console.error(`Error scraping ${sourceName}:`, error instanceof Error ? error.message : 'Unknown error');
    return null;
  }
}

export async function scrapeAllSources(): Promise<ScrapedArticle[]> {
  const articles: ScrapedArticle[] = [];

  for (const source of NEWS_SOURCES) {
    try {
      const response = await axios.get(source.url, {
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        },
        timeout: 10000,
      });

      const $ = cheerio.load(response.data);
      
      // Extract article links with better selectors to avoid navigation/header links
      const links: string[] = [];
      
      // Target article headlines - these are more specific than generic navigation
      const articleSelectors = [
        'article h2 a',           // Articles with h2 headlines
        'article h3 a',           // Articles with h3 headlines
        '.article-title a',       // Common article title class
        '.headline a',            // Headline links
        '.story-headline a',      // Story headlines
        'h2 a[href*="/news"]',   // H2 links containing /news
        'h3 a[href*="/news"]',   // H3 links containing /news
        'h2 a[href*="/article"]', // H2 links containing /article
        'h3 a[href*="/article"]', // H3 links containing /article
      ];
      
      for (const selector of articleSelectors) {
        $(selector).each((_, el) => {
          const $link = $(el);
          const href = $link.attr('href');
          const linkText = $link.text().trim();
          
          // Filter out navigation links (too short or generic)
          if (href && 
              linkText.length > 15 && // Real headlines are longer
              !href.includes('#') && 
              !href.includes('javascript:') &&
              !linkText.toLowerCase().includes('newsletter') &&
              !linkText.toLowerCase().match(/^(news|headlines?|stories|more)$/i)) {
            
            const fullUrl = href.startsWith('http') ? href : new URL(href, source.url).href;
            if (!links.includes(fullUrl)) {
              links.push(fullUrl);
            }
          }
        });
        
        if (links.length >= 3) break; // Found enough articles
      }

      // Scrape first 3 articles from each source
      const articleLinks = links.slice(0, 3);
      
      for (const link of articleLinks) {
        const article = await scrapeNewsSource(link, source.name);
        if (article && article.content.length > 100) {
          articles.push({
            source: source.name,
            sourceUrl: link,
            title: article.title,
            content: article.content,
            countries: source.countries,
          });
        }
        
        // Rate limiting
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    } catch (error) {
      console.error(`Error scraping ${source.name}:`, error instanceof Error ? error.message : 'Unknown error');
    }
  }

  return articles;
}
