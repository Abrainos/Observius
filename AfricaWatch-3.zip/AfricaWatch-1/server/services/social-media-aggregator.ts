// Aggregates social media posts by country and creates alerts only when there are 2+ instances
import { africanCountries } from "@shared/schema";
import { countKeywordMatches } from "./social-media-keywords";

interface SocialMediaPost {
  source: string;
  sourceUrl: string;
  title: string;
  content: string;
  author?: string;
}

interface CountryAggregation {
  country: string;
  posts: SocialMediaPost[];
  keywordMatches: number;
}

/**
 * Detects which African country is mentioned in a post
 * Returns null if no African country is clearly mentioned
 */
export function detectAfricanCountry(text: string): string | null {
  const lowerText = text.toLowerCase();
  
  // Check for exact country name matches (case-insensitive)
  for (const country of africanCountries) {
    const countryLower = country.toLowerCase();
    
    // Look for country name as whole word
    const regex = new RegExp(`\\b${countryLower}\\b`, 'i');
    if (regex.test(lowerText)) {
      return country;
    }
    
    // Check for common variations
    const variations: { [key: string]: string[] } = {
      "Ivory Coast": ["côte d'ivoire", "cote d'ivoire", "cote divoire"],
      "Democratic Republic of the Congo": ["drc", "dr congo", "congo-kinshasa"],
      "Republic of the Congo": ["congo-brazzaville", "congo brazzaville"],
      "Cabo Verde": ["cape verde"],
      "Eswatini": ["swaziland"],
      "South Africa": ["rsa", "south african"],
      "Central African Republic": ["car", "centrafrique"],
    };
    
    if (variations[country]) {
      for (const variation of variations[country]) {
        if (lowerText.includes(variation.toLowerCase())) {
          return country;
        }
      }
    }
  }
  
  return null;
}

/**
 * Aggregates social media posts by country
 * Returns only countries with 2 or more posts
 */
export function aggregateByCountry(posts: SocialMediaPost[]): CountryAggregation[] {
  const countryMap = new Map<string, SocialMediaPost[]>();
  
  // Group posts by country
  for (const post of posts) {
    const combinedText = `${post.title} ${post.content}`;
    const country = detectAfricanCountry(combinedText);
    
    if (country) {
      if (!countryMap.has(country)) {
        countryMap.set(country, []);
      }
      countryMap.get(country)!.push(post);
    }
  }
  
  // Filter to only countries with 2+ posts and calculate keyword matches
  const aggregations: CountryAggregation[] = [];
  
  for (const [country, countryPosts] of countryMap.entries()) {
    if (countryPosts.length >= 2) {
      // Count total keyword matches across all posts for this country
      const totalKeywordMatches = countryPosts.reduce((sum, post) => {
        return sum + countKeywordMatches(`${post.title} ${post.content}`);
      }, 0);
      
      aggregations.push({
        country,
        posts: countryPosts,
        keywordMatches: totalKeywordMatches
      });
    }
  }
  
  // Sort by number of posts (descending) and keyword matches
  return aggregations.sort((a, b) => {
    const postDiff = b.posts.length - a.posts.length;
    if (postDiff !== 0) return postDiff;
    return b.keywordMatches - a.keywordMatches;
  });
}

/**
 * Creates a combined alert from multiple social media posts about the same country
 */
export function createCombinedAlert(aggregation: CountryAggregation): {
  title: string;
  description: string;
  sources: string;
} {
  const { country, posts } = aggregation;
  const instanceCount = posts.length;
  
  // Extract common themes from post titles
  const titles = posts.map(p => p.title);
  const keywords = new Set<string>();
  
  // Identify most common security keywords in the posts
  const commonKeywords = ["protest", "coup", "attack", "violence", "unrest", "clash", "riot"];
  for (const keyword of commonKeywords) {
    const titleText = titles.join(" ").toLowerCase();
    if (titleText.includes(keyword)) {
      keywords.add(keyword);
    }
  }
  
  const keywordList = Array.from(keywords).join(", ");
  
  // Create alert title
  const title = `Social Media Alert: Multiple reports of ${keywordList || "security incidents"} in ${country} (${instanceCount} posts)`;
  
  // Create alert description with post summaries
  const postSummaries = posts.map((post, idx) => {
    const snippet = post.content.substring(0, 150);
    return `${idx + 1}. ${post.title}${snippet !== post.content ? '...' : ''}`;
  }).join('\n\n');
  
  const description = `Multiple social media posts (${instanceCount}) have been detected reporting security incidents in ${country}:\n\n${postSummaries}`;
  
  // Combine source URLs
  const sources = posts.map(p => p.sourceUrl).join(', ');
  
  return {
    title,
    description,
    sources
  };
}
