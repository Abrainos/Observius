// Comprehensive keyword list for social media monitoring
// Includes: protest, coup, insurrection, organized protest, attack, civil unrest
// Languages: English, French, Portuguese, Arabic

export const SOCIAL_MEDIA_KEYWORDS = {
  // ENGLISH
  english: [
    // Protest & derivatives
    "protest", "protests", "protesting", "protester", "protesters", "demonstration", 
    "demonstrations", "demonstrator", "demonstrators", "demonstrating", "rally", 
    "rallies", "march", "marches", "marching", "uprising",
    
    // Coup & derivatives
    "coup", "coup d'état", "coup d'etat", "coups", "military takeover", 
    "junta", "putsch", "overthrow",
    
    // Insurrection & derivatives
    "insurrection", "insurrections", "insurgent", "insurgents", "insurgency",
    "rebellion", "rebellions", "rebel", "rebels", "revolt", "revolts",
    
    // Organized protest
    "organized protest", "planned protest", "mass protest", "protest movement",
    
    // Attack & derivatives
    "attack", "attacks", "attacking", "attacked", "attacker", "attackers",
    "assault", "assaults", "assaulting", "assaulted", "raid", "raids",
    "bombing", "explosion", "explosions", "suicide bomber",
    
    // Civil unrest & derivatives
    "civil unrest", "unrest", "riot", "riots", "rioting", "rioter", "rioters",
    "violence", "violent", "clashes", "clash", "militant", "militants",
    "extremist", "extremists", "terrorism", "terrorist", "terrorists"
  ],
  
  // FRENCH
  french: [
    // Protestation (Protest)
    "protestation", "protestations", "protester", "manifestation", 
    "manifestations", "manifester", "manifestant", "manifestants",
    "rassemblement", "marche", "soulèvement",
    
    // Coup d'état
    "coup d'état", "coup", "coups", "putsch", "renversement",
    "junte", "junte militaire", "prise de pouvoir",
    
    // Insurrection
    "insurrection", "insurrections", "insurgé", "insurgés", "insurgence",
    "rébellion", "rébellions", "rebelle", "rebelles", "révolte", "révoltes",
    
    // Protestation organisée
    "protestation organisée", "manifestation organisée", "mouvement de protestation",
    
    // Attaque
    "attaque", "attaques", "attaquer", "attaquant", "attaquants",
    "assaut", "assauts", "raid", "raids", "attentat", "attentats",
    "bombardement", "explosion", "kamikaze",
    
    // Troubles civils
    "troubles civils", "troubles", "émeute", "émeutes", "émeutier", "émeutiers",
    "violence", "violent", "violente", "affrontements", "affrontement",
    "militant", "militants", "extrémiste", "extrémistes", 
    "terrorisme", "terroriste", "terroristes"
  ],
  
  // PORTUGUESE
  portuguese: [
    // Protesto (Protest)
    "protesto", "protestos", "protestar", "manifestação", "manifestações",
    "manifestante", "manifestantes", "manifestar", "comício", "marcha",
    "levante", "revolta popular",
    
    // Golpe
    "golpe", "golpe de estado", "golpes", "putsch", "derrubada",
    "junta", "junta militar", "tomada de poder",
    
    // Insurreição
    "insurreição", "insurreições", "insurgente", "insurgentes", "insurgência",
    "rebelião", "rebeliões", "rebelde", "rebeldes", "revolta", "revoltas",
    
    // Protesto organizado
    "protesto organizado", "manifestação organizada", "movimento de protesto",
    
    // Ataque
    "ataque", "ataques", "atacar", "atacante", "atacantes",
    "assalto", "assaltos", "atentado", "atentados", "raid",
    "bombardeio", "explosão", "explosões", "homem-bomba",
    
    // Agitação civil
    "agitação civil", "agitação", "tumulto", "tumultos", "distúrbio", "distúrbios",
    "violência", "violento", "violenta", "confrontos", "confronto",
    "militante", "militantes", "extremista", "extremistas",
    "terrorismo", "terrorista", "terroristas"
  ],
  
  // ARABIC (transliterated and native)
  arabic: [
    // احتجاج (Protest)
    "احتجاج", "احتجاجات", "تظاهرة", "تظاهرات", "مظاهرة", "مظاهرات",
    "متظاهر", "متظاهرون", "احتشاد", "مسيرة", "انتفاضة",
    
    // انقلاب (Coup)
    "انقلاب", "انقلابات", "انقلاب عسكري", "المجلس العسكري", 
    "استيلاء", "الإطاحة",
    
    // تمرد (Insurrection)
    "تمرد", "تمردات", "متمرد", "متمردون", "عصيان",
    "ثورة", "ثورات", "ثائر", "ثوار",
    
    // احتجاج منظم
    "احتجاج منظم", "تظاهرة منظمة", "حركة احتجاج",
    
    // هجوم (Attack)
    "هجوم", "هجمات", "هاجم", "مهاجم", "مهاجمون",
    "اعتداء", "اعتداءات", "غارة", "غارات", "تفجير",
    "انفجار", "انفجارات", "انتحاري",
    
    // اضطرابات مدنية (Civil unrest)
    "اضطرابات مدنية", "اضطرابات", "شغب", "عنف", "اشتباكات",
    "اشتباك", "مسلح", "مسلحون", "متشدد", "متشددون",
    "إرهاب", "إرهابي", "إرهابيون", "أعمال عنف"
  ]
};

// Combine all keywords for searching
export const ALL_KEYWORDS = [
  ...SOCIAL_MEDIA_KEYWORDS.english,
  ...SOCIAL_MEDIA_KEYWORDS.french,
  ...SOCIAL_MEDIA_KEYWORDS.portuguese,
  ...SOCIAL_MEDIA_KEYWORDS.arabic
];

// Create search query patterns for different platforms
export function buildTwitterQuery(maxKeywords: number = 10): string {
  // Use most common English keywords for Twitter (which supports complex queries)
  const topKeywords = [
    "protest", "coup", "insurrection", "attack", "riot", 
    "violence", "unrest", "militant", "clash", "demonstration"
  ].slice(0, maxKeywords);
  
  return topKeywords.join(" OR ");
}

// Check if text contains any of the keywords (case-insensitive)
export function containsSecurityKeyword(text: string): boolean {
  const lowerText = text.toLowerCase();
  return ALL_KEYWORDS.some(keyword => 
    lowerText.includes(keyword.toLowerCase())
  );
}

// Count how many different keywords appear in text
export function countKeywordMatches(text: string): number {
  const lowerText = text.toLowerCase();
  const matchedKeywords = new Set<string>();
  
  for (const keyword of ALL_KEYWORDS) {
    if (lowerText.includes(keyword.toLowerCase())) {
      matchedKeywords.add(keyword.toLowerCase());
    }
  }
  
  return matchedKeywords.size;
}
