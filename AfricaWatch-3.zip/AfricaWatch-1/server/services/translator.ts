import { translate } from '@vitalets/google-translate-api';
import { franc } from 'franc';

export interface TranslationResult {
  translatedText: string;
  detectedLanguage: string;
  originalText: string;
  wasTranslated: boolean;
}

/**
 * Strip HTML tags, scripts, styles and normalize text for better translation
 */
function normalizeTextForTranslation(text: string): string {
  return text
    .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, ' ')
    .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, ' ')
    .replace(/<[^>]*>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&#x27;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/&ldquo;/g, '"')
    .replace(/&rdquo;/g, '"')
    .replace(/&lsquo;/g, "'")
    .replace(/&rsquo;/g, "'")
    .replace(/&mdash;/g, '—')
    .replace(/&ndash;/g, '–')
    .replace(/&#\d+;/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Detect language using layered approach for better accuracy
 */
function detectLanguage(text: string, feedLanguage?: string): { code: string; confidence: 'high' | 'medium' | 'low' } {
  const normalizedText = normalizeTextForTranslation(text);
  const textLength = normalizedText.length;
  
  if (feedLanguage && feedLanguage !== 'en' && feedLanguage !== 'eng') {
    console.log(`[TRANSLATOR] Using feed-provided language: ${feedLanguage}`);
    return { code: feedLanguage, confidence: 'high' };
  }
  
  if (textLength < 15) {
    const hasArabicChars = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/.test(normalizedText);
    const hasCyrillicChars = /[\u0400-\u04FF]/.test(normalizedText);
    const hasChineseChars = /[\u4E00-\u9FFF]/.test(normalizedText);
    
    if (hasArabicChars) {
      console.log(`[TRANSLATOR] Short text with Arabic characters detected`);
      return { code: 'ar', confidence: 'medium' };
    }
    if (hasCyrillicChars) return { code: 'ru', confidence: 'medium' };
    if (hasChineseChars) return { code: 'zh', confidence: 'medium' };
    
    return { code: 'und', confidence: 'low' };
  }
  
  const detectedLangCode = franc(normalizedText, { minLength: 10 });
  
  if (detectedLangCode === 'eng') {
    return { code: 'en', confidence: 'high' };
  }
  
  if (detectedLangCode === 'und') {
    const hasArabicChars = /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF]/.test(normalizedText);
    if (hasArabicChars) {
      console.log(`[TRANSLATOR] Franc uncertain but Arabic characters detected`);
      return { code: 'ar', confidence: 'low' };
    }
    return { code: 'und', confidence: 'low' };
  }
  
  const langMap: Record<string, string> = {
    'fra': 'fr',
    'arb': 'ar',
    'por': 'pt',
    'swa': 'sw',
    'amh': 'am',
    'som': 'so',
    'hau': 'ha',
    'yor': 'yo',
    'afr': 'af',
    'zul': 'zu',
    'xho': 'xh',
    'rus': 'ru',
    'spa': 'es',
    'urd': 'ur',
    'hin': 'hi',
    'ben': 'bn',
    'tur': 'tr',
    'fas': 'fa',
  };
  
  const mappedCode = langMap[detectedLangCode] || detectedLangCode;
  return { code: mappedCode, confidence: 'high' };
}

/**
 * Sleep for a specified duration in milliseconds
 */
function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Retry a function with exponential backoff
 */
async function retryWithBackoff<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  initialDelay: number = 3000
): Promise<T> {
  let lastError: Error | undefined;
  
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      // Add significant delay between all translation requests to avoid rate limits
      if (attempt > 0) {
        const delay = initialDelay * Math.pow(2, attempt - 1);
        console.log(`[TRANSLATOR] Retry attempt ${attempt} after ${delay}ms delay`);
        await sleep(delay);
      } else {
        // Even on first attempt, add a delay to space out requests
        await sleep(800);
      }
      
      return await fn();
    } catch (error) {
      lastError = error as Error;
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      
      // Check if it's a rate limit error
      if (errorMessage.includes('Too Many Requests') || errorMessage.includes('429')) {
        console.log(`[TRANSLATOR] Rate limit hit, attempt ${attempt + 1}/${maxRetries + 1}`);
        if (attempt < maxRetries) {
          continue; // Retry
        }
      } else {
        // For non-rate-limit errors, fail immediately
        throw error;
      }
    }
  }
  
  // All retries exhausted
  throw lastError || new Error('Translation failed after all retries');
}

/**
 * Translate text to English if it's in another language
 */
export async function translateToEnglish(text: string, feedLanguage?: string): Promise<TranslationResult> {
  const originalText = text;
  
  if (!text || text.trim().length === 0) {
    return {
      translatedText: text,
      detectedLanguage: 'unknown',
      originalText: text,
      wasTranslated: false,
    };
  }

  const normalizedText = normalizeTextForTranslation(text);
  const detection = detectLanguage(normalizedText, feedLanguage);
  
  if (detection.code === 'en') {
    return {
      translatedText: normalizedText,
      detectedLanguage: 'en',
      originalText,
      wasTranslated: false,
    };
  }

  try {
    console.log(`[TRANSLATOR] Detected: ${detection.code} (confidence: ${detection.confidence}) - translating to English (length: ${normalizedText.length})`);

    let result;
    let usedAutoFallback = false;
    
    if (detection.confidence === 'low' || detection.code === 'und') {
      console.log(`[TRANSLATOR] Low confidence detection, using 'auto' source language`);
      usedAutoFallback = true;
      result = await retryWithBackoff(async () => {
        return await translate(normalizedText, { to: 'en', from: 'auto' });
      });
    } else {
      try {
        result = await retryWithBackoff(async () => {
          return await translate(normalizedText, { to: 'en', from: detection.code });
        });
      } catch (languageError) {
        const errorMsg = languageError instanceof Error ? languageError.message : 'Unknown error';
        if (errorMsg.includes('Bad Request') || errorMsg.includes('400')) {
          console.log(`[TRANSLATOR] Language code '${detection.code}' rejected, retrying with 'auto'`);
          usedAutoFallback = true;
          result = await retryWithBackoff(async () => {
            return await translate(normalizedText, { to: 'en', from: 'auto' });
          });
        } else {
          throw languageError;
        }
      }
    }

    console.log(`[TRANSLATOR] ✓ Successfully translated from ${detection.code}${usedAutoFallback ? ' (via auto)' : ''}`);

    return {
      translatedText: result.text,
      detectedLanguage: detection.code,
      originalText,
      wasTranslated: true,
    };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : 'Unknown error';
    console.error(`[TRANSLATOR] ✗ Translation failed:`, {
      detectedLanguage: detection.code,
      confidence: detection.confidence,
      textLength: normalizedText.length,
      firstChars: normalizedText.substring(0, 50),
      error: errorMsg
    });
    
    return {
      translatedText: normalizedText,
      detectedLanguage: detection.code,
      originalText,
      wasTranslated: false,
    };
  }
}

/**
 * Translate an article (title + content) to English
 */
export async function translateArticle(title: string, content: string, feedLanguage?: string): Promise<{
  title: string;
  content: string;
  language: string;
  wasTranslated: boolean;
}> {
  const originalTitle = title;
  const originalContent = content;
  
  const normalizedTitle = normalizeTextForTranslation(title);
  const normalizedContent = normalizeTextForTranslation(content);
  
  const combinedText = `${normalizedTitle} ${normalizedContent}`.substring(0, 1000);
  const detection = detectLanguage(combinedText, feedLanguage);
  
  if (detection.code === 'en') {
    return {
      title: normalizedTitle,
      content: normalizedContent,
      language: 'en',
      wasTranslated: false,
    };
  }

  try {
    console.log(`[TRANSLATOR] Translating article from ${detection.code} (confidence: ${detection.confidence})`);

    let titleResult, contentResult;
    let usedAutoFallback = false;
    
    if (detection.confidence === 'low' || detection.code === 'und') {
      console.log(`[TRANSLATOR] Low confidence, using 'auto' source language for article`);
      usedAutoFallback = true;
      titleResult = await retryWithBackoff(async () => {
        return await translate(normalizedTitle, { to: 'en', from: 'auto' });
      });

      await sleep(1000);

      contentResult = await retryWithBackoff(async () => {
        return await translate(normalizedContent, { to: 'en', from: 'auto' });
      });
    } else {
      try {
        titleResult = await retryWithBackoff(async () => {
          return await translate(normalizedTitle, { to: 'en', from: detection.code });
        });

        await sleep(1000);

        contentResult = await retryWithBackoff(async () => {
          return await translate(normalizedContent, { to: 'en', from: detection.code });
        });
      } catch (languageError) {
        const errorMsg = languageError instanceof Error ? languageError.message : 'Unknown error';
        if (errorMsg.includes('Bad Request') || errorMsg.includes('400')) {
          console.log(`[TRANSLATOR] Language code '${detection.code}' rejected, retrying article with 'auto'`);
          usedAutoFallback = true;
          titleResult = await retryWithBackoff(async () => {
            return await translate(normalizedTitle, { to: 'en', from: 'auto' });
          });

          await sleep(1000);

          contentResult = await retryWithBackoff(async () => {
            return await translate(normalizedContent, { to: 'en', from: 'auto' });
          });
        } else {
          throw languageError;
        }
      }
    }

    console.log(`[TRANSLATOR] ✓ Translated article from ${detection.code}${usedAutoFallback ? ' (via auto)' : ''}`);

    return {
      title: titleResult.text,
      content: contentResult.text,
      language: detection.code,
      wasTranslated: true,
    };
  } catch (error) {
    const errorMsg = error instanceof Error ? error.message : 'Unknown error';
    console.error(`[TRANSLATOR] ✗ Article translation failed:`, {
      detectedLanguage: detection.code,
      confidence: detection.confidence,
      titleLength: normalizedTitle.length,
      contentLength: normalizedContent.length,
      error: errorMsg
    });
    
    return {
      title: normalizedTitle,
      content: normalizedContent,
      language: detection.code,
      wasTranslated: false,
    };
  }
}
