import axios from "axios";
import { buildTwitterQuery } from "./social-media-keywords";
import { africanCountries } from "@shared/schema";

interface Tweet {
  id: string;
  text: string;
  author: string;
  createdAt: Date;
  url: string;
}

export async function searchTwitterSecurity(): Promise<Tweet[]> {
  const bearerToken = process.env.TWITTER_BEARER_TOKEN;
  
  if (!bearerToken) {
    console.log("[Twitter] Bearer token not configured - skipping Twitter API");
    return [];
  }

  try {
    // Build search query for African security incidents using new keywords
    const keywordQuery = buildTwitterQuery(8); // Top 8 keywords
    
    // Split 54 African countries into batches to avoid Twitter query length limits (512 chars)
    // Each batch contains ~9 countries to stay well under the limit
    const countryBatches: string[][] = [];
    const batchSize = 9;
    for (let i = 0; i < africanCountries.length; i += batchSize) {
      countryBatches.push(africanCountries.slice(i, i + batchSize));
    }
    
    console.log(`[Twitter] Searching ${africanCountries.length} countries in ${countryBatches.length} batches`);
    
    const allTweets: Tweet[] = [];

    // Search each country batch across multiple languages
    for (let batchIdx = 0; batchIdx < countryBatches.length; batchIdx++) {
      const countryBatch = countryBatches[batchIdx];
      const africanCountryMentions = countryBatch.join(" OR ");
      
      // Search in multiple languages: English, French, Portuguese
      // Note: Twitter API doesn't support Arabic language code, but Arabic content will be found in text
      const queries = [
        `(${keywordQuery}) (${africanCountryMentions}) -is:retweet lang:en`,
        `(${keywordQuery}) (${africanCountryMentions}) -is:retweet lang:fr`,
        `(${keywordQuery}) (${africanCountryMentions}) -is:retweet lang:pt`,
      ];

      // Execute searches for each language in this country batch
      for (const query of queries) {
        try {
          const response = await axios.get("https://api.twitter.com/2/tweets/search/recent", {
            params: {
              query: query,
              max_results: 20, // Reduced per query but more total queries
              "tweet.fields": "created_at,author_id,lang",
              "user.fields": "username",
              expansions: "author_id"
            },
            headers: {
              'Authorization': `Bearer ${bearerToken}`,
            },
            timeout: 15000,
          });

          if (response.data?.data) {
            const users = new Map<string, string>(
              (response.data.includes?.users || []).map((u: any) => [u.id as string, u.username as string])
            );

            for (const tweet of response.data.data) {
              const username = users.get(tweet.author_id) || "unknown";
              allTweets.push({
                id: String(tweet.id),
                text: String(tweet.text),
                author: String(username),
                createdAt: new Date(tweet.created_at),
                url: `https://twitter.com/${username}/status/${tweet.id}`,
              });
            }
          }

          // Rate limiting - wait between requests
          await new Promise(resolve => setTimeout(resolve, 1000));
        } catch (error) {
          // Continue with other queries even if one fails
          console.error(`[Twitter] Error with batch ${batchIdx + 1} query "${query.substring(0, 50)}...":`, 
            error instanceof Error ? error.message : "Unknown error");
        }
      }
    }

    // Remove duplicates based on tweet ID
    const uniqueTweets = Array.from(
      new Map(allTweets.map(tweet => [tweet.id, tweet])).values()
    );

    console.log(`[Twitter] Fetched ${uniqueTweets.length} unique tweets across all languages`);
    return uniqueTweets;
    
  } catch (error) {
    if (axios.isAxiosError(error) && error.response?.status === 401) {
      console.error("[Twitter] Invalid bearer token");
    } else if (axios.isAxiosError(error) && error.response?.status === 429) {
      console.error("[Twitter] Rate limit exceeded");
    } else {
      console.error("[Twitter] Error:", error instanceof Error ? error.message : "Unknown error");
    }
    return [];
  }
}
