import { 
  type Alert, 
  type InsertAlert,
  type MonitoredCountry,
  type InsertMonitoredCountry,
  type NewsletterSubscriber,
  type InsertNewsletterSubscriber,
  type AppSetting,
  alerts,
  monitoredCountries,
  newsletterSubscribers,
  appSettings,
} from "@shared/schema";
import { randomUUID } from "crypto";
import { db } from "./db.js";
import { eq, inArray, and, gte, desc, sql as drizzleSql } from "drizzle-orm";

export interface IStorage {
  // Alerts (now global - no user filtering)
  getAllAlerts(region?: string, limit?: number): Promise<Alert[]>;
  getAlertById(id: string): Promise<Alert | undefined>;
  getAlertsByCountries(countries: string[]): Promise<Alert[]>;
  getRecentAlertsByCountry(country: string, hoursBack: number, referenceTime?: Date): Promise<Alert[]>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  deleteAlert(id: string): Promise<void>;
  deleteAllAlerts(): Promise<void>;
  pruneOldAlerts(keepCount: number): Promise<number>; // Returns number of deleted alerts
  updateAlertAnalysis(id: string, analysis: string): Promise<void>;

  // Monitored Countries (now global)
  getAllMonitoredCountries(): Promise<MonitoredCountry[]>;
  getMonitoredCountries(region?: string): Promise<MonitoredCountry[]>;
  createMonitoredCountry(country: InsertMonitoredCountry): Promise<MonitoredCountry>;
  deleteMonitoredCountry(id: string): Promise<void>;
  toggleMonitoredCountry(id: string, enabled: boolean): Promise<MonitoredCountry>;

  // Newsletter Subscribers
  getAllNewsletterSubscribers(): Promise<NewsletterSubscriber[]>;
  getActiveNewsletterSubscribers(): Promise<NewsletterSubscriber[]>;
  getNewsletterSubscriberByEmail(email: string): Promise<NewsletterSubscriber | undefined>;
  getNewsletterSubscriberByToken(token: string): Promise<NewsletterSubscriber | undefined>;
  createNewsletterSubscriber(subscriber: InsertNewsletterSubscriber): Promise<NewsletterSubscriber>;
  unsubscribeNewsletter(token: string): Promise<void>;
  deleteNewsletterSubscriber(id: string): Promise<void>;

  // App Settings
  getSetting(key: string): Promise<string | null>;
  setSetting(key: string, value: string): Promise<void>;
  isNewsletterEnabled(): Promise<boolean>;
  setNewsletterEnabled(enabled: boolean): Promise<void>;
}

export class MemStorage implements IStorage {
  private alerts: Map<string, Alert>;
  private monitoredCountries: Map<string, MonitoredCountry>;

  constructor() {
    this.alerts = new Map();
    this.monitoredCountries = new Map();
  }

  // Alert methods (now global - no user filtering)
  async getAllAlerts(region?: string, limit: number = 2000): Promise<Alert[]> {
    const filtered = Array.from(this.alerts.values())
      .filter(alert => !region || alert.region === region)
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime())
      .slice(0, limit);
    return filtered;
  }

  async getAlertById(id: string): Promise<Alert | undefined> {
    return this.alerts.get(id);
  }

  async getAlertsByCountries(countries: string[]): Promise<Alert[]> {
    return Array.from(this.alerts.values()).filter((alert) =>
      countries.includes(alert.country)
    );
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = randomUUID();
    const alert: Alert = { 
      id,
      region: insertAlert.region ?? "africa",
      country: insertAlert.country,
      title: insertAlert.title,
      description: insertAlert.description,
      location: insertAlert.location,
      severity: insertAlert.severity,
      source: insertAlert.source,
      sourceUrl: insertAlert.sourceUrl ?? null,
      timestamp: insertAlert.timestamp ?? new Date(), // Use source timestamp if provided
      violenceDetails: insertAlert.violenceDetails ?? null,
      policeIntervention: insertAlert.policeIntervention ?? null,
      aiAnalysis: insertAlert.aiAnalysis ?? null,
      latitude: insertAlert.latitude ?? null,
      longitude: insertAlert.longitude ?? null,
      originalTitle: insertAlert.originalTitle ?? null,
      originalDescription: insertAlert.originalDescription ?? null,
      detectedLanguage: insertAlert.detectedLanguage ?? null,
      wasTranslated: insertAlert.wasTranslated ?? false,
    };
    this.alerts.set(id, alert);
    return alert;
  }

  async deleteAlert(id: string): Promise<void> {
    this.alerts.delete(id);
  }

  async deleteAllAlerts(): Promise<void> {
    this.alerts.clear();
  }

  async pruneOldAlerts(keepCount: number = 2000): Promise<number> {
    const allAlerts = Array.from(this.alerts.values())
      .sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
    
    if (allAlerts.length <= keepCount) return 0;
    
    const toDelete = allAlerts.slice(keepCount);
    toDelete.forEach(alert => this.alerts.delete(alert.id));
    return toDelete.length;
  }

  async updateAlertAnalysis(id: string, analysis: string): Promise<void> {
    const alert = this.alerts.get(id);
    if (alert) {
      alert.aiAnalysis = analysis;
      this.alerts.set(id, alert);
    }
  }

  // Monitored Countries methods (now global - no user filtering)
  async getAllMonitoredCountries(): Promise<MonitoredCountry[]> {
    return Array.from(this.monitoredCountries.values());
  }

  async getMonitoredCountries(region?: string): Promise<MonitoredCountry[]> {
    return Array.from(this.monitoredCountries.values()).filter(country =>
      !region || country.region === region
    );
  }

  async createMonitoredCountry(insertCountry: InsertMonitoredCountry): Promise<MonitoredCountry> {
    const id = randomUUID();
    const country: MonitoredCountry = {
      id,
      country: insertCountry.country,
      region: insertCountry.region ?? "africa",
      enabled: insertCountry.enabled ?? true,
      createdAt: new Date(),
    };
    this.monitoredCountries.set(id, country);
    return country;
  }

  async deleteMonitoredCountry(id: string): Promise<void> {
    this.monitoredCountries.delete(id);
  }

  async toggleMonitoredCountry(id: string, enabled: boolean): Promise<MonitoredCountry> {
    const country = this.monitoredCountries.get(id);
    if (!country) {
      throw new Error("Monitored country not found");
    }
    country.enabled = enabled;
    this.monitoredCountries.set(id, country);
    return country;
  }

  async getRecentAlertsByCountry(country: string, hoursBack: number, referenceTime?: Date): Promise<Alert[]> {
    const refTime = referenceTime ?? new Date();
    const cutoffStart = new Date(refTime.getTime() - hoursBack * 60 * 60 * 1000);
    const cutoffEnd = new Date(refTime.getTime() + hoursBack * 60 * 60 * 1000);
    return Array.from(this.alerts.values()).filter(
      alert => {
        const alertTime = new Date(alert.timestamp);
        return alert.country === country && alertTime >= cutoffStart && alertTime <= cutoffEnd;
      }
    );
  }

  // Newsletter Subscriber methods (in-memory - not used in production)
  private newsletterSubscribers: Map<string, NewsletterSubscriber> = new Map();

  async getAllNewsletterSubscribers(): Promise<NewsletterSubscriber[]> {
    return Array.from(this.newsletterSubscribers.values());
  }

  async getActiveNewsletterSubscribers(): Promise<NewsletterSubscriber[]> {
    return Array.from(this.newsletterSubscribers.values()).filter(sub => sub.isActive);
  }

  async getNewsletterSubscriberByEmail(email: string): Promise<NewsletterSubscriber | undefined> {
    return Array.from(this.newsletterSubscribers.values()).find(sub => sub.email === email);
  }

  async getNewsletterSubscriberByToken(token: string): Promise<NewsletterSubscriber | undefined> {
    return Array.from(this.newsletterSubscribers.values()).find(sub => sub.unsubscribeToken === token);
  }

  async createNewsletterSubscriber(insertSubscriber: InsertNewsletterSubscriber): Promise<NewsletterSubscriber> {
    const id = randomUUID();
    const subscriber: NewsletterSubscriber = {
      id,
      email: insertSubscriber.email,
      subscribedAt: new Date(),
      unsubscribeToken: randomUUID(),
      isActive: insertSubscriber.isActive ?? true,
    };
    this.newsletterSubscribers.set(id, subscriber);
    return subscriber;
  }

  async unsubscribeNewsletter(token: string): Promise<void> {
    const subscriber = await this.getNewsletterSubscriberByToken(token);
    if (subscriber) {
      subscriber.isActive = false;
      this.newsletterSubscribers.set(subscriber.id, subscriber);
    }
  }

  async deleteNewsletterSubscriber(id: string): Promise<void> {
    this.newsletterSubscribers.delete(id);
  }

  // App Settings methods (stub - not persisted in memory storage)
  async getSetting(key: string): Promise<string | null> {
    return null;
  }

  async setSetting(key: string, value: string): Promise<void> {
    // No-op for memory storage
  }

  async isNewsletterEnabled(): Promise<boolean> {
    return false; // Always disabled for memory storage
  }

  async setNewsletterEnabled(enabled: boolean): Promise<void> {
    // No-op for memory storage
  }
}

// Database Storage Implementation (PostgreSQL with Drizzle ORM)
export class DbStorage implements IStorage {
  // Alert methods (now global - no user filtering)
  // Added limit parameter to prevent database response size errors (max 64MB)
  async getAllAlerts(region?: string, limit: number = 2000): Promise<Alert[]> {
    if (region) {
      return await db.select().from(alerts)
        .where(eq(alerts.region, region))
        .orderBy(desc(alerts.timestamp))
        .limit(limit);
    }
    return await db.select().from(alerts)
      .orderBy(desc(alerts.timestamp))
      .limit(limit);
  }

  async getAlertById(id: string): Promise<Alert | undefined> {
    const results = await db.select().from(alerts).where(eq(alerts.id, id));
    return results[0];
  }

  async getAlertsByCountries(countries: string[]): Promise<Alert[]> {
    if (countries.length === 0) return [];
    return await db.select().from(alerts).where(inArray(alerts.country, countries));
  }

  async getRecentAlertsByCountry(country: string, hoursBack: number, referenceTime?: Date): Promise<Alert[]> {
    const refTime = referenceTime ?? new Date();
    const cutoffStart = new Date(refTime.getTime() - hoursBack * 60 * 60 * 1000);
    const cutoffEnd = new Date(refTime.getTime() + hoursBack * 60 * 60 * 1000);
    return await db
      .select()
      .from(alerts)
      .where(
        and(
          eq(alerts.country, country),
          gte(alerts.timestamp, cutoffStart),
          drizzleSql`${alerts.timestamp} <= ${cutoffEnd}`
        )
      );
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const result = await db.insert(alerts).values({
      ...insertAlert,
      region: insertAlert.region ?? "africa",
      timestamp: insertAlert.timestamp ?? new Date(), // Use source timestamp if provided
    }).returning();
    return result[0];
  }

  async deleteAlert(id: string): Promise<void> {
    await db.delete(alerts).where(eq(alerts.id, id));
  }

  async deleteAllAlerts(): Promise<void> {
    await db.delete(alerts);
  }

  async pruneOldAlerts(keepCount: number = 2000): Promise<number> {
    // Get the timestamp of the Nth most recent alert (the cutoff)
    const cutoffResult = await db.select({ timestamp: alerts.timestamp })
      .from(alerts)
      .orderBy(desc(alerts.timestamp))
      .limit(1)
      .offset(keepCount - 1);
    
    if (cutoffResult.length === 0) {
      // Less than keepCount alerts exist, nothing to prune
      return 0;
    }
    
    const cutoffTimestamp = cutoffResult[0].timestamp;
    
    // Delete all alerts older than the cutoff
    const result = await db.delete(alerts)
      .where(drizzleSql`${alerts.timestamp} < ${cutoffTimestamp}`)
      .returning({ id: alerts.id });
    
    return result.length;
  }

  async updateAlertAnalysis(id: string, analysis: string): Promise<void> {
    await db.update(alerts)
      .set({ aiAnalysis: analysis })
      .where(eq(alerts.id, id));
  }

  // Monitored Countries methods (now global - no user filtering)
  async getAllMonitoredCountries(): Promise<MonitoredCountry[]> {
    return await db.select().from(monitoredCountries);
  }

  async getMonitoredCountries(region?: string): Promise<MonitoredCountry[]> {
    if (region) {
      return await db.select().from(monitoredCountries).where(eq(monitoredCountries.region, region));
    }
    return await db.select().from(monitoredCountries);
  }

  async createMonitoredCountry(insertCountry: InsertMonitoredCountry): Promise<MonitoredCountry> {
    const result = await db.insert(monitoredCountries).values({
      ...insertCountry,
      region: insertCountry.region ?? "africa",
    }).returning();
    return result[0];
  }

  async deleteMonitoredCountry(id: string): Promise<void> {
    await db.delete(monitoredCountries).where(eq(monitoredCountries.id, id));
  }

  async toggleMonitoredCountry(id: string, enabled: boolean): Promise<MonitoredCountry> {
    const result = await db.update(monitoredCountries)
      .set({ enabled })
      .where(eq(monitoredCountries.id, id))
      .returning();
    if (!result[0]) {
      throw new Error("Monitored country not found");
    }
    return result[0];
  }

  // Newsletter Subscriber methods
  async getAllNewsletterSubscribers(): Promise<NewsletterSubscriber[]> {
    return await db.select().from(newsletterSubscribers);
  }

  async getActiveNewsletterSubscribers(): Promise<NewsletterSubscriber[]> {
    return await db.select().from(newsletterSubscribers).where(eq(newsletterSubscribers.isActive, true));
  }

  async getNewsletterSubscriberByEmail(email: string): Promise<NewsletterSubscriber | undefined> {
    const results = await db.select().from(newsletterSubscribers).where(eq(newsletterSubscribers.email, email));
    return results[0];
  }

  async getNewsletterSubscriberByToken(token: string): Promise<NewsletterSubscriber | undefined> {
    const results = await db.select().from(newsletterSubscribers).where(eq(newsletterSubscribers.unsubscribeToken, token));
    return results[0];
  }

  async createNewsletterSubscriber(insertSubscriber: InsertNewsletterSubscriber): Promise<NewsletterSubscriber> {
    const result = await db.insert(newsletterSubscribers).values({
      email: insertSubscriber.email,
      isActive: insertSubscriber.isActive ?? true,
    }).returning();
    return result[0];
  }

  async unsubscribeNewsletter(token: string): Promise<void> {
    await db.update(newsletterSubscribers)
      .set({ isActive: false })
      .where(eq(newsletterSubscribers.unsubscribeToken, token));
  }

  async deleteNewsletterSubscriber(id: string): Promise<void> {
    await db.delete(newsletterSubscribers).where(eq(newsletterSubscribers.id, id));
  }

  // App Settings methods
  async getSetting(key: string): Promise<string | null> {
    const results = await db.select().from(appSettings).where(eq(appSettings.key, key));
    return results[0]?.value ?? null;
  }

  async setSetting(key: string, value: string): Promise<void> {
    await db.insert(appSettings)
      .values({ key, value })
      .onConflictDoUpdate({
        target: appSettings.key,
        set: { value, updatedAt: new Date() },
      });
  }

  async isNewsletterEnabled(): Promise<boolean> {
    const value = await this.getSetting('newsletter_enabled');
    // Default to disabled (false) if not set
    return value === 'true';
  }

  async setNewsletterEnabled(enabled: boolean): Promise<void> {
    await this.setSetting('newsletter_enabled', enabled.toString());
  }
}

// Use database storage
export const storage: IStorage = new DbStorage();
