import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, boolean, numeric, index, jsonb, real, uniqueIndex } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Alert severity levels matching design guidelines
export const severityLevels = ["critical", "high", "moderate", "info"] as const;
export type SeverityLevel = typeof severityLevels[number];

// Comprehensive list of African countries
export const africanCountries = [
  "Algeria", "Angola", "Benin", "Botswana", "Burkina Faso", "Burundi", "Cabo Verde", "Cameroon",
  "Central African Republic", "Chad", "Comoros", "Congo", "Democratic Republic of Congo", "Djibouti",
  "Egypt", "Equatorial Guinea", "Eritrea", "Eswatini", "Ethiopia", "Gabon", "Gambia", "Ghana",
  "Guinea", "Guinea-Bissau", "Ivory Coast", "Kenya", "Lesotho", "Liberia", "Libya", "Madagascar",
  "Malawi", "Mali", "Mauritania", "Mauritius", "Morocco", "Mozambique", "Namibia", "Niger",
  "Nigeria", "Rwanda", "Sao Tome and Principe", "Senegal", "Seychelles", "Sierra Leone", "Somalia",
  "South Africa", "South Sudan", "Sudan", "Tanzania", "Togo", "Tunisia", "Uganda", "Zambia", "Zimbabwe"
] as const;

export type AfricanCountry = typeof africanCountries[number];

// Comprehensive list of Asian countries (East and Southeast Asia - 14 countries)
export const asianCountries = [
  "Brunei", "Cambodia", "China", "Indonesia", "Japan", "Laos", "Malaysia",
  "Mongolia", "Myanmar", "North Korea", "Philippines", "Singapore", "South Korea",
  "Taiwan", "Thailand", "Timor-Leste", "Vietnam"
] as const;

export type AsianCountry = typeof asianCountries[number];

// Comprehensive list of Central and South Asian countries (14 countries)
export const centralSouthAsianCountries = [
  "Afghanistan", "Bangladesh", "Bhutan", "India", "Kazakhstan", "Kyrgyzstan",
  "Maldives", "Nepal", "Pakistan", "Sri Lanka", "Tajikistan", "Turkmenistan", "Uzbekistan"
] as const;

export type CentralSouthAsianCountry = typeof centralSouthAsianCountries[number];

// Comprehensive list of European countries (50 countries - using UN geoscheme)
export const europeanCountries = [
  "Albania", "Andorra", "Armenia", "Austria", "Azerbaijan", "Belarus", "Belgium", "Bosnia and Herzegovina",
  "Bulgaria", "Croatia", "Cyprus", "Czechia", "Denmark", "Estonia", "Finland", "France",
  "Georgia", "Germany", "Greece", "Hungary", "Iceland", "Ireland", "Italy", "Kosovo",
  "Latvia", "Liechtenstein", "Lithuania", "Luxembourg", "Malta", "Moldova", "Monaco", "Montenegro",
  "Netherlands", "North Macedonia", "Norway", "Poland", "Portugal", "Romania", "Russia", "San Marino",
  "Serbia", "Slovakia", "Slovenia", "Spain", "Sweden", "Switzerland", "Turkey", "Ukraine",
  "United Kingdom", "Vatican City"
] as const;

export type EuropeanCountry = typeof europeanCountries[number];

// Comprehensive list of Middle Eastern countries (15 countries - transcontinental countries moved to Europe)
export const middleEasternCountries = [
  "Bahrain", "Egypt", "Iran", "Iraq", "Israel", "Jordan", "Kuwait",
  "Lebanon", "Oman", "Palestine", "Qatar", "Saudi Arabia", "Syria",
  "United Arab Emirates", "Yemen"
] as const;

export type MiddleEasternCountry = typeof middleEasternCountries[number];

// Comprehensive list of South American countries (13 countries)
export const southAmericanCountries = [
  "Argentina", "Bolivia", "Brazil", "Chile", "Colombia", "Ecuador", "Guyana",
  "Paraguay", "Peru", "Suriname", "Uruguay", "Venezuela", "French Guiana"
] as const;

export type SouthAmericanCountry = typeof southAmericanCountries[number];

// Comprehensive list of North American countries (23 countries)
export const northAmericanCountries = [
  "United States", "Canada", "Mexico", "Belize", "Costa Rica", "El Salvador",
  "Guatemala", "Honduras", "Nicaragua", "Panama", "Antigua and Barbuda", "Bahamas",
  "Barbados", "Cuba", "Dominica", "Dominican Republic", "Grenada", "Haiti",
  "Jamaica", "Saint Kitts and Nevis", "Saint Lucia", "Saint Vincent and the Grenadines",
  "Trinidad and Tobago"
] as const;

export type NorthAmericanCountry = typeof northAmericanCountries[number];

// Region types
export const regions = ["africa", "asia", "europe", "middleeast", "southamerica", "northamerica", "centralsouthasia"] as const;
export type Region = typeof regions[number];

// Combined countries by region
export const countriesByRegion: Record<Region, readonly string[]> = {
  africa: africanCountries,
  asia: asianCountries,
  europe: europeanCountries,
  middleeast: middleEasternCountries,
  southamerica: southAmericanCountries,
  northamerica: northAmericanCountries,
  centralsouthasia: centralSouthAsianCountries,
};

// Alerts table - stores detected incidents (now global - no user filtering)
export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("africa"), // Region: africa, asia, europe, middleeast, southamerica, northamerica, or centralsouthasia
  country: text("country").notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  location: text("location").notNull(),
  severity: text("severity").notNull(), // critical, high, moderate, info
  source: text("source").notNull(), // News source name
  sourceUrl: text("source_url"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  violenceDetails: text("violence_details"),
  policeIntervention: text("police_intervention"),
  aiAnalysis: text("ai_analysis"), // Full AI analysis
  latitude: numeric("latitude"), // Geographic coordinates for location mapping
  longitude: numeric("longitude"), // Geographic coordinates for location mapping
  originalTitle: text("original_title"), // Original language title (if translated)
  originalDescription: text("original_description"), // Original language description (if translated)
  detectedLanguage: text("detected_language"), // ISO language code (e.g., 'fr', 'ar', 'pt')
  wasTranslated: boolean("was_translated").notNull().default(false), // Whether content was translated
}, (table) => [
  // Index for deduplication performance (country + timestamp for recent alert lookups)
  index("alerts_country_timestamp_idx").on(table.country, table.timestamp),
]);

// Monitored countries - now global (no user filtering)
export const monitoredCountries = pgTable("monitored_countries", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  region: text("region").notNull().default("africa"), // Region: africa, asia, europe, middleeast, southamerica, northamerica, or centralsouthasia
  country: text("country").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
});

// Newsletter subscribers - stores emails for daily briefing delivery
export const newsletterSubscribers = pgTable("newsletter_subscribers", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  email: text("email").notNull().unique(),
  subscribedAt: timestamp("subscribed_at").notNull().defaultNow(),
  unsubscribeToken: varchar("unsubscribe_token").notNull().unique().default(sql`gen_random_uuid()`),
  isActive: boolean("is_active").notNull().default(true),
}, (table) => [
  // Index for quick email lookup
  uniqueIndex("newsletter_email_idx").on(table.email),
]);

// App settings - stores global configuration
export const appSettings = pgTable("app_settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

// Insert schemas
export const insertAlertSchema = createInsertSchema(alerts)
  .omit({
    id: true,
  })
  .extend({
    severity: z.enum(severityLevels),
    timestamp: z.date().optional(), // Allow passing source timestamp for deduplication
  });

export const insertMonitoredCountrySchema = createInsertSchema(monitoredCountries).omit({
  id: true,
  createdAt: true,
});

export const insertNewsletterSubscriberSchema = createInsertSchema(newsletterSubscribers)
  .omit({
    id: true,
    subscribedAt: true,
    unsubscribeToken: true,
  })
  .extend({
    email: z.string().email("Invalid email address"),
  });

// Types
export type InsertAlert = z.infer<typeof insertAlertSchema>;
export type Alert = typeof alerts.$inferSelect;

export type InsertMonitoredCountry = z.infer<typeof insertMonitoredCountrySchema>;
export type MonitoredCountry = typeof monitoredCountries.$inferSelect;

export type InsertNewsletterSubscriber = z.infer<typeof insertNewsletterSubscriberSchema>;
export type NewsletterSubscriber = typeof newsletterSubscribers.$inferSelect;

export type AppSetting = typeof appSettings.$inferSelect;

// NOTE: User authentication and subscriptions removed for decentralized architecture
// Each user maintains their own local copy of alerts in browser IndexedDB

// Filter schemas for frontend
export const alertFilterSchema = z.object({
  countries: z.array(z.string()).optional(),
  severities: z.array(z.string()).optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
});

export type AlertFilter = z.infer<typeof alertFilterSchema>;
